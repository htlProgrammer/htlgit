#!/bin/bash
mvn clean package;

scp -i ~/.ssh/zionwebsite.pem target/zion-project.jar ubuntu@ec2-52-81-46-55.cn-north-1.compute.amazonaws.com.cn:~;

ssh -i "~/.ssh/zionwebsite.pem" ubuntu@ec2-52-81-46-55.cn-north-1.compute.amazonaws.com.cn 'kill -9 `ps -ef | grep zion-project.jar|grep -v grep|awk '{print $2}'`;rm -rf ~/java/zion-project.jar;mv zion-project.jar java/zion-project.jar; cd java;nohup java -jar zion-project.jar >temp.txt &';


