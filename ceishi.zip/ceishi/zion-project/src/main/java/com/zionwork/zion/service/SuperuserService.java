package com.zionwork.zion.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.jaxb.PageAdapter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zionwork.zion.entity.Superuser;
import com.zionwork.zion.repository.SuperuserRepository;

/**
 * @author Zion Admin
 * 超级用户的service层
 */
@Transactional
@Service
public class SuperuserService {     
    @Autowired
    private SuperuserRepository superuserRepository;

    public SuperuserRepository getSuperuserRepository() {
        return superuserRepository;
    }

	/**
	 * 根据超级用户id查找超级用户信息
	 * @param superUserId
	 * @return
	 */
	public Superuser findSuperUserBySuperUserId(String superUserId) {		
		return superuserRepository.findOne(superUserId);
	}

	/**
	 * 根据超级用户状态查找超级用户信息
	 * @param status
	 * @return
	 */
	public List<Superuser> findSuperUserByStatus(String status) {
		Superuser superuser=new Superuser();
		superuser.setStatus(status);
		Example<Superuser> example=Example.of(superuser);
		return superuserRepository.findAll(example);
	}

	public String addSuperUser(String superUserId, String telephone, String telephoneName,String status,String mailBox) {
		Superuser findOne = superuserRepository.findOne(superUserId);
		if (findOne!=null) {
			return "The superuserid already exists";
		}
		Superuser superuser=new Superuser();
		superuser.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
		superuser.setStatus(status);
		superuser.setSuperUserId(superUserId);
		superuser.setTelephone(telephone);
		superuser.setTelephoneName(telephoneName);
		superuser.setMailBox(mailBox);
		superuserRepository.save(superuser);
		return "success";
	}

}