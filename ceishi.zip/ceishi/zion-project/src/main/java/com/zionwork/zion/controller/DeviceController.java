package com.zionwork.zion.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Device;
import com.zionwork.zion.service.DeviceService;
import com.zionwork.zion.service.SuperuserService;

/**
 * @author Zion Admin
 * 设备接口
 */

@Controller
@RequestMapping("/zion/Device")
public class DeviceController extends BaseController {
    @Autowired
    private DeviceService deviceService;
    @Autowired
    private SuperuserService superuserService;

    /**
     * 注册设备
     *
     * @param deviceId
     * @param deviceType
     * @param deviceMake
     * @param deviceMakeTime
     * @param deviceStatus
     * @param deviceVersion
     * @param deviceInfo
     * @return
     */
    @RequestMapping("/registerDevice")
    @ResponseBody
    public void registerDevice(HttpServletRequest req, HttpServletResponse resp) {
        String deviceId = req.getParameter("deviceId");
        String deviceType = req.getParameter("deviceType");
        String deviceMake = req.getParameter("deviceMake");
        String deviceMakeTime = req.getParameter("deviceMakeTime");
        String deviceStatus = req.getParameter("deviceStatus");
        String deviceVersion = req.getParameter("deviceVersion");
        String areaId = req.getParameter("areaId");
        String deviceAddress = req.getParameter("deviceAddress");
        String superUserId = req.getParameter("superUserId");
        //判断关键参数是否为空
        if (!validateParams(resp, req, deviceId, deviceType, deviceStatus, deviceMakeTime)) {
            return;
        }
        //判断区域是否存在
        if (deviceService.findDeviceByDeviceId(deviceId) != null) {
            printJson(resp, req, 400, "The deviceId already exists", "String");
            return;
        }
        try {
        	//空字段同意使用“—”代替
            deviceMake = changeNullParam(deviceMake);
            deviceVersion = changeNullParam(deviceVersion);
            areaId = changeNullParam(areaId);
            deviceAddress = changeNullParam(deviceAddress);
            superUserId = changeNullParam(superUserId);
            //录入设备信息
            String registerDevice = deviceService.registerDevice(deviceId, deviceType, deviceMake, deviceStatus,
                    deviceVersion, deviceMakeTime, areaId, deviceAddress, superUserId);
            if (registerDevice.equals("success")) {
                printJson(resp, req, 200, registerDevice, "String");
            } else {
                printJson(resp, req, 400, registerDevice, "String");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 设备绑定超级用户
     *
     * @param deviceId
     * @param superUserId
     * @return
     */
    @RequestMapping("/updateDeviceInfoBySuperUser")
    @ResponseBody
    public void updateDeviceInfoBySuperUser(HttpServletRequest req, HttpServletResponse resp) {
        String deviceId = req.getParameter("deviceId");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空，并且判断设备是否存在
        if (!validateParam(resp, req, deviceId, superUserId)) {
            return;
        }
        try {
        	//更新设备所属用户信息
            String updateDeviceInfoBySuperUser = deviceService.updateDeviceInfoBySuperUser(superUserId, deviceId);
            if (updateDeviceInfoBySuperUser.equals("success")) {
                printJson(resp, req, 200, updateDeviceInfoBySuperUser, "String");
            } else {
                printJson(resp, req, 400, updateDeviceInfoBySuperUser, "String");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 设备定位
     *
     * @param deviceId
     * @param areaId
     * deviceAddress
     *      @param: length
     *      @param: width
     *      @param: height
     * @return
     */
    @RequestMapping("/updateDeviceByArea")
    @ResponseBody
    public void updateDeviceByArea(HttpServletRequest req, HttpServletResponse resp) {
        String deviceId = req.getParameter("deviceId");
        String areaId = req.getParameter("areaId");
        String length = req.getParameter("length");
        String width = req.getParameter("width");
        String height = req.getParameter("height");
        //判断参数是否为空，并且判断设备是否存在
        if (!validateParam(resp, req, deviceId, areaId)) {
            return;
        }
        //判断参数是否为空
        if (!validateParams(resp, req,length,width,height)) {
            return;
        }
        try {
        	//更新设备位置信息
            String updateDeviceByArea = deviceService.updateDeviceByArea(areaId, deviceId, length,width,height);
            if (updateDeviceByArea.equals("success")) {
                printJson(resp, req, 200, updateDeviceByArea, "String");
            } else {
                printJson(resp, req, 400, updateDeviceByArea, "String");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

	/**
	 * 设备状态更新
	 *
	 * @param deviceId
	 * @param deviceStatus
	 * @return
	 */
	@RequestMapping("/updateDeviceInfoByStatus")
	@ResponseBody
	public void updateDeviceInfoByStatus(HttpServletRequest req, HttpServletResponse resp) {
		String deviceId = req.getParameter("deviceId");
		String deviceStatus = req.getParameter("deviceStatus");
		//判断参数是否为空，并且判断设备是否存在
		if (!validateParam(resp,req, deviceId, deviceStatus)) {
			return;
		}
		try {
			//更新设备状态信息
			String updateDeviceInfoByStatus = deviceService.updateDeviceInfoByStatus(deviceStatus, deviceId);
			if (updateDeviceInfoByStatus.equals("success")) {
				printJson(resp,req, 200, updateDeviceInfoByStatus,"String");
			} else {
				printJson(resp,req, 400, updateDeviceInfoByStatus,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}
	
	/**
	 * 设备状态和所属人更新
	 *
	 * @param deviceId
	 * @param deviceStatus
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/updateDeviceInfoByStatusAndSuperUserId")
	@ResponseBody
	public void updateDeviceInfoByStatusAndSuperUserId(HttpServletRequest req, HttpServletResponse resp) {
		String deviceId = req.getParameter("deviceId");
		String deviceStatus = req.getParameter("deviceStatus");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空，并且判断设备是否存在
		if (!validateParam(resp,req, deviceId, deviceStatus)) {
			return;
		}
		//判断参数是否为空
		if (!validateParams(resp,req,superUserId)) {
			return;
		}
		try {
			//更新设备所属人和状态信息
			String updateDeviceInfoByStatusAndSuperUserId = deviceService.updateDeviceInfoByStatusAndSuperUserId(deviceStatus, deviceId,superUserId);
			if (updateDeviceInfoByStatusAndSuperUserId.equals("success")) {
				printJson(resp,req, 200, updateDeviceInfoByStatusAndSuperUserId,"String");
			} else {
				printJson(resp,req, 400, updateDeviceInfoByStatusAndSuperUserId,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

    /**
     * 超级用户根据设备Id查询设备信息
     *
     * @param deviceId
     * @param superUserId
     * @return
     */
    @RequestMapping("/findDeviceInfoByDeviceIdAndSuperUserId")
    @ResponseBody
    public void findDeviceInfoByDeviceIdAndSuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String deviceId = req.getParameter("deviceId");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceId, superUserId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            Device findDeviceInfoByDeviceIdAndSuperUserId = deviceService
                    .findDeviceInfoByDeviceIdAndSuperUserId(deviceId, superUserId);
            if (findDeviceInfoByDeviceIdAndSuperUserId == null) {
                printJson(resp, req, 400, "Find device's info by deviceId and superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDeviceIdAndSuperUserId, "Object");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 超级用户根据设备Id查询设备信息
     *
     * @param areaId
     * @param superUserId
     * @return
     */
    @RequestMapping("/findDeviceInfoByareaIdAndSuperUserId")
    @ResponseBody
    public void findDeviceInfoByareaIdAndSuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String areaId = req.getParameter("areaId");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp, req, areaId, superUserId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
        	List<Device> findDeviceInfoByareaIdAndSuperUserId = deviceService
                    .findDeviceInfoByareaIdAndSuperUserId(areaId, superUserId);
            if (findDeviceInfoByareaIdAndSuperUserId.size() == 0) {
                printJson(resp, req, 400, "Find device's info by areaId and superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByareaIdAndSuperUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    /**
     * 超级用户查询自己所有设备信息
     *
     * @param superUserId
     * @return
     */
    @RequestMapping("/findDeviceInfoBySuperUserId")
    @ResponseBody
    public void findDeviceInfoBySuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp, req, superUserId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceBySuperUserId = deviceService.findDeviceBySuperUserId(superUserId);
            if (findDeviceBySuperUserId.size() == 0) {
                printJson(resp, req, 400, "Find device's info by superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceBySuperUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 超级用户根据设备类型查找设备信息
     *
     * @param superUserId
     * @param deviceType
     * @return
     */
    @RequestMapping("/findDeviceInfoByDeviceTypeAndSuperUserId")
    @ResponseBody
    public void findDeviceInfoByDeviceTypeAndSuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, superUserId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoByDeviceTypeAndSuperUserId = deviceService
                    .findDeviceInfoByDeviceTypeAndSuperUserId(deviceType, superUserId);
            if (findDeviceInfoByDeviceTypeAndSuperUserId.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDeviceTypeAndSuperUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }

    }

    /**
     * 超级用户根据设备类型和区域查找设备信息
     *
     * @param deviceType
     * @param superUserId
     * @param areaId
     * @return
     */
    @RequestMapping("/findDeviceInfoByDeviceTypeAndAreaAndSuperUser")
    @ResponseBody
    public void findDeviceInfoByDeviceTypeAndAreaAndSuperUser(HttpServletRequest req, HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String superUserId = req.getParameter("superUserId");
        String areaId = req.getParameter("areaId");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, superUserId, areaId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoByDeviceTypeAndAreaAndSuperUser = deviceService
                    .findDeviceInfoByDeviceTypeAndAreaAndSuperUser(deviceType, superUserId, areaId);
            if (findDeviceInfoByDeviceTypeAndAreaAndSuperUser.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and areaId and superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDeviceTypeAndAreaAndSuperUser, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 查询超级用户的某类设备的某种设备状态
     *
     * @param superUserId
     * @param deviceType
     * @param deviceStatus
     * @return
     */
    @RequestMapping("/findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus")
    @ResponseBody
    public void findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus(HttpServletRequest req,
                                                                        HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String superUserId = req.getParameter("superUserId");
        String deviceStatus = req.getParameter("deviceStatus");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, superUserId, deviceStatus)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp, req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus = deviceService
                    .findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus(deviceType, superUserId, deviceStatus);
            if (findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and deviceStatus and superuserId does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }


    /**
     * 查询超级用户的某类设备的某种设备状态
     *
     * @param deviceType
     * @param deviceStatus
     * @return
     */
    @RequestMapping("/findDeviceInfoByDevcieTypeAndDeviceStatus")
    @ResponseBody
    public void findDeviceInfoByDevcieTypeAndDeviceStatus(HttpServletRequest req,
                                                          HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String deviceStatus = req.getParameter("deviceStatus");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, deviceStatus)) {
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoByDevcieTypeAndDeviceStatus = deviceService
                    .findDeviceInfoByDevcieTypeAndDeviceStatus(deviceType, deviceStatus);
            if (findDeviceInfoByDevcieTypeAndDeviceStatus.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and deviceStatus does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDevcieTypeAndDeviceStatus, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 查询超级用户的某类设备的某种设备状态
     *
     * @param deviceType
     * @param deviceStatus
     * @param areaId
     * @param deviceAddress
     * @return
     */
    @RequestMapping("/findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo")
    @ResponseBody
    public void findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo(HttpServletRequest req,
                                                          HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String deviceStatus = req.getParameter("deviceStatus");
        String areaId= req.getParameter("areaId");
        String deviceAddress= req.getParameter("deviceAddress");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, deviceStatus,areaId,deviceAddress)) {
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo = deviceService
                    .findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo(deviceType, deviceStatus,areaId,deviceAddress);
            if (findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and deviceStatus and areaInfo does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    
    /**
	 * 通过设备类型，设备生产时间查找设备信息
	 * @param deviceType
	 * @param deviceMakeTime
	 * @return
	 */
    @RequestMapping("/findDeviceInfoByDevcieTypeAndDeviceMakeTime")
    @ResponseBody
    public void findDeviceInfoByDevcieTypeAndDeviceMakeTime(HttpServletRequest req,
                                                          HttpServletResponse resp) {
        String deviceType = req.getParameter("deviceType");
        String deviceMakeTime = req.getParameter("deviceMakeTime");
        //判断参数是否为空
        if (!validateParams(resp, req, deviceType, deviceMakeTime)) {
            return;
        }
        try {
        	//查找数据
            List<Device> findDeviceInfoByDevcieTypeAndDeviceMakeTime = deviceService
                    .findDeviceInfoByDevcieTypeAndDeviceMakeTime(deviceType,deviceMakeTime);
            if (findDeviceInfoByDevcieTypeAndDeviceMakeTime.size() == 0) {
                printJson(resp, req, 400, "Find device's info by deviceType and deviceMakeTime does not exist", "String");
            } else {
                printJson(resp, req, 200, findDeviceInfoByDevcieTypeAndDeviceMakeTime, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    /**
     * 判断一个参数是否为空，和设备是否存在
     * @param resp
     * @param req
     * @param deviceId
     * @param string
     * @return
     */
    public boolean validateParam(HttpServletResponse resp, HttpServletRequest req, String deviceId, String string) {
        if (string == null || string == "") {
            printJson(resp, req, 400, "Key parameter is null", "String");
            return false;
        }
        Device findDeviceByDeviceId = deviceService.findDeviceByDeviceId(deviceId);
        if (findDeviceByDeviceId == null) {
            printJson(resp, req, 400, "The device does not exist", "String");
            return false;
        }
        return true;
    }
 
}