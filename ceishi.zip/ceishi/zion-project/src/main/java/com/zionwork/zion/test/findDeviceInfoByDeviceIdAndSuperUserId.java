package com.zionwork.zion.test;

import java.util.HashMap;
import java.util.Map;

import com.zioncore.utils.ControllerUtil;

public class findDeviceInfoByDeviceIdAndSuperUserId {
	public static void main(String[] args) {
		
		String deviceId="SUNRAY_SmokeDetector_0869-4870-3002-3667";
		String superUserId="01000122";
		reqController(deviceId, superUserId);
	}
	public static void reqController(String deviceId,String superUserId) {
		ControllerUtil controllerUtil=new ControllerUtil();
		Map<String, String> map=new HashMap<>();
		map.put("deviceId", deviceId);
		map.put("superUserId", superUserId);
		String postMap = controllerUtil.postMap("http://127.0.0.1:8094/zion/Device/findDeviceInfoByDeviceIdAndSuperUserId", map);
		System.out.println(postMap);
	}
}
