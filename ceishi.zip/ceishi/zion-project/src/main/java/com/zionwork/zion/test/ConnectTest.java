package com.zionwork.zion.test;


import java.net.URL;

import java.net.URLConnection;

import java.util.concurrent.CountDownLatch;

 

/**

 * Created with IDEA

 * author:QinWei

 * Date:2018/12/27

 * Time:11:08

 * 并发测试

 */

public class ConnectTest {

 

    public static void main(String[] args) throws Exception {

        int count=1400;

        final CountDownLatch cdl=new CountDownLatch(count);

        for (int i = 0; i < count; i++) {

            new Thread(new Runnable() {

                @Override

                public void run() {

                    cdl.countDown();

                    try {

                        cdl.await();

                    } catch (InterruptedException e) {

                        e.printStackTrace();

                    }

                    try {

                        connect();

                    } catch (Exception e) {

                        e.printStackTrace();

                    }

                }
            }).start();
            
            
        }
        Thread.sleep(5000);
        Thread thread=new Thread(new Runnable() {

            @Override

            public void run() {

                cdl.countDown();

                try {

                    cdl.await();

                } catch (InterruptedException e) {

                    e.printStackTrace();

                }

                try {

                    connect();

                } catch (Exception e) {

                    e.printStackTrace();

                }

            }
        });
        thread.start();
 

    }

 

        public static void connect() throws Exception {

            final String urlStr="http://127.0.0.1:8090//zion/Operation/findAllDeviceOperationBySuperUserAndTime?superUserId='333'";

            URL url=new URL(urlStr);

            URLConnection urlConnection = url.openConnection();

            urlConnection.setDoInput(true);

            urlConnection.setDoOutput(true);

            urlConnection.connect();

            System.out.println(urlConnection.getInputStream());

    }

}

