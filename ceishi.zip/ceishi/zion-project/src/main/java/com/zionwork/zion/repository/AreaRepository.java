package com.zionwork.zion.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.zionwork.zion.entity.Area;

/**
 * @author Zion Admin
 * Area数据处理的Dao层
 */
public interface AreaRepository extends JpaRepository<Area, Serializable> {
	
	@Query(value = "update area set areaName =:areaName,areaSize=:areaSize,userId=:userId,superUserId=:superUserId,areaPictureUrl=:areaPictureUrl where areaId =:areaId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateArea(@Param("areaId")String areaId, @Param("areaName")String areaName, @Param("areaSize")String areaSize,@Param("userId") String userId, @Param("superUserId")String superUserId, @Param("areaPictureUrl")String areaPictureUrl);
	
	@Query(value = "update area set areaSize =:areaSize where areaId =:areaId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateAreaSize(@Param("areaId")String areaId, @Param("areaSize")String areaSize);
	
	@Query(value = "update area set userId =:userId where areaId =:areaId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateAreaUserId( @Param("areaId") String areaId, @Param("userId") String userId);
	
	@Query(value = "update area set superUserId =:superUserId where areaId =:areaId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateAreasuperUserId(@Param("areaId")String areaId,@Param("superUserId") String superUserId);
}