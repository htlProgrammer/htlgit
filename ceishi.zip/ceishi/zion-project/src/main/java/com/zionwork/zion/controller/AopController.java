package com.zionwork.zion.controller;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Zion Admin
 * Aop写日志
 */
@Component
@Aspect
public class AopController {
    private Logger logger = Logger.getLogger(AopController.class.getName());

    @Pointcut("execution(public * com.zionwork.zion.controller..*.*(..))")
    public void webLog() {
    }
    
    /**
     * @param joinPoint
     * @throws Throwable
     * 业务处理前切面操作
     */
    @Before("webLog()")
    public void doBefore(JoinPoint joinPoint) throws Throwable {
        // 接收到请求，记录请求内容
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        
        // 记录下请求内容
        logger.info("URL : " + request.getRequestURL().toString());
        logger.info("HTTP_METHOD : " + request.getMethod());
        logger.info("IP : " + request.getRemoteAddr());
        logger.info("CLASS_METHOD : " + joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName());
    }

    /**
     * @throws Throwable
     * 业务处理后切面操作
     */
    @AfterReturning(returning = "ret", pointcut = "webLog()")
    public void doAfterReturning() throws Throwable {
    	ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
    	HttpServletResponse response = attributes.getResponse();
    	logger.info("Return status :"+response.getStatus());
    }

}
