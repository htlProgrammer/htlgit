package com.zionwork.zion.entity;

//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;

/*@Entity
@Table*/
public class History {
	String deviceId;
    String deviceType;
    String deviceSignType;
    String currentStatusValue;
    String createTime;
    String deviceWorkStatus;
    String superUserId;
    //@Id
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getDeviceSignType() {
		return deviceSignType;
	}
	public void setDeviceSignType(String deviceSignType) {
		this.deviceSignType = deviceSignType;
	}
	public String getCurrentStatusValue() {
		return currentStatusValue;
	}
	public void setCurrentStatusValue(String currentStatusValue) {
		this.currentStatusValue = currentStatusValue;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getDeviceWorkStatus() {
		return deviceWorkStatus;
	}
	public void setDeviceWorkStatus(String deviceWorkStatus) {
		this.deviceWorkStatus = deviceWorkStatus;
	}
	
	public String getSuperUserId() {
		return superUserId;
	}
	public void setSuperUserId(String superUserId) {
		this.superUserId = superUserId;
	}
	@Override
	public String toString() {
		return "History [deviceId=" + deviceId + ", deviceType=" + deviceType + ", deviceSignType=" + deviceSignType
				+ ", currentStatusValue=" + currentStatusValue + ", createTime=" + createTime + ", deviceWorkStatus="
				+ deviceWorkStatus + ", superUserId=" + superUserId + "]";
	}

   
}
