package com.zionwork.zion.config;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Receiver {
    @JmsListener(destination = "my-destination")
    public void  receivedMessage(String message) throws InterruptedException{
    	Thread.currentThread().sleep(20000);
        System.out.println("接受到"+message);
    }
}

