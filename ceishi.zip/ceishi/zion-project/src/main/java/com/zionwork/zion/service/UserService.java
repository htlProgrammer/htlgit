package com.zionwork.zion.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zioncore.utils.VerifyUtils;
import com.zionwork.zion.entity.Superuser;
import com.zionwork.zion.entity.User;
import com.zionwork.zion.repository.UserRepository;


/**
 * @author Zion Admin
 * 用户信息的service层
 */
@Transactional
@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private SuperuserService superuserService;

    public UserRepository getUserRepository() {
        return userRepository;
    }

    /**
     * 查找某个用户信息
     * @param userId
     * @return
     */
    public User findUserByUserId(String userId) {
        return userRepository.findOne(userId);
    }

    // TODO @ymc: encapsulate all err msg
    /**
     * 添加用户信息
     * @param superUserId
     * @param userId
     * @param password
     * @param phoneNumber
     * @param realName
     * @param birthday
     * @return
     */
    public String addUser(String superUserId, String userId, String password, String phoneNumber, String realName,
                          String birthday) {
    	
    	//判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            return "The superuser does not exist";
        }
        //判断该添加用户名是否存在
        if (userRepository.findOne(userId) != null) {
            return "The user name already exists";
        }
        //判断生日的合法性
        if (!validateBirthday(birthday)) {
            return "Illegal birthday provided";
        }
        //判断手机号码是否被使用    添加用户时候没有判断用户手机号码是否合法 
        if (validatePhoneNumber(phoneNumber)) {
        	return "The phone number is already in use";
		}
        //添加用户
        User user = new User();
        user.setBirthday(birthday);
        //String 类型的时间格式如 1565854272
        user.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
        user.setPassword(password);
        user.setPhoneNumber(phoneNumber);
        user.setRealName(realName);
        user.setSuperUserId(superUserId);
        user.setUserId(userId);
        userRepository.save(user);
        return "success";
    }

    
    
    /**
     * 验证用户名是否存在
     * @param superUserId
     * @param userId
     * @return
     */
    public String validateUser(String superUserId, String userId) {
        Superuser findSuperUserBySuperUserId = superuserService.findSuperUserBySuperUserId(superUserId);
        //判断superuser是否存在
        if (findSuperUserBySuperUserId == null) {
            return "The superuser does not exist";
        }
        //判断用户名是否存在
        User findOne = userRepository.findOne(userId);
        if (findOne != null) {
            return "The user name already exists";
        }
        return "The user name doesn't exist";
    }

	/**
	 * 查找某个超级用户下的所有用户信息
	 * @param superUserId
	 * @return
	 */
	public List<User> findAllUserBySuperUserId(String superUserId) {
		User user=new User();
		user.setSuperUserId(superUserId);
		Example<User> example=Example.of(user);
		return userRepository.findAll(example);
	}
	
	/**
	 * 修改用户信息
	 * @param userId
	 * @param password
	 * @param phoneNumber
	 * @param realName
	 * @param birthday
	 * @return
	 */
	public String updateUser(String userId,String password,String phoneNumber,String realName,String birthday) {
		User findOne = userRepository.findOne(userId);
		//判断需要修改的用户是否存在
		if (findOne==null) {
			return "The user does not exist";
		}
		//判断修改内容是否为空        全部为空才返回   不能啥都不变。  有一个为空，则跳出
		if ((password==null||password=="")&&(phoneNumber==null||phoneNumber=="")&&(realName==null||realName=="")&&(birthday==null||birthday=="")) {
			return "Can't change nothing";
		}
		//判断是否需要改密码
		if (password!=null&&password!="") {
			findOne.setPassword(password);
		}
		// 判断是否需要改手机号码,并且判断手机号是否被使用    ，没有判断手机号是否合理
		if (phoneNumber!=null&&phoneNumber!=""&&!validatePhoneNumber(phoneNumber)) {
			findOne.setPhoneNumber(phoneNumber);
		}else if (phoneNumber!=null&&phoneNumber!=""&&validatePhoneNumber(phoneNumber)) {
			return "The phone number is already in use";
		}
		//判断是否改真名
		if (realName!=null&&realName!="") { //这个真名实现的感觉有问题。
			findOne.setRealName(realName);
		}
		//判断是否改生日，并且验证生日的合法性
		if (birthday!=null&&birthday!=""&&validateBirthday(birthday)) {
			findOne.setBirthday(birthday);
		}else if (birthday!=null&&birthday!=""&&!(validateBirthday(birthday))) {
			return "Illegal birthday provided";
		}
		//修改数据
		userRepository.save(findOne);
		return "success";
	}

	/**
	 * 通过手机号查找用户信息
	 * @param phoneNumber
	 * @return
	 */
	public User findUserIdByphoneNumber(String phoneNumber) {
		User user=new User();
		user.setPhoneNumber(phoneNumber);
		Example<User> example=Example.of(user);
		return userRepository.findOne(example);
	}

	/**
	 * 批量删除用户信息
	 * @param list
	 * @return
	 */
	public String deleteAllByAllUserId(List<Object> list) {
		List<User> entities=new ArrayList<>();
		for (Object object : list) {
			User user=new User();
			user.setUserId(object.toString());
			entities.add(user);
		}	
		userRepository.delete(entities);
		return "success";
	}

    /**
     * 判断生日的合法性
     * @param birthday
     * @return
     */
    private boolean validateBirthday(String birthday) {
        // Only accept birthday in the form of YYYY-MM-DD, return false if date is illegal
        // TODO: @ldc TO BE IMPLEMENTED
    	Pattern pattern = Pattern.compile("([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8])))");
    	Matcher matcher = pattern.matcher(birthday);
        return matcher.matches();
    }
    
    //如果存在这个号码就返回true.   号码判断缺少一个号码是否合理。
    private boolean validatePhoneNumber(String phoneNumber) {
    	boolean result=true;
    	User user=new User();
		user.setPhoneNumber(phoneNumber);
		Example<User> example=Example.of(user);
		if (userRepository.findOne(example)==null) {
			result=false;
		}
    	return result;
    }
    
    
	public String addUser1(String superUserId, String userId, String password, String phoneNumber, String realName,
			String birthday) {
		//判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            return "The superuser does not exist";
        }
        //判断该添加用户名是否存在
        if (userRepository.findOne(userId) != null) {
            return "The user name already exists";
        }
        //判断生日的合法性
        if (!validateBirthday(birthday)) {
            return "Illegal birthday provided";
        }
      
        //添加用户时候没有判断用户手机号码是否合法   修改了相关代码
        if(!validatePhoneNumberAble(phoneNumber)) { //合法
        	return "The phone number is  unavailable";
        }
        
        
        //判断手机号码是否被使用   
        if (validatePhoneNumber(phoneNumber)) {
        	return "The phone number is already in use";
		}
        //添加用户
        User user = new User();
        user.setBirthday(birthday);
        //String 类型的时间格式如 1565854272
        user.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
        user.setPassword(password);
        user.setPhoneNumber(phoneNumber);
        user.setRealName(realName);
        user.setSuperUserId(superUserId);
        user.setUserId(userId);
        userRepository.save(user);
        return "success";
	}
	
	//判断手机号码是不是可用的
	private boolean validatePhoneNumberAble(String phoneNumber) {
		// TODO Auto-generated method stub
		if(VerifyUtils.isMobile(phoneNumber)) {//可用
			return true;
		} 
		return false;
	}
}
