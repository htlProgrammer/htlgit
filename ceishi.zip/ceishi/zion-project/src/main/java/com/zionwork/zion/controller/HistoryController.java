package com.zionwork.zion.controller;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.History;
import com.zionwork.zion.service.DeviceService;
import com.zionwork.zion.service.HistoryService;
import com.zionwork.zion.service.MessageService;
import com.zionwork.zion.service.SuperuserService;

@Controller
@RequestMapping("/zion/History")
public class HistoryController extends BaseController {

	@Autowired
	private MessageService messageService;

	@Autowired
	private HistoryService historyService;

	@Autowired
	private DeviceService deviceService;

	@Autowired
	private SuperuserService superuserService;
	
	

	/**
	 * 批量插入历史数据
	 * @param req
	 * @param resp
	 * @throws InterruptedException
	 */
	@RequestMapping("/pushDateToHistory")
	@ResponseBody
	public void pushDateToHistory(HttpServletRequest req, HttpServletResponse resp) throws InterruptedException {
		//读取HttpServletRequest流
		JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req,resp);
		//判断是否传输信息为空
		if (readHttpServletRequestIO==null) {
			printJson(resp,req, 400, "Params cannot be empty","String");
			return;
		}
		List<History> list;
		try {
			//数据转化
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString(), History.class);
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}
		Map<String, History> map = new HashMap<>();
		//筛选出每一个设备的最新信息，并且把警报和警报解除信息立即更新到数据库
		for (History history : list) {
			//判断设备id是否为空或空字符
			if (history.getDeviceId() == null || Objects.equals(history.getDeviceId(), "")) {
				printJson(resp,req, 400, "Missing deviceId","String");
				return;
			}
			//处理紧急数据，更新到数据库
			if ("Alarm".equals(history.getCurrentStatusValue()) || "AlarmRelease".equals(history.getCurrentStatusValue())) {
				messageService.updateOneMessageFlush(history.getDeviceId(), history.getDeviceType(),
						history.getDeviceSignType(), history.getCurrentStatusValue(), history.getCreateTime(),
						history.getDeviceWorkStatus(),history.getSuperUserId());
				continue;
			}
			//设备查重处理，和筛选最新信息
			if (!map.containsKey(history.getDeviceId())) {
				map.put(history.getDeviceId(), history);
			} else if (map.containsKey(history.getDeviceId())
					&& history.getCreateTime().compareTo(map.get(history.getDeviceId()).getCreateTime()) > 0) {
				map.put(history.getDeviceId(), history);
			}
		}
		try {
			//数据更新
			String pushDateToHistory = historyService.pushDateToHistory(map, list);
			if (pushDateToHistory.equals("success")) {
				printJson(resp,req, 200, pushDateToHistory,"String");
			} else {
				printJson(resp,req, 500, pushDateToHistory,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}

	}

	/**
	 * 查询某个设备某段时间的信息
	 *
	 * @param deviceId
	 * @param startTime
	 * @param endTime
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findAllInfoByDeviceAndTimeFromHistory")
	@ResponseBody
	public void findAllInfoByDeviceAndTimeFromHistory(HttpServletRequest req, HttpServletResponse resp) {
		String deviceId = req.getParameter("deviceId");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, deviceId, superUserId)) {
			return;
		}
		//判断设备是否存在，并且判断设备是否属于该superuser
		if (deviceService.findDeviceByDeviceId(deviceId) == null) {
			printJson(resp,req, 400, "The device does not exist","String");
			return;
		}else if (deviceService.findDeviceByDeviceId(deviceId).getSuperUserId()==null||!superUserId.equals(deviceService.findDeviceByDeviceId(deviceId).getSuperUserId())) {
			printJson(resp,req, 400, "This device does not belong to the superuser","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllInfoByDeviceAndTimeFromHistory = historyService
					.findAllInfoByDeviceAndTimeFromHistory(superUserId, deviceId, startTime, endTime);
			if (findAllInfoByDeviceAndTimeFromHistory.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceId and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllInfoByDeviceAndTimeFromHistory,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}

	}

	/**
	 * 查询某个超级用户某段时间内的所有设备信息
	 *
	 * @param superUserId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllDeviceInfoBySuperUserAndTimeFromHistory")
	@ResponseBody
	public void findAllDeviceInfoBySuperUserAndTimeFromHistory(HttpServletRequest req, HttpServletResponse resp) {
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllDeviceInfoBySuperUserAndTimeFromHistory = historyService
					.findAllDeviceInfoBySuperUserAndTimeFromHistory(superUserId, startTime, endTime);
			if (findAllDeviceInfoBySuperUserAndTimeFromHistory.size()==0) {
				printJson(resp,req, 400, "Find device's info by superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceInfoBySuperUserAndTimeFromHistory,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个超级用户某段时间内的某种类型设备的信息
	 *
	 * @param superUserId
	 * @param deviceType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllInfoBySuperUserDeviceTypeAndTimeFromHistory")
	@ResponseBody
	public void findAllInfoBySuperUserDeviceTypeAndTimeFromHistory(HttpServletRequest req, HttpServletResponse resp) {
		String deviceType = req.getParameter("deviceType");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, deviceType, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllInfoBySuperUserDeviceTypeAndTimeFromHistory = historyService
					.findAllInfoBySuperUserDeviceTypeAndTimeFromHistory(superUserId, deviceType, startTime, endTime);
			if (findAllInfoBySuperUserDeviceTypeAndTimeFromHistory.size()==0) {
				printJson(resp,req, 400, "Find device's info by superuserId and deviceType does not exist","String");
			} else {
				printJson(resp, req,200, findAllInfoBySuperUserDeviceTypeAndTimeFromHistory,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}

	}
	
	
	
	
	/**
	 * 按照时间和对应数据表进行恢复数据
	 * @param req
	 * @param resp
	 */
	@RequestMapping("/restoreHistory")
	@ResponseBody
	public void restoreHistory(HttpServletRequest req, HttpServletResponse resp) {
		try {
			String key = req.getParameter("key");
			String bucketName=req.getParameter("bucketName");
			String mongoTableName=req.getParameter("mongoTableName");
			//判断参数是否为空
			if (!validateParams(resp,req, key, bucketName,mongoTableName)) {
				return;
			}
			Pattern pattern = Pattern.compile("([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})-(((0[13578]|1[02])-(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)-(0[1-9]|[12][0-9]|30))|(02-(0[1-9]|[1][0-9]|2[0-8])))");
	    	Matcher matcher = pattern.matcher(key);
	    	if (!matcher.matches()) {
	    		printJson(resp,req, 400, "Wrong time format", "String");
			}
	    	key=key+".txt";
	    	String restoreHistory = historyService.restoreHistory(bucketName,key,mongoTableName);
	    	printJson(resp, req,200, restoreHistory,"String");
		} catch (Exception e) {
			// TODO: handle exception
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
		
	}
}