package com.zionwork.zion.nosqlentity;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "Historytable")
public class DyHistory {	
	String deviceId;
    String deviceType;
    String deviceSignType;
    String currentStatusValue;
    String createTime;
    String deviceWorkStatus;
    String superUserId;
    
    @DynamoDBAttribute(attributeName = "deviceId")
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	@DynamoDBAttribute(attributeName = "deviceType")
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	@DynamoDBAttribute(attributeName = "deviceSignType")
	public String getDeviceSignType() {
		return deviceSignType;
	}
	public void setDeviceSignType(String deviceSignType) {
		this.deviceSignType = deviceSignType;
	}
	@DynamoDBAttribute(attributeName = "currentStatusValue")
	public String getCurrentStatusValue() {
		return currentStatusValue;
	}
	public void setCurrentStatusValue(String currentStatusValue) {
		this.currentStatusValue = currentStatusValue;
	}
	@DynamoDBRangeKey(attributeName = "createTime")
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@DynamoDBAttribute(attributeName = "deviceWorkStatus")
	public String getDeviceWorkStatus() {
		return deviceWorkStatus;
	}
	public void setDeviceWorkStatus(String deviceWorkStatus) {
		this.deviceWorkStatus = deviceWorkStatus;
	}
	@DynamoDBHashKey(attributeName = "superUserId")
	public String getSuperUserId() {
		return superUserId;
	}
	public void setSuperUserId(String superUserId) {
		this.superUserId = superUserId;
	}
	@Override
	public String toString() {
		return "History [deviceId=" + deviceId + ", deviceType=" + deviceType + ", deviceSignType=" + deviceSignType
				+ ", currentStatusValue=" + currentStatusValue + ", createTime=" + createTime + ", deviceWorkStatus="
				+ deviceWorkStatus + ", superUserId=" + superUserId + "]";
	}


}
