package com.zionwork.zion.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.zionwork.zion.entity.Permissions;
import com.zionwork.zion.repository.PermissionsRepository;


/**
 * @author Zion Admin
 * 权限信息的service层
 */
@Transactional
@Service
public class PermissionsService {
    @Autowired
    private PermissionsRepository permissionsRepository;
    @Autowired
    private UserService userService;

    public PermissionsRepository getPermissionsRepository() {
        return permissionsRepository;
    }

    /**
     * 添加权限
     * @param userId
     * @param targetId
     * @param relationType
     * @param relationValue
     * @param superUserId
     * @param targetType
     * @return
     */
    public String addNewPermission(String userId, String targetId, String relationType, String relationValue,
			String superUserId,String targetType) {	
        try {
        	// Reject permission addition if user does not exist
            if (userService.findUserByUserId(userId) == null) {
                return "Requested user does not exist";
            }else if (!userService.findUserByUserId(userId).getSuperUserId().equals(superUserId)) {
            	return "The user does not belong to this superuser";
    		}
            //Device findDeviceByDeviceId = deviceService.findDeviceByDeviceId(targetId);
            // TODO @ymc: target v.s. device
           /* if (findDeviceByDeviceId==null) {
                return "Requested target does not exist";
            }*/
            
            Permissions permission = new Permissions();
            permission.setUserId(userId);
            permission.setTargetId(targetId);
            permission.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
            permission.setRelationType(relationType);
            permission.setRelationValue(relationValue);
            permission.setSuperUserId(superUserId);
            permission.setTargetType(targetType);
            permissionsRepository.save(permission);
            return "success";
			
		} catch (Exception e) {
			// TODO: handle exception
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly(); //try-catch 之下的事务回滚。
			return e.toString();
		}
    }


    /**
     * 查找某个用户的权限
     * @param userId
     * @return
     */
    public List<Permissions> findPermissionByUserId(String userId) {
        Permissions permission = new Permissions();
        permission.setUserId(userId);
        Example<Permissions> example = Example.of(permission);
        return permissionsRepository.findAll(example);
    }

	/**
	 * 根据关系类型和关系值查找某个用户对于某个设备的权限
	 * @param userId
	 * @param targetId
	 * @param relationType
	 * @param relationValue
	 * @return
	 */
	public String updatePermission(String userId, String targetId, String relationType, String relationValue) {
        Permissions permission = new Permissions();
        permission.setUserId(userId);
        permission.setTargetId(targetId);
        permission.setRelationType(relationType);
        Example<Permissions> example = Example.of(permission);
        Permissions findOne = permissionsRepository.findOne(example);
        if (findOne==null) {
			return "There is no permission relationship between this user and this device, so it cannot be modified";
		}
        permissionsRepository.updatePermission(userId,targetId,relationType,relationValue);
        return "success";
	}

	/**
	 * 根据关系类型和关系值查找某个超级用户下某个用户对于某个设备的权限
	 * @param userId
	 * @param targetId
	 * @param relationType
	 * @param relationValue
	 * @param superUserId
	 * @return
	 */
	public Permissions findPermissionByUserIdAndDeviceIdAndValue(String userId, String targetId, String relationType,
			String relationValue,String superUserId) {
		Permissions permission = new Permissions();
        permission.setUserId(userId);
        permission.setTargetId(targetId);
        permission.setRelationType(relationType);
        permission.setRelationValue(relationValue);
        permission.setSuperUserId(superUserId);
        Example<Permissions> example = Example.of(permission);
        return permissionsRepository.findOne(example);
	}

	/**
	 * 根据关系类型和关系值查找某个超级用户下某个用户所有权限信息
	 * @param userId
	 * @param relationType
	 * @param relationValue
	 * @param superUserId
	 * @return
	 */
	public List<Permissions> findPermissionByUserIdAndRelation(String userId, String relationType, String relationValue,
			String superUserId) {
		Permissions permission = new Permissions();
        permission.setUserId(userId);
        permission.setRelationType(relationType);
        permission.setRelationValue(relationValue);
        permission.setSuperUserId(superUserId);
        Example<Permissions> example = Example.of(permission);
        return permissionsRepository.findAll(example);
	}

	/**
	 * 查找某个超级用户下和某个设备相关的所有权限信息
	 * @param superUserId
	 * @param targetId
	 * @return
	 */
	public List<Permissions> findPermissionBysuperUserId(String superUserId,String targetId) {
		Permissions permission = new Permissions();
        permission.setSuperUserId(superUserId);
        permission.setTargetId(targetId);
        Example<Permissions> example = Example.of(permission);
        return permissionsRepository.findAll(example);
	}

	/**
	 * 批量添加权限信息
	 * @param list
	 * @return
	 */
	public String pushPermissionInfo(List<Permissions> list) {	
		try {
			for(int i=0;i<list.size();i++) {
				Permissions permissions=list.get(i);
				permissions.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
				list.set(i, permissions); //set 是属于替换操作的。 
			}
	
			permissionsRepository.save(list);
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly(); //在service 层已经出现了transaction，再次使用这个的目的。
			return e.toString();
		}
	}

	/**
	 * 批量删除权限信息
	 * @param list
	 * @return
	 */
	public String deleteAllPermissionsByAllUserId(List<Object> list) {	
		try {
			for (Object userId : list) {
				permissionsRepository.deleteByUserId(userId.toString());
			}		
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 删除某用户的权限信息
	 * @param id
	 */
	public void delete(String id) {
		try {
			Permissions permissions=new Permissions();
			permissions.setUserId(id);
			List<Permissions> list=new ArrayList<>();
			list.add(permissions);
			permissionsRepository.deleteInBatch(list);
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
	}
}