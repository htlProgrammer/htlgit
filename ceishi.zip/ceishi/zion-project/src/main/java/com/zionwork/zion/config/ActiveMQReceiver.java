package com.zionwork.zion.config;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.MapMessage;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.mongodb.MongoBulkWriteException;
import com.zioncore.utils.PropertiesUtil;
import com.zionwork.zion.test.RestoreHistoryData;

@Component
public class ActiveMQReceiver {
	/**
	 * 处理名为restore-history的消息队列里面的消息
	 * @param message
	 * @throws JMSException
	 */
	@JmsListener(destination = "restore-history")
    public void  receivedMessage(MapMessage message) throws JMSException{
		String restoreHistoryDataByTime = null;
		try {
			String property = PropertiesUtil.getProperty("spring.data.mongodb.local.path");
			restoreHistoryDataByTime = RestoreHistoryData.restoreHistoryDataByTime(message.getString("bucketName"), message.getString("key"), message.getString("mongoTableName"), property+message.getString("key"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IO流异常");
			e.printStackTrace();
		}catch (MongoBulkWriteException e) {
			System.out.println("数据可能已经存在，批量数据恢复异常");
			e.printStackTrace();
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("其他异常");
			e.printStackTrace();
		}
		System.out.println(restoreHistoryDataByTime);	
    }
}
