package com.zionwork.zion.controller;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Permissions;
import com.zionwork.zion.service.PermissionsService;
import com.zionwork.zion.service.SuperuserService;
import com.zionwork.zion.service.UserService;


/**
 * @author Zion Admin
 * 权限接口
 */
@Controller
@RequestMapping("/zion/Permissions")
public class PermissionsController extends BaseController {
    @Autowired
    private PermissionsService permissionsService;
    @Autowired
    private UserService userService;
    @Autowired
    private SuperuserService superuserService;
    /**
     * 添加某个用户和某个设备的权限关系
     *
     * @param userId
     * @param targetId
     * @param relationType
     * @param relationValue
     * @param superUserId
     * @param targetType
     * @return
     */
    @RequestMapping("/addPermission")
    @ResponseBody
    public void addPermission(HttpServletRequest req, HttpServletResponse resp) {
        String userId = req.getParameter("userId");
        String targetId = req.getParameter("targetId");
        String relationType = req.getParameter("relationType");
        String relationValue = req.getParameter("relationValue");
        String superUserId = req.getParameter("superUserId");
        String targetType = req.getParameter("targetType");
        //判断主要参数是否为空
        if (!validateParams(resp, req,userId,superUserId,targetId,relationType,relationValue)) {
            return;
        }
        try {
        	//判断是否为空，为空用"—"代替
        	targetType=changeNullParam(targetType);  
        	//插入数据
            String tryAddPermission = permissionsService.addNewPermission(userId,targetId,relationType,relationValue,superUserId,targetType);
            if (tryAddPermission == "success") {
                printJson(resp,req, 200, tryAddPermission, "String");
            }
            else {
                printJson(resp,req, 400, tryAddPermission, "String");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    /**
	 * 批量添加权限
	 *
	 * @param date
	 * @return
	 */
	@RequestMapping("/pushPermissionInfo")
	@ResponseBody
	public void pushPermissionInfo(HttpServletRequest req, HttpServletResponse resp) {
		//读取HttpServletRequest流
		JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req, resp);   //最主要的是这一步的数据不了解。
		//判断HttpServletRequest流是否为空
		if (readHttpServletRequestIO == null) {
			printJson(resp,req, 400, "Params cannot be empty","String");
			return;
		}
		List<Permissions> list=new ArrayList<Permissions>();
		try {
			//数据转化
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString(), Permissions.class);
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}
		//判断权限信息中是否有userId为空  
		for (Permissions permissions : list) {
			if (permissions.getUserId()==null||permissions.getUserId()=="") {
				printJson(resp,req, 400, "There is a permissions in the data that lacks a userid","String");
				return;
			}
		}
		
		
		try {
			//插入数据
			String pushOperationsInfo = permissionsService.pushPermissionInfo(list);
			if (pushOperationsInfo.equals("success")) {
				printJson(resp, req,200, pushOperationsInfo,"String");
			} else {
				printJson(resp,req, 500, pushOperationsInfo,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
	

    /**
     * 修改某个用户和某个设备的权限关系
     *
     * @param userId
     * @param targetId
     * @param relationType
     * @param relationValue
     * @return
     */
    @RequestMapping("/updatePermission")
    @ResponseBody
    public void updatePermission(HttpServletRequest req, HttpServletResponse resp) {
    	 String userId = req.getParameter("userId");
         String targetId = req.getParameter("targetId");
         String relationType = req.getParameter("relationType");
         String relationValue = req.getParameter("relationValue");
         //判断参数是否为空
         if (!validateParams(resp,req, userId,targetId,relationType,relationValue)) {
             return;
         }
         try {
        	 //修改数据
             String tryUpdatePermission = permissionsService.updatePermission(userId,targetId,relationType,relationValue);
             if (tryUpdatePermission == "success") {
                 printJson(resp, req,200, tryUpdatePermission, "String");
             }
             else {
                 printJson(resp, req,400, tryUpdatePermission, "String");
             }
             return;
         } catch (Exception e) {
        	 //处理异常，抛出异常
             printJson(resp,req, 500, e.toString(), "String");
             logger.error("Server exception", e);
         }
    }

    /**
     * 通过用户id和设备id和权限关系以及设置权限查找信息
     *
     * @param userId
     * @param targetId
     * @param relationType
     * @param relationValue
     * @param superUserId
     * @return
     */
    @RequestMapping("/findPermissionByUserIdAndDeviceIdAndValue")
    @ResponseBody
    public void findPermissionByUserIdAndDeviceIdAndValue(HttpServletRequest req, HttpServletResponse resp) {
    	String userId = req.getParameter("userId");
        String targetId = req.getParameter("targetId");
        String relationType = req.getParameter("relationType");
        String relationValue = req.getParameter("relationValue");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp,req, userId,targetId,relationType,relationValue,superUserId)) {
            return;
        }
        /*if (deviceService.findDeviceByDeviceId(targetId)==null) {
			printJson(resp,req, 400, "The target does not exist", "String");
			return;
		}*/
        //判断userId是否存在
        if (userService.findUserByUserId(userId)==null) {
			printJson(resp,req, 400, "The user does not exist", "String");
			return;
		}
        try {
        	//查找数据
            Permissions findPermissionByUserIdAndDeviceIdAndValue = permissionsService.findPermissionByUserIdAndDeviceIdAndValue(userId,targetId,relationType,relationValue,superUserId);
            if (findPermissionByUserIdAndDeviceIdAndValue==null) {
                printJson(resp, req,400, "This user and this target have no permission relationship data", "String");
            }
            else {
                printJson(resp,req, 200, findPermissionByUserIdAndDeviceIdAndValue, "Object");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 通过用户和设备的关系类型查询某个超级用户下的权限信息
     *
     * @param userId
     * @param relationType
     * @param relationValue
     * @param superUserId
     * @return
     */
    @RequestMapping("/findPermissionByUserIdAndRelation")
    @ResponseBody
    public void findPermissionByUserIdAndRelation(HttpServletRequest req, HttpServletResponse resp) {
    	String userId = req.getParameter("userId");
        String relationType = req.getParameter("relationType");
        String relationValue = req.getParameter("relationValue");
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp,req, userId,relationType,relationValue,superUserId)) {
            return;
        }
        //判断user是否存在，并且判断user是否属于该superuser
        if (userService.findUserByUserId(userId)==null) {
			printJson(resp,req, 400, "The user does not exist", "String");
			return;
		}else if (userService.findUserByUserId(userId).getSuperUserId()==null||!superUserId.equals(userService.findUserByUserId(userId).getSuperUserId())) {
			printJson(resp,req, 400, "This user does not belong to the superuser", "String");
			return;
		}
        try {
        	//查找数据
            List<Permissions> findPermissionByUserIdAndRelation = permissionsService.findPermissionByUserIdAndRelation(userId,relationType,relationValue,superUserId);
            if (findPermissionByUserIdAndRelation.size()==0) {
                printJson(resp,req, 400, "The user's permission information could not be found", "String");
            }
            else {
                printJson(resp,req, 200, findPermissionByUserIdAndRelation, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp, req,500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 通过用户和设备以及权限查询某个超级用户下的权限信息
     *
     * @param userId
     * @return
     */
    @RequestMapping("/findPermissionByUserId")
    @ResponseBody
    public void findPermissionByUserId(HttpServletRequest req, HttpServletResponse resp) {
        String userId = req.getParameter("userId");
        //判断参数是否为空
        if (!validateParams(resp,req, userId)) {
            return;
        }
        try {
        	//查找数据
            List<Permissions> findPermissionByUserId = permissionsService.findPermissionByUserId(userId);
            if (findPermissionByUserId.size() == 0) {
                printJson(resp,req, 400, "The user's permission information could not be found", "String");
            } else {
                printJson(resp,req, 200, findPermissionByUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    
    /**
     * 通过用户和设备以及权限查询某个超级用户下的权限信息
     *
     * @param superUserId
     * @param targetId
     * @return
     */
    @RequestMapping("/findPermissionBysuperUserId")
    @ResponseBody
    public void findPermissionBysuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String superUserId = req.getParameter("superUserId");
        String targetId = req.getParameter("targetId");
        //判断参数是否为空
        if (!validateParams(resp,req, superUserId,targetId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId)==null) {
			printJson(resp,req, 400, "The superuser does not exist", "String");
			return;
		}
        try {
        	//查找数据
            List<Permissions> findPermissionBysuperUserId = permissionsService.findPermissionBysuperUserId(superUserId,targetId);
            if (findPermissionBysuperUserId.size() == 0) {
                printJson(resp,req, 400, "The permission information could not be found by superuser", "String");
            } else {
                printJson(resp,req, 200, findPermissionBysuperUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//处理异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    

    /**
     *批量删除权限通过userId
     *
     * @param phoneNumber
     * @return userId
     */
    @RequestMapping("/deleteAllPermissionsByAllUserId")
    @ResponseBody
    public void deleteAllPermissionsByAllUserId(HttpServletRequest req, HttpServletResponse resp) {
    	//读取HttpServletRequest流
    	JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req, resp);
    	//判断HttpServletRequest流是否为空
		if (readHttpServletRequestIO == null) {
			printJson(resp,req, 400, "Params cannot be empty","String");
			return;
		}
		List<Object> list=new ArrayList<Object>();
		try {
			//数据转化
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString());
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}
        try {
        	//删除数据
            String deleteAllPermissionsByAllUserId = permissionsService.deleteAllPermissionsByAllUserId(list);
            if (deleteAllPermissionsByAllUserId.equals("success")) {
                
                printJson(resp, req,200, deleteAllPermissionsByAllUserId, "String");
            } else {
            	printJson(resp, req,400, deleteAllPermissionsByAllUserId, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    
  
}