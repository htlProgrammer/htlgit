package com.zionwork.zion.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;


import javax.persistence.Id;
import javax.persistence.IdClass;

/**
 * permissions 实体类
 * Fri Apr 12 10:34:05 CST 2019
 * @Zion
 */ 
@Entity
@Table(name="permissions")
@IdClass(Permissions.class)
public class Permissions implements Serializable { //这个是不是可以考虑一下五表的权限？
	private static final long serialVersionUID = 1L;
	private String userId; //用户id
	private String targetId; //空气检测 和 烟感
	private String targetType; //目标类型   System 系统
	private String relationType;//关系类型 ：管理员  历史  维护  视图  专用？
	private String relationValue;//关系值     yes all ok 
	private String createTime;//创建世界
	private String superUserId;//超级用户

	@Id
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId=userId;
	}
	@Id
	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId=targetId;
	}

	public String getTargetType() {
		return targetType;
	}

	public void setTargetType(String targetType) {
		this.targetType=targetType;
	}
	@Id
	public String getRelationType() {
		return relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType=relationType;
	}

	public String getRelationValue() {
		return relationValue;
	}

	public void setRelationValue(String relationValue) {
		this.relationValue=relationValue;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime=createTime;
	}

	public String getSuperUserId() {
		return superUserId;
	}

	public void setSuperUserId(String superUserId) {
		this.superUserId=superUserId;
	}

}

