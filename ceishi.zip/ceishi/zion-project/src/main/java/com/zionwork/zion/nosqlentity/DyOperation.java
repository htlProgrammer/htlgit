package com.zionwork.zion.nosqlentity;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "Operationtable")
public class DyOperation {
	    String operateId;
	    String targetId;
	    String operateUser;
	    String operateType;
	    String operateReason;
	    String operateResult;
	    String createTime;
	    String targetType;
	    String superUserId;
	    
	    @DynamoDBAttribute(attributeName = "operateId")
		public String getOperateId() {
			return operateId;
		}
		public void setOperateId(String operateId) {
			this.operateId = operateId;
		}
		@DynamoDBAttribute(attributeName = "targetId")
		public String getTargetId() {
			return targetId;
		}
		public void setTargetId(String targetId) {
			this.targetId = targetId;
		}
		@DynamoDBAttribute(attributeName = "operateUser")
		public String getOperateUser() {
			return operateUser;
		}
		public void setOperateUser(String operateUser) {
			this.operateUser = operateUser;
		}
		@DynamoDBAttribute(attributeName = "operateType")
		public String getOperateType() {
			return operateType;
		}
		public void setOperateType(String operateType) {
			this.operateType = operateType;
		}
		@DynamoDBAttribute(attributeName = "operateReason")
		public String getOperateReason() {
			return operateReason;
		}
		public void setOperateReason(String operateReason) {
			this.operateReason = operateReason;
		}
		@DynamoDBAttribute(attributeName = "operateResult")
		public String getOperateResult() {
			return operateResult;
		}
		public void setOperateResult(String operateResult) {
			this.operateResult = operateResult;
		}
		@DynamoDBRangeKey(attributeName = "createTime")
		public String getCreateTime() {
			return createTime;
		}
		public void setCreateTime(String createTime) {
			this.createTime = createTime;
		}
		@DynamoDBAttribute(attributeName = "targetType")
		public String getTargetType() {
			return targetType;
		}
		public void setTargetType(String targetType) {
			this.targetType = targetType;
		}
		@DynamoDBHashKey(attributeName = "superUserId")
		public String getSuperUserId() {
			return superUserId;
		}
		public void setSuperUserId(String superUserId) {
			this.superUserId = superUserId;
		}
	    
	
}
