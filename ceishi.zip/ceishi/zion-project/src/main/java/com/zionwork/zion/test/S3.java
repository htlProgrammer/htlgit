package com.zionwork.zion.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.dynamodbv2.datamodeling.S3ClientCache;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.Owner;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class S3 {
	public static void main(String[] args) {
		BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAOPZTIQPFMP5KZB2Q", "bIUya8PJslwoGaSnl+Vjqi5hLvJjvoJ/VPd5RRk/");
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
		                        .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
		                        .build();

		 /*   try {
		       Bucket b = s3Client.createBucket("historytable");
		    } catch (AmazonS3Exception e) {
		        System.err.println(e.getErrorMessage());
		    }*/
		
		/*try {
			s3Client.putObject("historytable", "test2", new File("d:\\workbooks.txt"));
		} catch (AmazonServiceException e) {
		    System.err.println(e.getErrorMessage());
		    System.exit(1);
		}*/
/*		try {
		    S3Object o = s3Client.getObject("historytable", "test");
		    S3ObjectInputStream s3is = o.getObjectContent();
		    FileOutputStream fos = new FileOutputStream(new File("d:\\test.txt"));
		    byte[] read_buf = new byte[1024];
		    int read_len = 0;
		    while ((read_len = s3is.read(read_buf)) > 0) {
		        fos.write(read_buf, 0, read_len);
		    }
		    s3is.close();
		    fos.close();
		} catch (AmazonServiceException e) {
		    System.err.println(e.getErrorMessage());
		    System.exit(1);
		} catch (FileNotFoundException e) {
		    System.err.println(e.getMessage());
		    System.exit(1);
		} catch (IOException e) {
		    System.err.println(e.getMessage());
		    System.exit(1);
		}
		*/
		
		/*try {
		    s3Client.deleteBucket("historytable");
		} catch (AmazonServiceException e) {
		    System.err.println(e.getErrorMessage());
		    System.exit(1);
		}*/
		/*List<Bucket> buckets = s3Client.listBuckets();
		System.out.println("Your Amazon S3 buckets are:");
		for (Bucket b : buckets) {
		    System.out.println("* " + b.getName());
		}*/
		
		ListObjectsV2Result result = s3Client.listObjectsV2("historytable");
		List<S3ObjectSummary> objects = result.getObjectSummaries();
		for (S3ObjectSummary os: objects) {
		    System.out.println("* " + os.getKey());
		}

		//RestoreHistoryData.restoreHistoryDataByTime("historytable", "2019-07-10.txt","Historytable", "d:\\zion\\2019-07-10.txt");
	}
}
