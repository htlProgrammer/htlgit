package com.zionwork.zion.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

/**
 * message 实体类
 * Fri Apr 12 10:34:05 CST 2019
 * @Zion
 */ 
@Entity
@Table(name="message")
public class Message implements Serializable {
	private static final long serialVersionUID = 1L;
	private String deviceId;
	private String deviceType;
	private String deviceSignType;
	private String currentStatusValue;
	private String areaId;
	private String deviceAddress;
	private String userId;
	private String superUserId;
	private String createTime;
	private String deviceWorkStatus;

	@Id
	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId=deviceId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType=deviceType;
	}

	public String getDeviceSignType() {
		return deviceSignType;
	}

	public void setDeviceSignType(String deviceSignType) {
		this.deviceSignType=deviceSignType;
	}

	public String getCurrentStatusValue() {
		return currentStatusValue;
	}

	public void setCurrentStatusValue(String currentStatusValue) {
		this.currentStatusValue=currentStatusValue;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId=areaId;
	}

	public String getDeviceAddress() {
		return deviceAddress;
	}

	public void setDeviceAddress(String deviceAddress) {
		this.deviceAddress=deviceAddress;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId=userId;
	}

	public String getSuperUserId() {
		return superUserId;
	}

	public void setSuperUserId(String superUserId) {
		this.superUserId=superUserId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime=createTime;
	}

	public String getDeviceWorkStatus() {
		return deviceWorkStatus;
	}

	public void setDeviceWorkStatus(String deviceWorkStatus) {
		this.deviceWorkStatus=deviceWorkStatus;
	}

}

