package com.zionwork.zion.service;


import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.zionwork.zion.entity.Area;
import com.zionwork.zion.entity.Superuser;
import com.zionwork.zion.entity.User;
import com.zionwork.zion.repository.AreaRepository;


/**
 * @author Zion Admin
 * 区域信息的service层
 */
@Transactional
@Service
public class AreaService {
    @Autowired
    private AreaRepository areaRepository;
    @Autowired
    private UserService userService;
    @Autowired
    private SuperuserService superuserService;

    public AreaRepository getAreaRepository() {
        return areaRepository;
    }
	/**
	 * 添加区域
	 * @param areaName
	 * @param length
	 * @param width
	 * @param height
	 * @param userId
	 * @param superUserId
	 * @param areaPictureUrl
	 * @return
	 */
	public String addArea(String areaName, String length, String width, String height, String userId,
			String superUserId,String areaPictureUrl) {
		//判断高度是否有数值
		if (height==null||height=="") {
			height="0";
		}
		//宽和高进行转化，转化成浮点数
		if (!validate(length)||!validate(width)) {
			return "The length or width does not match the format";
		}
		//判断区域是否已经存在，通过区域图片判断
		/*Area validateUrl=new Area();
		validateUrl.setAreaPictureUrl(areaPictureUrl);
		Example<Area> example=Example.of(validateUrl);
		List<Area> findAll = areaRepository.findAll(example);
		if (findAll.size()!=0) {
			return "This area map already exists";
		}*/
		//如果字段为空或者空字符转化为"-"
		userId=nullEmpty(userId);
		superUserId=nullEmpty(superUserId);
		//添加区域
		Area area=new Area();
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		String areaSize=length+"x"+width+"x"+height;
		area.setAreaId(uuid);
		area.setAreaName(areaName);
		area.setAreaPictureUrl(areaPictureUrl);
		area.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
		area.setSuperUserId(superUserId);
		area.setUserId(userId);
		area.setAreaSize(areaSize);
		areaRepository.save(area);
		//添加成功，返回区域id
		return uuid;
	}
	

	/**
	 * 根据区域id查询区域信息
	 * @param areaId
	 * @return
	 */
	public Area findAreaInfoByAreaId(String areaId) {
		return areaRepository.findOne(areaId);
	}

	
	/**
	 * 更新区域大小信息
	 * @param areaId
	 * @param length
	 * @param width
	 * @param height
	 * @return
	 */
	public String updateAreaSize(String areaId, String length, String width, String height) {
		try {
			//判断高度是否有数值
			if (height==null||height=="") {
				height="0";
			}
			//宽和高进行转化，转化成浮点数
			if (!validate(length)||!validate(width)) {
				return "The length or width does not match the format";
			}
			//更新数据
			String areaSize=length+"x"+width+"x"+height;
			int updateAreaSize = areaRepository.updateAreaSize(areaId,areaSize);
			if (updateAreaSize!=0) {
				return "success";
			}
			//数据更新失败返回fail
			return "fail";
		} catch (Exception e) {
			// TODO: handle exception
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 更新区域数据
	 * @param areaId
	 * @param areaName
	 * @param length
	 * @param width
	 * @param height
	 * @param userId
	 * @param superUserId
	 * @param areaPictureUrl
	 * @return
	 */
	public String updateArea(String areaId, String areaName, String length, String width, String height, String userId,
			String superUserId, String areaPictureUrl) {
		try {
			//判断高度是否有数值
			if (height==null||height=="") {
				height="0";
			}
			//判断superuser是否存在
			Superuser findSuperUserBySuperUserId = superuserService.findSuperUserBySuperUserId(superUserId);
			if (findSuperUserBySuperUserId==null) {
				return "the superuser does not exist";
			}
			//判断user是否存在
			User findUserByUserId = userService.findUserByUserId(userId);
			if (findUserByUserId==null) {
				return "the user does not exist";
			}
			//宽和高进行转化，转化成浮点数
			if (!validate(length)||!validate(width)) {
				return "The length or width does not match the format";
			}
			String areaSize=length+"x"+width+"x"+height;
			//更新区域信息
			int updateArea = areaRepository.updateArea(areaId, areaName, areaSize, userId, superUserId, areaPictureUrl);
			if (updateArea!=0) {
				return "success";
			}
			return "fail";
		} catch (Exception e) {
			// TODO: handle exception
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 更新区域负责人
	 * @param areaId
	 * @param userId
	 * @return
	 */
	public String updateAreaUserId(String areaId, String userId) {
		try {
			int updateAreaUserId=areaRepository.updateAreaUserId(areaId,userId);
			if (updateAreaUserId!=0) {
				return "success";
			}
			return "fail";
		} catch (Exception e) {
			// TODO: handle exception
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}


	/**
	 * 查询超级用户下的区域信息
	 * @param superUserId
	 * @return
	 */
	public List<Area> findAreaInfoBySuperUserId(String superUserId) {
		Area area=new Area();
		area.setSuperUserId(superUserId);
		Example<Area> example=Example.of(area);
		return areaRepository.findAll(example);		
	}


	/**
	 * 查询某个超级用户下，某个用户管理的区域信息
	 * @param superUserId
	 * @param userId
	 * @return
	 */
	public List<Area> findAreaInfoBySuperUserIdAndUserId(String superUserId, String userId) {
		Area area=new Area();
		area.setSuperUserId(superUserId);
		area.setUserId(userId);
		Example<Area> example=Example.of(area);
		return areaRepository.findAll(example);
	}
	
	/**
	 * 某个超级用户根据区域id查询区域信息
	 * @param areaId
	 * @param superUserId
	 * @return
	 */
	public String updateAreasuperUserId(String areaId, String superUserId) {
		try {
			int updateAreasuperUserId=areaRepository.updateAreasuperUserId(areaId,superUserId);
			if (updateAreasuperUserId!=0) {
				return "success";
			}
			return "fail";
		} catch (Exception e) {
			// TODO: handle exception
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}
	
	/**
	 * 空值转化
	 * @param string
	 * @return
	 */
	public String nullEmpty(String string) {	
		if (string==null||string=="") {
			string="-";
		}
		return string;
	}
	
	/**
	 * 判断String是否可以转化成浮点数
	 * @param date
	 * @return
	 */
	public boolean validate(String date) {	        
	    boolean flag =true;
	    try {
	       Float.parseFloat(date);

	    } catch (Exception e) {
	       flag=false;
	    }
	    return flag;
	}

}