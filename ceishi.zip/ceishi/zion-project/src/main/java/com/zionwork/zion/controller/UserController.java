package com.zionwork.zion.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.User;
import com.zionwork.zion.service.SuperuserService;
import com.zionwork.zion.service.UserService;

/**
 * @author Zion Admin
 * 用户接口
 */
@Controller
@RequestMapping("/zion/User")
public class UserController extends BaseController {
    @Autowired
    private UserService userService;
    @Autowired
    private SuperuserService superuserService;

    /**
     * 添加用户
     * This API assumes that addUser can only be called within VPC
     *
     * @param password
     * @param phoneNumber
     * @param realName
     * @param birthday
     * @return
     */
    @RequestMapping("/addUser")
    @ResponseBody
    public void addUser(HttpServletRequest req, HttpServletResponse resp) {

        String superUserId = req.getParameter("superUserId");
        String userId = req.getParameter("userId");
        String password = req.getParameter("password");
        String phoneNumber = req.getParameter("phoneNumber");
        String realName = req.getParameter("realName");
        String birthday = req.getParameter("birthday");
        
        System.out.println(userId);
        System.out.println(password);
        System.out.println(phoneNumber);
        
        //判断参数是否为空    
        //这里是调用了继承的BaseController
        if (!validateParams(resp,req, superUserId, userId, password, phoneNumber, realName, birthday)) { //当validateParams()的时候为true，才不会中断。
            return;   //中断执行
        }
        try {
        	//添加用户
            // TODO @ymc: encapsulate all err msg
            String state = userService.addUser(superUserId, userId, password, phoneNumber, realName, birthday);
            String result="success";      
            if (result.equals(state)) {  
                printJson(resp,req, 200, state, "String");
            } else {
                printJson(resp,req, 400, state, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            // TODO @ymc: encapsulate all err msg
            printJson(resp, req,500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /*
     * 添加一个用户
     * 
     * */
    @RequestMapping("/addUser1")
    @ResponseBody
    public void addUser1(HttpServletRequest req, HttpServletResponse resp) {

        String superUserId = req.getParameter("superUserId");
        String userId = req.getParameter("userId");
        String password = req.getParameter("password");
        String phoneNumber = req.getParameter("phoneNumber");
        String realName = req.getParameter("realName");
        String birthday = req.getParameter("birthday");
       
        //判断参数是否为空    
        //这里是调用了继承的BaseController
        if (!validateParams(resp,req, superUserId, userId, password, phoneNumber, realName, birthday)) { //当validateParams()的时候为true，才不会中断。
            return;   //中断执行
        }
        try {
        	//添加用户
            // TODO @ymc: encapsulate all err msg
            String state = userService.addUser1(superUserId, userId, password, phoneNumber, realName, birthday);
            String result="success";      
            if (result.equals(state)) {  
                printJson(resp,req, 200, state, "String");
            } else {
                printJson(resp,req, 400, state, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            // TODO @ymc: encapsulate all err msg
            printJson(resp, req,500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    

    /**
     * 修改人员信息
     *
     * @param userId
     * @param phoneNumber
     * @param password
     * @param realName
     * @param birthday
     * @return
     */
    @RequestMapping("/updateUser")
    @ResponseBody
    public void updateUser(HttpServletRequest req, HttpServletResponse resp) {
        String userId = req.getParameter("userId");
        String password = req.getParameter("password");
        String phoneNumber = req.getParameter("phoneNumber");
        String realName = req.getParameter("realName");
        String birthday=req.getParameter("birthday");  
        
        //判断参数是否为空
    	if (!validateParams(resp,req, userId)) {   //如果这个是真的，进入下一步。但是在这个时候，他会先进入验证方法
			return; //不在向下执行
		}
        try {
        	//修改人员信息
            // TODO @ymc: encapsulate all err msg
            String tryUpdateResult = userService.updateUser(userId, password, phoneNumber, realName,birthday);
        
            if (tryUpdateResult.equals("success")) {
                printJson(resp,req, 200, tryUpdateResult, "String");
            } else {
                printJson(resp,req, 400, tryUpdateResult, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            // TODO @ymc: encapsulate all err msg
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 验证人员信息
     * 在手机验证之前
     *
     * @param superUserId
     * @param userId
     * @return
     */
    @RequestMapping("/validateUser")
    @ResponseBody
    public void validateUser(HttpServletRequest req, HttpServletResponse resp) {
        String superUserId = req.getParameter("superUserId");
        String userId = req.getParameter("userId");
        //判断参数是否为空
        if (!validateParams(resp,req, superUserId, userId)) {
            return;
        }
        try {
        	//验证数据
            // TODO @ymc: encapsulate all err msg
            String validateUser = userService.validateUser(superUserId, userId);
            if (validateUser.equals("The user name already exists")) {
                printJson(resp,req, 200, validateUser, "String");
            } else {
                printJson(resp,req, 400, validateUser, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            // TODO @ymc: encapsulate all err msg
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }


    /**
     * 通过用户id，查找用户信息
     *
     * @return
     */
    @RequestMapping("/findUserByUserId")
    @ResponseBody
    public void findUserByUserId(HttpServletRequest req, HttpServletResponse resp) {
        String userId = req.getParameter("userId");
        //判断参数是否存在
        if (!validateParams(resp,req, userId)) {
            return;
        }
        try {
        	//查找数据
            User findUserByUserId = userService.findUserByUserId(userId);
            if (findUserByUserId == null) {
                printJson(resp, req,400, "Find user's info by userId does not exist", "String");
            } else {
                printJson(resp, req,200, findUserByUserId, "Object");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            printJson(resp, req,500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }

    /**
     * 通过超级用户查询属于他的所用用户
     *
     * @param superUserId
     * @return
     */
    @RequestMapping("/findAllUserBySuperUserId")
    @ResponseBody
    public void findAllUserBySuperUserId(HttpServletRequest req, HttpServletResponse resp) {
        String superUserId = req.getParameter("superUserId");
        //判断参数是否为空
        if (!validateParams(resp,req, superUserId)) {
            return;
        }
        //判断superuser是否存在
        if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
            printJson(resp,req, 400, "The superuser does not exist", "String");
            return;
        }
        try {
        	//查找数据
            List<User> findAllUserBySuperUserId = userService.findAllUserBySuperUserId(superUserId);
            if (findAllUserBySuperUserId.size() == 0) {
                printJson(resp,req, 400, "Find user's info by superuserId does not exist", "String");
            } else {
                printJson(resp,req, 200, findAllUserBySuperUserId, "List");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    
    
    /**
     * 通过超级用户查询属于他的所用用户
     * 通过超级用户查询属于他的所用用户
     * @param phoneNumber
     * @return userId
     */
    @RequestMapping("/findUserIdByphoneNumber")
    @ResponseBody
    public void findUserIdByphoneNumber(HttpServletRequest req, HttpServletResponse resp) {
        String phoneNumber = req.getParameter("phoneNumber");
        //判断参数是否为空
        if (!validateParams(resp,req, phoneNumber)) {
            return;
        }
        try {
        	//查找数据
            User findUserIdByphoneNumber = userService.findUserIdByphoneNumber(phoneNumber);
            if (findUserIdByphoneNumber == null) {
                printJson(resp,req, 400, "Find user does not exist", "String");
            } else {
                printJson(resp,req, 200, findUserIdByphoneNumber.getUserId(), "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，抛出异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
    
    /**
     * 批量删除通过userId
     *
     * @return userId
     */
    @RequestMapping("/deleteAllByAllUserId")
    @ResponseBody
    public void deleteAllByAllUserId(HttpServletRequest req, HttpServletResponse resp) {
    	//读取HttpServletRequest流  
    	//重点在于不知道这个有什么用处。  也不知道这个前台会传递一个什么url过来。
		JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req,resp);
		//判断HttpServletRequest流是否为空
		if (readHttpServletRequestIO==null) {
			printJson(resp, req,400, "Params cannot be empty","String");
			return;
		}
		List<Object> list=new ArrayList<Object>();
		try {
			//数据转化
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString());
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}		
        try {
        	//删除数据
            String deleteAllByAllUserId = userService.deleteAllByAllUserId(list);
            if (deleteAllByAllUserId.equals("success")) {         
                printJson(resp, req,200, deleteAllByAllUserId, "String");
            } else {
            	printJson(resp, req,400, deleteAllByAllUserId, "String");
            }
            return;
        } catch (Exception e) {
        	//出现异常，处理异常
            printJson(resp,req, 500, e.toString(), "String");
            logger.error("Server exception", e);
        }
    }
}