package com.zionwork.zion.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.zionwork.zion.entity.Area;
import com.zionwork.zion.entity.Device;
import com.zionwork.zion.entity.Message;
import com.zionwork.zion.repository.MessageRepository;


/**
 * @author Zion Admin
 * message数据的service层
 */
@Transactional
@Service
public class MessageService {
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
	private DeviceService deviceService;
	@Autowired
	private AreaService areaService;

    public MessageRepository getMessageRepository() {
        return messageRepository;
    }

	/**
	 * 增加一条message数据
	 * @param device_id
	 * @param device_type
	 * @param device_sign_type
	 * @param current_status_value
	 * @param area_id
	 * @param device_address
	 * @param user_id
	 * @param superuser_id
	 * @param create_time
	 * @param device_work_status
	 */
	public void addOneMessage(String device_id,String device_type,String device_sign_type,String current_status_value,String area_id,String device_address,String user_id,String superuser_id,String create_time,String device_work_status) {
		messageRepository.addOneMessage(device_id, device_type, device_sign_type, current_status_value, area_id, device_address, user_id, superuser_id, create_time, device_work_status);
	}


	/**
	 * 更改message数据
	 * @param device_id
	 * @param device_type
	 * @param device_sign_type
	 * @param current_status_value
	 * @param date
	 * @param device_work_status
	 */
	public void updateOneMessage(String device_id, String device_type, String device_sign_type,
			String current_status_value, String date, String device_work_status) {
		messageRepository.updateOneMessage(device_id,device_type,device_sign_type,
				current_status_value,date,device_work_status);
	}
	
	/**
	 * 紧急数据更新或插入处理
	 * @param device_id
	 * @param device_type
	 * @param device_sign_type
	 * @param current_status_value
	 * @param createTime
	 * @param device_work_status
	 * @param superUserId
	 */
	public void updateOneMessageFlush(String device_id, String device_type, String device_sign_type,
			String current_status_value, String createTime, String device_work_status, String superUserId) {
		try {
			//判断数据是否再数据库存在
			Message findOne = messageRepository.findOne(device_id);
			//如果数据不存在，插入数据
			if (findOne==null) {
				Message temporaryMessage=new Message();
				temporaryMessage.setDeviceId(device_id);
				temporaryMessage.setCreateTime(createTime);
				temporaryMessage.setCurrentStatusValue(current_status_value);
				temporaryMessage.setDeviceSignType(device_sign_type);
				temporaryMessage.setDeviceWorkStatus(device_work_status);
				temporaryMessage.setDeviceType(device_type);
				temporaryMessage.setSuperUserId(superUserId);
				Device deviceInfo = deviceService.findDeviceByDeviceId(device_id);
				//判断设备所属的区域信息和负责人信息
				if (deviceInfo != null && !"-".equals(deviceInfo.getAreaId())
							&& areaService.findAreaInfoByAreaId(deviceInfo.getAreaId()) != null) {
					Area areaInfo = areaService.findAreaInfoByAreaId(deviceInfo.getAreaId());
					temporaryMessage.setAreaId(areaInfo.getAreaId());
					temporaryMessage.setDeviceAddress(deviceInfo.getDeviceAddress());
					temporaryMessage.setUserId(areaInfo.getUserId());
				}else {
					temporaryMessage.setAreaId("-");
					temporaryMessage.setDeviceAddress("-");
					temporaryMessage.setUserId("-");
				}
				//插入数据
				messageRepository.saveAndFlush(temporaryMessage);
			}else {
				//更新数据
				findOne.setDeviceId(device_id);
				findOne.setCreateTime(createTime);
				findOne.setCurrentStatusValue(current_status_value);
				findOne.setDeviceSignType(device_sign_type);
				findOne.setDeviceWorkStatus(device_work_status);
				findOne.setDeviceType(device_type);
				messageRepository.saveAndFlush(findOne);
			}
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
	}

	/**
	 * 根据设备类型查找某个超级用户的设备最新消息
	 * @param deviceType
	 * @param superUserId
	 * @return
	 */
	public List<Message> findAllDeviceInfoBySuperUserAndDeviceType(String deviceType, String superUserId) {
		Message message=new Message();
    	message.setSuperUserId(superUserId);
    	message.setDeviceType(deviceType);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	/**
	 * 查看某个超级用户的所有设备最新信息
	 * @param superUserId
	 * @return
	 */
	public List<Message> findAllDeviceInfoBySuperUserId(String superUserId) {
		Message message=new Message();
		message.setSuperUserId(superUserId);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	/**
	 * 通过设备类型查找某个超级用户在某个区域内的所有设备的最新信息
	 * @param deviceType
	 * @param superUserId
	 * @param areaId
	 * @return
	 */
	public List<Message> findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId(String deviceType, String superUserId,
			String areaId) {
		Message message=new Message();
    	message.setSuperUserId(superUserId);
    	message.setDeviceType(deviceType);
    	message.setAreaId(areaId);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
		
	}

	/**
	 * 通过设备类型和设备当前状态值查找某个超级用户的设备最新消息
	 * @param deviceType
	 * @param superUserId
	 * @param statusValue
	 * @return
	 */
	public List<Message> findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue(String deviceType,
			String superUserId, String statusValue) {
		Message message=new Message();
    	message.setSuperUserId(superUserId);
    	message.setDeviceType(deviceType);
    	message.setCurrentStatusValue(statusValue);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	/**
	 * 通过设备类型查找某超级用户下某个负责人管理的设备的最新消息
	 * @param deviceType
	 * @param superUserId
	 * @param userId
	 * @return
	 */
	public List<Message> findSuperUserIdAllDeviceByUserIdAndType(String deviceType, String superUserId, String userId) {
		Message message=new Message();
    	message.setSuperUserId(superUserId);
    	message.setDeviceType(deviceType);
    	message.setUserId(userId);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	/**
	 * 根据设备当前状态值查找某个超级用户的设备最新消息
	 * @param superUserId
	 * @param statusValue
	 * @return
	 */
	public List<Message> findAllDeviceCurrentStatusValueBySuperUser(String superUserId, String statusValue) {
		Message message=new Message();
    	message.setSuperUserId(superUserId);
    	message.setCurrentStatusValue(statusValue);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	/**
	 * 根据设备id查找某个设备的最新消息
	 * @param deviceId
	 * @return
	 */
	public Message findOneDeviceInfo(String deviceId) {
		return messageRepository.findOne(deviceId);
	}

	/**
	 * 根据区域id和负责人查找设备最新消息
	 * @param areaId
	 * @param userId
	 * @return
	 */
	public String updateMessageUserIdByAreaId(String areaId, String userId) {
		int updateMessageUserIdByAreaId = messageRepository.updateMessageUserIdByAreaId(areaId,userId);
		if (updateMessageUserIdByAreaId!=0) {
			return "success";
		}
		return "fail";
	}
	
	/**
	 * 根据设备id更改区域信息
	 * @param deviceId
	 * @param areaId
	 * @param deviceAddress
	 */
	public String updateAreaInfoByDeviceId(String deviceId, String areaId, String deviceAddress,String userId) {
		int updateMessageUserIdByAreaId = messageRepository.updateMessageUserIdByAreaId(deviceId,areaId,deviceAddress,userId);
		if (updateMessageUserIdByAreaId!=0) {
			return "success";
		}
		return "fail";		
	}

	/**
	 * 根据设备类型查找设备最新数据
	 * @param deviceType
	 * @return
	 */
	public List<Message> findAllMessageByDeviceType(String deviceType) {
		Message message=new Message();
		message.setDeviceType(deviceType);
    	Example<Message> example=Example.of(message);
    	return messageRepository.findAll(example);
	}

	public void updateMessageBysuperUserId(String superUserId,String deviceId) {
		messageRepository.updateMessageBysuperUserId(superUserId,deviceId);
		
	}

	

}