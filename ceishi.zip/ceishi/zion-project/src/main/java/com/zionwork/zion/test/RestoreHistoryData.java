package com.zionwork.zion.test;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.zioncore.utils.DeleteFileUtil;
import com.zioncore.utils.MongodbConnect;
import com.zioncore.utils.S3Util;

public class RestoreHistoryData {
	/**
	 * 从S3上面恢复数据到Mongodb
	 * 
	 * @param bucketName
	 * @param key
	 * @param tableName
	 * @param file
	 * @throws IOException 
	 */
	public static String restoreHistoryDataByTime(String bucketName, String key, String mongoTableName, String file) throws IOException {

		// 从S3下载需要恢复的数据到本地
		S3Util.downloadDate(bucketName, key, file);
		// 读取S3恢复到本地的数据
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File(file)));
		BufferedReader in = new BufferedReader(new InputStreamReader(bis, "utf-8"), 10 * 1024 * 1024);
		List<Document> documents = new ArrayList<>();
		int temp = 0;
		while (in.ready()) {
			String line = in.readLine();
			documents.add(Document.parse(line));
			temp++;
			if (temp == 100) {
				// 恢复到mongodb数据库
				MongodbConnect.getMongodb().getCollection(mongoTableName).insertMany(documents);
				documents.clear();
				temp = 0;
			}
		}
		if (temp > 0) {
			// 恢复到mongodb数据库
			MongodbConnect.getMongodb().getCollection(mongoTableName).insertMany(documents);
		}
		in.close();
		// 删除下载到本地的文本
		DeleteFileUtil.delete(file);
		return "success";

	}
}
