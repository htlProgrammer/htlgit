package com.zionwork.zion.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zionwork.zion.entity.User;


/**
 * @author Zion Admin
 * 用户Dao层
 */
public interface UserRepository extends JpaRepository<User, Serializable> {
}