
package com.zionwork.zion.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
/*import org.springframework.context.annotation.Scope;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.scheduling.annotation.Async;*/
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.alibaba.fastjson.JSON;
import com.zioncore.utils.NorelationDB;
import com.zioncore.utils.NorelationFactory;
import com.zioncore.utils.PropertiesUtil;
import com.zionwork.zion.entity.Area;
import com.zionwork.zion.entity.Device;
import com.zionwork.zion.entity.History;
import com.zionwork.zion.entity.Message;
import org.apache.tomcat.jdbc.pool.ConnectionPool;
import org.apache.tomcat.jdbc.pool.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



/**
 * @author Zion Admin
 * 历史数据的service层
 */
@Transactional
@Service
public class HistoryService {
/*	@Autowired
	private MessageService messageService;
	@Autowired
	private DeviceService deviceService;
	@Autowired
	private AreaService areaService;*/	
	@Autowired
	private JmsTemplate  jmsTemplate;
	@Autowired
    DataSource dataSource;
	@Autowired
    private ExecutorService executorService;
	
	private PropertiesUtil propertiesUtil=new PropertiesUtil();

	
	private static NorelationDB norelationDB = NorelationFactory.getInstance();
	
	/**
	 * 数据批量插入或者更新到message表
	 * @param map
	 * @param latch
	 */
	public void RunSql(Map<String, History> map,CountDownLatch latch) {	
		try {
			//从数据连接池获取连接
			ConnectionPool pool = dataSource.getPool();		
			Connection conn = pool.getConnection();
			StringBuilder deviceSignTypes=new StringBuilder();
			StringBuilder currentStatusValues=new StringBuilder();
			StringBuilder createTimes=new StringBuilder();
			StringBuilder deviceIds=new StringBuilder();
			StringBuilder addSql=new StringBuilder();
			int update=0;
			int insert=0;
			//更新数据
			for (String key : map.keySet()) {	
				History history = map.get(key);
				//判断数据库是否存在该数据
				PreparedStatement ps = conn.prepareStatement("select createTime,deviceId from message where deviceId=?");
				ps.setString(1, key);
				ResultSet rs = ps.executeQuery();
				Message message=new Message();
				while (rs.next()) {
		             message.setCreateTime(rs.getString("createTime"));
		             message.setDeviceId(rs.getString("deviceId"));
		        }
				//数据库不存在就插入，存在就看是否需要更新
				if (message.getDeviceId() == null) {					
					PreparedStatement ps3 = conn.prepareStatement("select areaId,deviceAddress from device where deviceId=?");
					ps3.setString(1, key);
					ResultSet rs3 = ps3.executeQuery();
					Device deviceInfo=new Device();
					while (rs3.next()) {
						deviceInfo.setAreaId(rs3.getString("areaId"));
						deviceInfo.setDeviceAddress(rs3.getString("deviceAddress"));
					}
					//判断设备所属区域信息和管理员信息是否存在，不存在用"-"代替
					if (deviceInfo.getAreaId()!=null&&deviceInfo.getDeviceAddress()!=null) {
						PreparedStatement ps2 = conn.prepareStatement("select userId from area where areaId=?");
						ps2.setString(1, deviceInfo.getAreaId());
						ResultSet rs2 = ps2.executeQuery();
						Area areaInfo=new Area();
						while (rs2.next()) {
							areaInfo.setUserId(rs2.getString("userId"));
			           }
						if (areaInfo.getUserId()!=null) {
							//拼接sql语句
							addSql.append("("+"'"+history.getDeviceId()+"'"+","+"'"+history.getDeviceType()+"'"+","+"'"+history.getDeviceSignType()+"'"+","
									+"'"+history.getCurrentStatusValue()+"'"+","+"'"+deviceInfo.getAreaId()+"'"+","+"'"+deviceInfo.getDeviceAddress()+"'"+","+"'"+areaInfo.getUserId()+"'"+","
									+"'"+history.getSuperUserId()+"'"+","+"'"+history.getCreateTime()+"'"+","+"'"+history.getDeviceWorkStatus()+"'"+")"+",");
							insert++;
						}else {
							addSql.append("("+"'"+history.getDeviceId()+"'"+","+"'"+history.getDeviceType()+"'"+","+"'"+history.getDeviceSignType()+"'"+","
									+"'"+history.getCurrentStatusValue()+"'"+","+"'-'"+","+"'-'"+","+"'-'"+","
									+"'"+history.getSuperUserId()+"'"+","+"'"+history.getCreateTime()+"'"+","+"'"+history.getDeviceWorkStatus()+"'"+")"+",");
							insert++;
						}
					}else {
						addSql.append("("+"'"+history.getDeviceId()+"'"+","+"'"+history.getDeviceType()+"'"+","+"'"+history.getDeviceSignType()+"'"+","
								+"'"+history.getCurrentStatusValue()+"'"+","+"'-'"+","+"'-'"+","+"'-'"+","
								+"'"+history.getSuperUserId()+"'"+","+"'"+history.getCreateTime()+"'"+","+"'"+history.getDeviceWorkStatus()+"'"+")"+",");
						insert++;
					}
					//每一万条信息拼接插入一次数据库
					if (insert%10000==0) {
						String sql="insert INTO message (deviceId,deviceType,deviceSignType,currentStatusValue,areaId,deviceAddress,userId,superUserId,createTime,deviceWorkStatus) VALUES"+addSql.substring(0, addSql.length()-1);
						PreparedStatement ps2 = conn.prepareStatement(sql);
						//ps2.addBatch(sql);
						ps2.executeUpdate();
						addSql=new StringBuilder();
					}					
				} else if (map.get(key).getCreateTime().compareTo(message.getCreateTime()) > 0) {
					//数据存在，且需要更新
					deviceSignTypes.append(" WHEN "+"'"+history.getDeviceId()+"'"+" THEN "+"'"+history.getDeviceSignType()+"'");
					currentStatusValues.append(" WHEN "+"'"+history.getDeviceId()+"'"+" THEN "+"'"+history.getCurrentStatusValue()+"'");
					createTimes.append(" WHEN "+"'"+history.getDeviceId()+"'"+" THEN "+"'"+history.getCreateTime()+"'");
					deviceIds.append("'"+history.getDeviceId()+"'"+",");
					update++;
					//每一千条数据更新一次
					if (update%1000==0) {
						String sql="UPDATE message SET deviceSignType = CASE deviceId "+deviceSignTypes+" END, currentStatusValue= CASE deviceId"+currentStatusValues+" END,createTime= CASE deviceId "+createTimes+" END "+" WHERE deviceId IN "+"("+deviceIds.substring(0, deviceIds.length()-1)+")";		
						PreparedStatement ps2 = conn.prepareStatement(sql);
						//ps2.addBatch(sql);
						ps2.executeUpdate();
						deviceSignTypes=new StringBuilder();
						currentStatusValues=new StringBuilder();
						createTimes=new StringBuilder();
						deviceIds=new StringBuilder();
					}
				}
			}	
			//当插入的sql语句不为空，处理
			if (addSql.length()>0) {
				String sql="insert INTO message (deviceId,deviceType,deviceSignType,currentStatusValue,areaId,deviceAddress,userId,superUserId,createTime,deviceWorkStatus) VALUES"+addSql.substring(0, addSql.length()-1);
				PreparedStatement ps2 = conn.prepareStatement(sql);
				//ps2.addBatch(sql);
				ps2.executeUpdate();
			}
			//当更新的sql语句不为空，处理
			if (deviceIds.length()>0) {
				String sql="UPDATE message SET deviceSignType = CASE deviceId "+deviceSignTypes+" END, currentStatusValue= CASE deviceId"+currentStatusValues+" END,createTime= CASE deviceId "+createTimes+" END "+" WHERE deviceId IN "+"("+deviceIds.substring(0, deviceIds.length()-1)+")";		
				PreparedStatement ps2 = conn.prepareStatement(sql);
				//ps2.addBatch(sql);
				ps2.executeUpdate();	
			}
			//关闭连接
			conn.close();
			//完成任务
			latch.countDown();
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			e.printStackTrace();
		}
	}
	/**
	 * 批量插入数据
	 * @param map
	 * @param list
	 * @return
	 * @throws SQLException
	 * @throws InterruptedException
	 */
	@SuppressWarnings("static-access")
	public String pushDateToHistory(Map<String, History> map, List<History> list) throws SQLException, InterruptedException {
		//从properties配置中读取，需要开启几个线程
		int threadsNum=Integer.parseInt(propertiesUtil.getProperty("pushHistory.threads"));
		int count=1;
		List<Map<String, History>> list2=new ArrayList<>();	
		//list中加入Map
		for (int i = 0; i < threadsNum; i++) {
			Map<String, History> map1 = new HashMap<String, History>();
			list2.add(map1);
		}
		//将Map平均分等分
		for (String key : map.keySet()) {
			list2.get(count%threadsNum).put(key, map.get(key));
			count++;
		}
		//记录开启线程的完成数
		CountDownLatch latch = new CountDownLatch(threadsNum);
		//开启多线程跑数据的批量操作
		for (int i = 0; i < threadsNum; i++) {
			Map<String, History> maps =list2.get(i);
			executorService.execute(new Runnable() {
				 public void run() { 					
					 RunSql(maps,latch);			   	  
			      }  			 
		        });
		}	
		//数据批量存储到Nosql数据库
		Map<String, String> bashMap = new HashMap<String, String>();
		bashMap.put("History", JSON.toJSONString(list));
		norelationDB.batchSave(bashMap);
		//等待所有线程完成任务
		latch.await();
		//批量数据的操作结束
		return "success";
	}

	/**
	 * 通过设备id查找某个超级用户某段时间内的设备信息（时间可以选择）
	 * @param superUserId
	 * @param deviceId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<Map<String, Object>> findAllInfoByDeviceAndTimeFromHistory(String superUserId, String deviceId,
			String startTime, String endTime) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("deviceId", deviceId);
		startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
		return norelationDB.findByKeyAndRangeKeyAndParams("Historytable", "superUserId", superUserId, "createTime",
				startTime, endTime, map);
	}

	/**
	 * 查找某个超级用户某段时间内的设备信息（时间可以选择）
	 * @param superUserId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<Map<String, Object>> findAllDeviceInfoBySuperUserAndTimeFromHistory(String superUserId,
			String startTime, String endTime) {
		startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
		return norelationDB.findByKeyAndRangeKey("Historytable", "superUserId", superUserId, "createTime", startTime,
				endTime);
	}

	/**
	 * 根据设备类型查找某个超级用户某段时间内的设备信息（时间可以选择）
	 * @param superUserId
	 * @param deviceType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<Map<String, Object>> findAllInfoBySuperUserDeviceTypeAndTimeFromHistory(String superUserId,
			String deviceType, String startTime, String endTime) {
		startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("deviceType", deviceType);
		return norelationDB.findByKeyAndRangeKeyAndParams("Historytable", "superUserId", superUserId, "createTime",
				startTime, endTime, map);
	}
	
	/**
	 * 空字符同一格式
	 * @param string
	 * @return
	 */
	public String nullEmpty(String string) {	
		if (string==null||string=="") {
			string="";
		}
		return string;
	}
	
	
	/**
	 * 按照时间和对应数据表进行恢复数据
	 * @param bucketName
	 * @param key
	 * @param mongoTableName
	 * @return
	 */
	public String restoreHistory(String bucketName, String key, String mongoTableName) {
		//给restore-history这个消息队列添加消息
		jmsTemplate.send("restore-history", new MessageCreator() {		
			@Override
			public javax.jms.Message createMessage(Session session) throws JMSException {
				//消息参数不止一个，使用Map类型的
				MapMessage createMapMessage = session.createMapMessage();
				createMapMessage.setString("key", key);
				createMapMessage.setString("bucketName", bucketName);
				createMapMessage.setString("mongoTableName", mongoTableName);
				return createMapMessage;
			}
		});
		return "success";
	}
}