package com.zionwork.zion.test;

import java.util.HashMap;
import java.util.Map;

import com.zioncore.utils.ControllerUtil;

public class addAreaTest {
	public static void main(String[] args) {	
		String areaName="ceshi";
    	String length = "";
    	String width = "111";
    	String height = "0";
    	String areaPictureUrl ="taiguo";
    	reqController(areaName, length, width, height, areaPictureUrl);
	}
	public static void reqController(String areaName,String length,String width,String height,String areaPictureUrl) {
		ControllerUtil controllerUtil=new ControllerUtil();
		Map<String, String> map=new HashMap<>();
		map.put("areaName", areaName);
		map.put("length", length);
		map.put("width", width);
		map.put("height", height);
		map.put("areaPictureUrl", areaPictureUrl);
		String postMap = controllerUtil.postMap("http://127.0.0.1:8094/zion/Area/addArea", map);
		System.out.println(postMap);
	}
}
