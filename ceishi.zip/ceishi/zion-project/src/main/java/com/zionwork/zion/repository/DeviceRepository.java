package com.zionwork.zion.repository;

import java.io.Serializable;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.zionwork.zion.entity.Device;


/**
 * @author Zion Admin
 * 设备数据的Dao层
 */
public interface DeviceRepository extends JpaRepository<Device, Serializable> {
    @Query(value = "update Device set superUserId =:superUserId,updateTime =:updateTime where deviceId =:deviceId")
    @Transactional
    @Modifying
    int updateDeviceInfoBySuperUser(@Param("superUserId") String superUserId, @Param("deviceId") String deviceId,@Param("updateTime")String updateTime);

    @Query(value = "update Device set areaId =:areaId,deviceAddress=:deviceAddress,updateTime =:updateTime where deviceId =:deviceId")
    @Transactional
    @Modifying
    int updateDeviceByArea(@Param("areaId") String areaId, @Param("deviceId") String deviceId,@Param("deviceAddress") String deviceAddress,@Param("updateTime")String updateTime);

    @Query(value = "update Device set deviceStatus =:deviceStatus,updateTime =:updateTime where deviceId =:deviceId")
    @Transactional
    @Modifying
    int updateDeviceInfoByStatus(@Param("deviceStatus") String deviceStatus, @Param("deviceId") String deviceId,@Param("updateTime")String updateTime);
    
    @Query(value = "update Device set deviceStatus =:deviceStatus,updateTime =:updateTime,superUserId =:superUserId where deviceId =:deviceId")
    @Transactional
    @Modifying
    int updateDeviceInfoByStatusAndSuperUserId(@Param("deviceStatus")String deviceStatus, @Param("deviceId") String deviceId,@Param("superUserId") String superUserId,
    		@Param("updateTime")String updateTime);
}