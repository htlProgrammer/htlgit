package com.zionwork.zion.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.zioncore.utils.NorelationDB;
import com.zioncore.utils.NorelationFactory;
import com.zionwork.zion.entity.Operation;

/**
 * @author Zion Admin
 * 操作信息的service层
 */
@Transactional
@Service
public class OperationService {
    private static NorelationDB norelationDB = NorelationFactory.getInstance();

    /**
     * 批量插入操作信息
     * @param list
     * @return
     */
    public String pushOperationsInfo(List<Operation> list) {
        //做数据唯一性处理
    	for (int i = 0; i < list.size(); i++) {
            Operation operation = list.get(i);
            String uuid = UUID.randomUUID().toString().replaceAll("-", "");
            operation.setCreateTime(operation.getCreateTime() + "-" + uuid);
        }
    	//批量插入数据到Nosql
        Map<String, String> bashMap = new HashMap<String, String>();
        bashMap.put("Operation", JSON.toJSONString(list));
        return norelationDB.batchSave(bashMap);
    }

    /**
     * 根据操作id查找某个超级用户下的某条操作信息
     * @param superUserId
     * @param operationId
     * @return
     */
    public List<Map<String, Object>> findOneOperationInfo(String superUserId, String operationId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("operateId", operationId);
        return norelationDB.findByKeyAndParams("Operationtable", "superUserId", superUserId, map);
    }

    /**
     * 查找某个超级用户下某个设备某段时间的操作记录（时间可选）
     * @param superUserId
     * @param targetId
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findAllOperationInfoByTimeAndDevice(String superUserId, String targetId,
                                                                         String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetId", targetId);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * 根据操作结果查找某个超级用户下的某操作者某段时间内的操作记录（时间可选）
     * @param superUserId
     * @param operateUserId
     * @param operationResult
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findOneDeviceAllOprationInfoByOperateResultAndTime(String superUserId,
                                                                                        String operateUserId, String operationResult, String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("operateUser", operateUserId);
        map.put("operateResult", operationResult);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * 查找某个超级用户下某个用户对某个设备的操作记录（时间可选）
     * @param superUserId
     * @param targetId
     * @param operateUser
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findAllOperationInfoByOperateUserAndDeviceIdAndTime(String superUserId,
                                                                                         String targetId, String operateUser, String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetId", targetId);
        map.put("operateUser", operateUser);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * @param superUserId
     * @param operateUser
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findAllOperationInfoByOperateUserAndTime(String superUserId, String operateUser,
                                                                              String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("operateUser", operateUser);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * 根据操作类型和操作结果查找某个超级用户下某个设备的操作记录（时间可选）
     * @param superUserId
     * @param targetId
     * @param operateResult
     * @param operateType
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findOneDeviceAllOperationInfoByOperateResultAndTime(String superUserId,
                                                                                         String targetId, String operateResult,String operateType, String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetId", targetId);
        map.put("operateResult", operateResult);
        map.put("operateType", operateType);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * 查看某个超级用户下所有设备的操作记录（时间可选）
     * @param superUserId
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findAllDeviceOperationBySuperUserAndTime(String superUserId, String startTime,
                                                                              String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	return norelationDB.findByKeyAndRangeKey("Operationtable", "superUserId", superUserId, "createTime", startTime,
                endTime);
    }

    /**
     * 根据操作类型查看某个超级用户下某个设备的操作记录（时间可选）
     * @param superUserId
     * @param targetId
     * @param operateType
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findOneDeviceAllOperationInfoByOperateTypeAndTime(String superUserId,
                                                                                       String targetId, String operateType, String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetId", targetId);
        map.put("operateType", operateType);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

    /**
     * 根据设备类型查看某个超级用户下所有设备的操作记录（时间可选）
     * @param superUserId
     * @param targetType
     * @param startTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> findAllOperationFromTimeBySuperUserAndDeviceType(String superUserId,
                                                                                      String targetType, String startTime, String endTime) {
    	startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetType", targetType);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
    }

	/**
	 * 添加一条操作记录
	 * @param operation
	 * @return
	 */
	public String addOperationInfo(Operation operation) {
		Map<String, String> map = new HashMap<String, String>();
		String uuid = UUID.randomUUID().toString().replaceAll("-", "");
		operation.setCreateTime(operation.getCreateTime()+"-"+uuid);
	    map.put("Operation", JSON.toJSONString(operation));
		return norelationDB.save(map);
	}
	
	/**
	 * 根据设备类型，设备id查找某个超级用户下的设备操作信息（时间可选）
	 * @param superUserId
	 * @param targetType
	 * @param targetId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<Map<String, Object>> findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId(String superUserId,
			String targetType, String targetId, String startTime, String endTime) {
		startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetType", targetType);
        map.put("targetId", targetId);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
	}

	/**
	 * 根据设备类型，设备id查找某个超级用户下某个操作者的设备操作信息（时间可选）
	 * @param superUserId
	 * @param targetId
	 * @param operateUser
	 * @param targetType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	public List<Map<String, Object>> findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType(String superUserId,
			String targetId, String operateUser, String targetType, String startTime, String endTime) {
		startTime=nullEmpty(startTime);
		endTime=nullEmpty(endTime);
    	Map<String, Object> map = new HashMap<String, Object>();
        map.put("targetType", targetType);
        map.put("targetId", targetId);
        map.put("operateUser", operateUser);
        return norelationDB.findByKeyAndRangeKeyAndParams("Operationtable", "superUserId", superUserId, "createTime",
                startTime, endTime, map);
	}

	/**
	 * 空字符同一格式
	 * @param string
	 * @return
	 */
	public String nullEmpty(String string) {	
		if (string==null||string=="") {
			string="";
		}
		return string;
	}
}
