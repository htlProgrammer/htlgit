package com.zionwork.zion.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

/**
 * superuser 实体类
 * Fri Apr 12 10:34:06 CST 2019
 * @Zion
 */ 
@Entity
@Table(name="superuser")
public class Superuser implements Serializable {
	private static final long serialVersionUID = 1L;
	private String superUserId;
	private String telephoneName;
	private String telephone;
	private String status;
	private String createTime;
	private String mailBox;

	@Id
	public String getSuperUserId() {
		return superUserId;
	}

	public void setSuperUserId(String superUserId) {
		this.superUserId=superUserId;
	}

	public String getTelephoneName() {
		return telephoneName;
	}

	public void setTelephoneName(String telephoneName) {
		this.telephoneName=telephoneName;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone=telephone;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status=status;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime=createTime;
	}

	public String getMailBox() {
		return mailBox;
	}

	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}

}

