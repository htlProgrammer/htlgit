package com.zionwork.zion.repository;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.zionwork.zion.entity.Message;

/**
 * @author Zion Admin
 * message数据的Dao层
 */
public interface MessageRepository extends JpaRepository<Message, Serializable> {
	@Query(value = "insert into message (deviceId,deviceType,deviceSignType,currentStatusValue,areaId,deviceAddress,userId,superUserId,createTime,deviceWorkStatus) values (:deviceId,:deviceType,:deviceSignType,:currentStatusValue,:areaId,:deviceAddress,:userId,:superUserId,:createTime,:deviceWorkStatus) on duplicate key update deviceId=:deviceId",nativeQuery = true)
	@Transactional
	@Modifying
	int addOneMessage(@Param("deviceId") String device_id, @Param("deviceType") String device_type,
			@Param("deviceSignType") String device_sign_type,
			@Param("currentStatusValue") String current_status_value, @Param("areaId") String area_id,
			@Param("deviceAddress") String device_address, @Param("userId") String user_id,
			@Param("superUserId") String superuser_id, @Param("createTime") String create_time,
			@Param("deviceWorkStatus") String device_work_status);

	@Query(value = "update message set deviceType =:deviceType,deviceSignType=:deviceSignType,currentStatusValue=:currentStatusValue,createTime=:createTime,deviceWorkStatus=:deviceWorkStatus where deviceId =:deviceId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateOneMessage(@Param("deviceId")String device_id,  @Param("deviceType") String device_type,@Param("deviceSignType") String device_sign_type,@Param("currentStatusValue") String current_status_value,
			@Param("createTime")String date, @Param("deviceWorkStatus")String device_work_status);
	
	@Query(value = "update message set userId =:userId where areaId =:areaId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateMessageUserIdByAreaId(@Param("areaId")String areaId, @Param("userId")String userId);

	@Query(value = "update message set areaId =:areaId,deviceAddress=:deviceAddress,userId=:userId where deviceId =:deviceId",nativeQuery = true)
	@Transactional
	@Modifying
	int updateMessageUserIdByAreaId(@Param("deviceId")String deviceId,@Param("areaId") String areaId, @Param("deviceAddress")String deviceAddress,@Param("userId")String userId);

	@Query(value = "update message set superUserId =:superUserId where deviceId =:deviceId",nativeQuery = true)
	@Transactional
	@Modifying
	void updateMessageBysuperUserId(@Param("superUserId")String superUserId,@Param("deviceId")String deviceId);
}