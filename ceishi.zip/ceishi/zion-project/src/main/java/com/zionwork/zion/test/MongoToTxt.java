package com.zionwork.zion.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
public class MongoToTxt {
	private static Integer PORT = 27017; // 端口号
	private static String IP = "localhost"; // IP
	private static String DATABASE = "test"; // 数据库名
	private static String USERNAME = "root"; // 用户名
	private static String PASSWORD = "123456"; // 密码
	private static String COLLECTION = "Historytable"; // 文档
	private static String ADDRESS = "d:\\zion\\"; // 导出文件的路径
	


	public static void main(String[] args) throws MessagingException {
		try {
			// IP，端口
			ServerAddress serverAddress = new ServerAddress(IP, PORT);
			List<ServerAddress> address = new ArrayList<ServerAddress>();
			address.add(serverAddress);
			// 用户名，数据库，密码
			MongoCredential credential = MongoCredential.createCredential(USERNAME, DATABASE, PASSWORD.toCharArray());
			List<MongoCredential> credentials = new ArrayList<MongoCredential>();
			credentials.add(credential);
			// 通过验证获取连接
			MongoClient mongoClient = new MongoClient(address, credentials);
			// 连接到数据库
			MongoDatabase mongoDatabase = mongoClient.getDatabase(DATABASE);
			// 连接文档
			MongoCollection<Document> collection = mongoDatabase.getCollection(COLLECTION);
			// 检索所有文档
			FindIterable<Document> findIterable = collection.find(new Document().append("createTime",new Document()
																		.append("$gte", "1562515200")
																		.append("$lte", "1572601600")));																						
			MongoCursor<Document> mongoCursor = findIterable.iterator();
			List<Document> documents = new ArrayList<>();
			while (mongoCursor.hasNext()) {
				documents.add(mongoCursor.next());
			}
			//File file=new File(ADDRESS);
			Date date = new Date();
			System.out.println(documents.size());
			SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd");
			BufferedWriter writer=new BufferedWriter(new FileWriter(ADDRESS+dateFormat.format(date)+".txt"));
			for (Document document : documents) {
				String string=document.toJson();
				writer.write(string+"\r\n");
			}
			writer.close();
		
		} catch (Exception e) {
			System.err.println(e.getClass().getName() + ": " + e.getMessage());
			
		}
	}
}