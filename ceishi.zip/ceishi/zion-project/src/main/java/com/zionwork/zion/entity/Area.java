package com.zionwork.zion.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

/**
 * area 实体类
 * Fri Apr 12 10:34:04 CST 2019
 * @Zion
 */ 
@Entity
@Table(name="area")
public class Area implements Serializable {
	private static final long serialVersionUID = 1L;
	private String areaId;
	private String areaName;
	private String areaSize;
	private String createTime;
	private String userId;
	private String superUserId;
	private String areaPictureUrl;

	@Id
	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId=areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName=areaName;
	}

	public String getAreaSize() {
		return areaSize;
	}

	public void setAreaSize(String areaSize) {
		this.areaSize=areaSize;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime=createTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId=userId;
	}

	public String getSuperUserId() {
		return superUserId;
	}

	public void setSuperUserId(String superUserId) {
		this.superUserId=superUserId;
	}

	public String getAreaPictureUrl() {
		return areaPictureUrl;
	}

	public void setAreaPictureUrl(String areaPictureUrl) {
		this.areaPictureUrl=areaPictureUrl;
	}

}

