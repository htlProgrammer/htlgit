package com.zionwork.zion.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.zionwork.zion.entity.Permissions;

/**
 * @author Zion Admin
 * 权限数据的Dao层
 */
public interface PermissionsRepository extends JpaRepository<Permissions, Serializable> {
	@Query(value = "delete from permissions where userId =:userId",nativeQuery = true)
	@Transactional
	@Modifying
	void deleteByUserId(@Param("userId")String userId);
	
	@Query(value = "update permissions set relationValue =:relationValue where userId =:userId and targetId=:targetId and relationType=:relationType",nativeQuery = true)
	@Transactional
	@Modifying
	void updatePermission(@Param("userId")String userId, @Param("targetId")String targetId,@Param("relationType") String relationType, @Param("relationValue")String relationValue);
}