package com.zionwork.zion.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zionwork.zion.entity.Superuser;

/**
 * @author Zion Admin
 * 超级用户Dao层
 */
public interface SuperuserRepository extends JpaRepository<Superuser, Serializable> {
}