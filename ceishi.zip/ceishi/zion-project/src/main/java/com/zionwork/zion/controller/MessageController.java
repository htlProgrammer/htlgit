package com.zionwork.zion.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Message;
import com.zionwork.zion.service.AreaService;
import com.zionwork.zion.service.DeviceService;
import com.zionwork.zion.service.MessageService;
import com.zionwork.zion.service.SuperuserService;

/**
 * @author Zion Admin
 * 设备最新消息接口
 */
@Controller
@RequestMapping("/zion/Message")
public class MessageController extends BaseController {
	@Autowired
	private MessageService messageService;
	@Autowired
	private SuperuserService superuserService;
	@Autowired
	private DeviceService deviceService;
	@Autowired
    private AreaService areaService;
	
	/**
     * 修改区域信息
     *
     * @param areaId
     * @param userId
     */
    @RequestMapping("/updateMessageUserIdByAreaId")
    @ResponseBody
    public void updateMessageUserIdByAreaId(HttpServletRequest req, HttpServletResponse resp) {
    	String areaId=req.getParameter("areaId");
		String userId=req.getParameter("userId");
		//判断参数是否为空
		if (!validateParams(resp,req,areaId,userId)) {
			return;
		}
		//判断区域是否存在
    	if (areaService.findAreaInfoByAreaId(areaId)==null) {
    		printJson(resp, req,400, "The area doesn't exist","String");
    		return;
		}
    	try {
    		//修改数据
			String updateMessageUserIdByAreaId = messageService.updateMessageUserIdByAreaId(areaId,userId);
			if (updateMessageUserIdByAreaId.equals("success")) {
				printJson(resp,req, 200, updateMessageUserIdByAreaId,"String");
			}else if (updateMessageUserIdByAreaId.equals("fail")) {
				printJson(resp,req, 400, "The database was not modified","String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp, req,500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
	
	
	
	
	
	/**
	 * 查找某个超级用户下的某类设备的所有信息
	 *
	 * @param deviceType
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findAllDeviceInfoBySuperUserAndDeviceType")
	@ResponseBody
	public void findAllDeviceInfoBySuperUserAndDeviceType(HttpServletRequest req, HttpServletResponse resp) {
		String deviceType = req.getParameter("deviceType");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, deviceType, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp,req, superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findAllDeviceInfoBySuperUserAndDeviceType = messageService
					.findAllDeviceInfoBySuperUserAndDeviceType(deviceType, superUserId);
			if (findAllDeviceInfoBySuperUserAndDeviceType.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceType and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceInfoBySuperUserAndDeviceType,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查找某个超级用户下所有设备信息
	 *
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findAllDeviceInfoBySuperUserId")
	@ResponseBody
	public void findAllDeviceInfoBySuperUserId(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp, req,superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findAllDeviceInfoBySuperUserId = messageService.findAllDeviceInfoBySuperUserId(superUserId);
			if (findAllDeviceInfoBySuperUserId .size()==0) {
				printJson(resp,req, 400, "Find device's info by superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceInfoBySuperUserId,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查找某个超级用户的某个区域下某种类型设备的所有信息
	 *
	 * @param deviceType
	 * @param superUserId
	 * @param areaId
	 * @return
	 */
	@RequestMapping("/findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId")
	@ResponseBody
	public void findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId(HttpServletRequest req, HttpServletResponse resp) {
		String deviceType = req.getParameter("deviceType");
		String superUserId = req.getParameter("superUserId");
		String areaId = req.getParameter("areaId");
		//判断参数是否为空
		if (!validateParams(resp,req, deviceType, superUserId, areaId)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp,req, superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId = messageService
					.findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId(deviceType, superUserId, areaId);
			if (findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceType and superuserId and areaId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查找某个超级用户某种设备的某类状态的所有信息
	 *
	 * @param deviceType
	 * @param superUserId
	 * @param statusValue
	 * @return
	 */
	@RequestMapping("/findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValues")
	@ResponseBody
	public void findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue(HttpServletRequest req,
			HttpServletResponse resp) {
		String deviceType = req.getParameter("deviceType");
		String superUserId = req.getParameter("superUserId");
		String statusValue = req.getParameter("statusValue");
		//判断参数是否为空
		if (!validateParams(resp, req,deviceType, superUserId, statusValue)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp, req,superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue = messageService
					.findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue(deviceType, superUserId, statusValue);
			if (findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceType and superuserId and statusValue does not exist","String");
			} else {
				printJson(resp, req,200, findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个管理员下某个区域的所有设备信息
	 *
	 * @param userId
	 * @param deviceType
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findSuperUserIdAllDeviceByUserIdAndType")
	@ResponseBody
	public void findSuperUserIdAllDeviceByUserIdAndType(HttpServletRequest req, HttpServletResponse resp) {
		String deviceType = req.getParameter("deviceType");
		String superUserId = req.getParameter("superUserId");
		String userId = req.getParameter("userId");
		//判断参数是否为空
		if (!validateParams(resp,req, deviceType, superUserId, userId)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp,req, superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findSuperUserIdAllDeviceByUserIdAndType = messageService
					.findSuperUserIdAllDeviceByUserIdAndType(deviceType, superUserId, userId);
			if (findSuperUserIdAllDeviceByUserIdAndType.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceType and superuserId and userId does not exist","String");
			} else {
				printJson(resp,req, 200, findSuperUserIdAllDeviceByUserIdAndType,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个超级用户当前某个设备状态的所有设备信息
	 *
	 * @param superUserId
	 * @param statusValue
	 * @return
	 */
	@RequestMapping("/findAllDeviceCurrentStatusValueBySuperUser")
	@ResponseBody
	public void findAllDeviceCurrentStatusValueBySuperUser(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String statusValue = req.getParameter("statusValue");
		//判断参数是否为空
		if (!validateParams(resp,req, superUserId, statusValue)) {
			return;
		}
		//判断superuser是否存在
		if (!validateParam(resp,req, superUserId)) {
			return;
		}
		try {
			//查找数据
			List<Message> findAllDeviceCurrentStatusValueBySuperUser = messageService
					.findAllDeviceCurrentStatusValueBySuperUser(superUserId, statusValue);
			if (findAllDeviceCurrentStatusValueBySuperUser.size()==0) {
				printJson(resp,req, 400, "Find device's info by deviceType and superuserId and userId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceCurrentStatusValueBySuperUser,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个设备的当前信息
	 *
	 * @param deviceId
	 * @return
	 */
	@RequestMapping("/findOneDeviceInfo")
	@ResponseBody
	public void findOneDeviceInfo(HttpServletRequest req, HttpServletResponse resp) {
		String deviceId = req.getParameter("deviceId");
		//判断参数是否为空
		if (deviceId == null || deviceId == "") {
			printJson(resp,req, 400, "The deviceId cannot be empty","String");
			return;
		}
		//判断设备是否存在
		if (deviceService.findDeviceByDeviceId(deviceId) == null) {
			printJson(resp,req, 400, "The device does not exist","String");
			return;
		}
		try {
			//查找数据
			Message findOneDeviceInfo = messageService.findOneDeviceInfo(deviceId);
			if (findOneDeviceInfo == null) {
				printJson(resp,req, 400, "Find device's info by deviceId does not exist","String");
			} else {
				printJson(resp,req, 200, findOneDeviceInfo,"Object");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
	
	/**
	 * 判断superuser是否存在
	 * @param resp
	 * @param req
	 * @param superUserId
	 * @return
	 */
	public boolean validateParam(HttpServletResponse resp, HttpServletRequest req,String superUserId) {
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return false;
		}
		return true;
	}

}