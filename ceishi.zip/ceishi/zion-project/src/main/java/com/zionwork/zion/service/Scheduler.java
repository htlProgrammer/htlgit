package com.zionwork.zion.service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.mail.MessagingException;
import org.bson.Document;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;
import com.zioncore.utils.DeleteFileUtil;
import com.zioncore.utils.MailUtils;
import com.zioncore.utils.MongodbConnect;
import com.zioncore.utils.PropertiesUtil;
import com.zioncore.utils.S3Util;
import com.zioncore.utils.TimeConversion;

/**
 * @author Zion Admin 
 * 调度器，定时操作某个任务
 */
@Component
public class Scheduler {
	private static String ADDRESS = PropertiesUtil.getProperty("spring.data.mongodb.local.path"); // 导出文件的路径
	private static String SETADRESS=PropertiesUtil.getProperty("mail.set");//邮件接受地址
	private TimeConversion t=new TimeConversion();

	/**
	 * 每天凌晨两点运行一次冷数据迁移到S3
	 * @throws MessagingException
	 */
	//@Scheduled(fixedRate = 20000)
	//@Scheduled(cron = "0 0 2 ? * *")
	public void everyDayBackUp() throws MessagingException {	
		try {
			Date date = new Date();
			//获取前一天  00:00:00的秒数
			String start=t.beforeDay(date,1);
			//获取当天 00:00:00的秒数
			//String end=t.currentDay(date);		
			SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd");
			// 连接文档
			MongoCollection<Document> collection = MongodbConnect.getMongodb().getCollection("Historytable");
			for (int i = 1; i <= 400; i++) {
				//每天进行数据拉取
				FindIterable<Document> findIterable = collection.find(new Document().append("createTime",new Document()
						.append("$gte", (Long.parseLong(start)+216*(i-1))+"")
						.append("$lt", (Long.parseLong(start)+216*(i))+"")));
				//从数据库获取的数据放入到集合
				MongoCursor<Document> mongoCursor = findIterable.iterator();
				List<Document> documents = new ArrayList<>();
				while (mongoCursor.hasNext()) {
					documents.add(mongoCursor.next());
				}
				//数据文本以时间为题目写入到本地	
				BufferedWriter writer = new BufferedWriter(new FileWriter(ADDRESS+dateFormat.format(date)+".txt",true));		
				for (Document document : documents) {
					String string = document.toJson();
					writer.write(string + "\r\n");
				}
				writer.close();
			}
			//文本上传到S3
			String uploadDate = S3Util.uploadDate("historytable", dateFormat.format(date)+".txt", ADDRESS+dateFormat.format(date)+".txt");
			//文本上传成功删除本地文本
			if (uploadDate.equals("success")) {
				boolean delete = DeleteFileUtil.delete(ADDRESS+dateFormat.format(date)+".txt");
				//文本删除失败邮件通知
				if (!delete) {
					MailUtils.sendTxtMail(SETADRESS, "Mongodb临时数据删除失败", "请及时找出失败原因");
				}
			}else {
				//文本上传S3失败邮件通知
				MailUtils.sendTxtMail(SETADRESS, "Mongodb历史数据转移S3失败", "请及时找出失败原因");
			}
		} catch (Exception e) {
			//出现异常邮件通知
			MailUtils.sendTxtMail(SETADRESS, "Mongodb数据转移S3服务器出现问题", e.toString());
		}
	}
	
	

	/**
	 * 每周三中午十二点清理一次，28天之前的所有数据
	 * @throws MessagingException
	 */
	//@Scheduled(cron ="0 0 12 ? * WED")
	public void periodicallyDelete() throws MessagingException {
		try {
			Date date = new Date();
			//获取前二十八天  00:00:00的秒数
			String index=t.beforeDay(date,28);
			// 连接文档
			MongoCollection<Document> collection = MongodbConnect.getMongodb().getCollection("Historytable");
			//删除二十八天前的所有数据
			DeleteResult deleteMany = collection.deleteMany(new Document().append("createTime",new Document()
					.append("$lte", index)));
			//如果出现删除空数据，邮件提示
			if (deleteMany.getDeletedCount()<=0) {
				MailUtils.sendTxtMail(SETADRESS, "Mongodb定期处理数据出现空数据", "请及时找出错误原因");
			}
		} catch (Exception e) {
			//系统错误邮件提示
			MailUtils.sendTxtMail(SETADRESS, "Mongodb定期处理数据出现服务器问题", e.toString());
		}
	}
}