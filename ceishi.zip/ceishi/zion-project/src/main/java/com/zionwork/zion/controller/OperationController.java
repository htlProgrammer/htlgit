package com.zionwork.zion.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.alibaba.fastjson.JSONObject;
import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Operation;
import com.zionwork.zion.service.OperationService;
import com.zionwork.zion.service.SuperuserService;

/**
 * @author Zion Admin
 * 设备操作记录接口
 */
@Controller
@RequestMapping("/zion/Operation")
public class OperationController extends BaseController {
	@Autowired
	private OperationService operationService;
	@Autowired
	private SuperuserService superuserService;

	/**
	 * 批量添加操作记录
	 *
	 * @param date
	 * @return
	 */
	@RequestMapping("/pushOperationsInfo")
	@ResponseBody
	public void pushOperationsInfo(HttpServletRequest req, HttpServletResponse resp) {
		//读取HttpServletRequest流
		JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req, resp);
		//判断HttpServletRequest流是否存在
		if (readHttpServletRequestIO == null) {
			printJson(resp,req, 400, "Params cannot be empty","String");
			return;
		}
		List<Operation> list=new ArrayList<Operation>();
		try {
			//数据转化
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString(), Operation.class);
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}
		//判断参数中设备id是否为空或空字符
		for (Operation operation : list) {
			if (operation.getTargetId() == null || operation.getTargetId() == "") {
				printJson(resp,req, 400, "the lack of targetId","String");
				return;
			}
		}
		try {
			//插入数据
			String pushOperationsInfo = operationService.pushOperationsInfo(list);
			if (pushOperationsInfo.equals("success")) {
				printJson(resp, req,200, pushOperationsInfo,"String");
			} else {
				printJson(resp,req, 500, pushOperationsInfo,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
	
	
	/**
	 * 添加单条操作记录
	 *
	 * @param date
	 * @return
	 */
	@RequestMapping("/addOperationInfo")
	@ResponseBody
	public void addOperationInfo(HttpServletRequest req, HttpServletResponse resp) {
		//读取HttpServletRequest流
		JSONObject readHttpServletRequestIO = ReadHttpServletRequestIO(req, resp);
		//判断HttpServletRequest流是否为空
		if (readHttpServletRequestIO == null) {
			printJson(resp,req, 400, "Params cannot be empty","String");
			return;
		}
		List<Operation> list=new ArrayList<Operation>();
		try {
			//转化数据
			list = JSONObject.parseArray(readHttpServletRequestIO.get("payload").toString(), Operation.class);
		} catch (Exception e) {
			//数据转化失败
			printJson(resp,req, 400, "Data cannot be parsed","String");
			return;
		}
		Operation operation=list.get(0);
		//判断operation是否为空
		if (operation==null) {
			printJson(resp,req, 400, "The operation cannot be empty", "String");
			return;
		}
		//判断操作者是否为空或空字符
		if (operation.getOperateUser()==null||operation.getOperateUser()=="") {
			printJson(resp,req, 400, "The operateUser cannot be empty", "String");
			return;
		}
		try {
			//插入数据
			String addOperationInfo = operationService.addOperationInfo(operation);
			if (addOperationInfo.equals("success")) {
				printJson(resp,req, 200, addOperationInfo,"String");
			} else {
				printJson(resp,req, 500, addOperationInfo,"String");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}


	/**
	 * 查看某条操作信息
	 *
	 * @param operationId
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findOneOperationInfo")
	@ResponseBody
	public void findOneOperationInfo(HttpServletRequest req, HttpServletResponse resp) {
		String operationId = req.getParameter("operationId");
		String superUserId = req.getParameter("superUserId");
		//判断参数是否为空
		if (!validateParams(resp,req, operationId, superUserId)) {
			printJson(resp, req,400, "Params cannot be empty","String");
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}

		try {
			//查找数据
			List<Map<String, Object>> findOneOperationInfo = operationService.findOneOperationInfo(superUserId,
					operationId);
			if (findOneOperationInfo.size()==0) {
				printJson(resp, req,400, "Find operation's info by operationId and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findOneOperationInfo,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个设备某段时间的操作记录
	 *
	 * @param superUserId
	 * @param targetId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationInfoByTimeAndDevice")
	@ResponseBody
	public void findAllOperationInfoByTimeAndDevice(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetId = req.getParameter("targetId");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp, req,targetId, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationInfoByTimeAndDevice = operationService
					.findAllOperationInfoByTimeAndDevice(superUserId, targetId, startTime, endTime);
			if (findAllOperationInfoByTimeAndDevice.size()==0) {
				printJson(resp, req,400, "Find operation's info by targetId and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationInfoByTimeAndDevice,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp, req,500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个操作者某段时间内的某个操作结果的所有操作
	 *
	 * @param operateUserId
	 * @param operationResult
	 * @param superUserId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findOneDeviceAllOprationInfoByOperateResultAndTime")
	@ResponseBody
	public void findOneDeviceAllOprationInfoByOperateResultAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String operateUserId = req.getParameter("operateUserId");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		String operationResult = req.getParameter("operationResult");
		//判断参数是否为空
		if (!validateParams(resp,req, operateUserId, superUserId, operationResult)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findOneDeviceAllOprationInfoByOperateResultAndTime = operationService
					.findOneDeviceAllOprationInfoByOperateResultAndTime(superUserId, operateUserId, operationResult,
							startTime, endTime);
			if (findOneDeviceAllOprationInfoByOperateResultAndTime.size()==0) {
				printJson(resp,req, 400, "Find operation's info by operateUserId and superuserId and operationResult does not exist","String");
			} else {
				printJson(resp,req, 200, findOneDeviceAllOprationInfoByOperateResultAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个设备某个操作者在某段时间类的操作结果
	 * 
	 * @param superUserId
	 * @param targetId
	 * @param operateUser
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationInfoByOperateUserAndDeviceIdAndTime")
	@ResponseBody
	public void findAllOperationInfoByOperateUserAndDeviceIdAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetId = req.getParameter("targetId");
		String operateUser = req.getParameter("operateUser");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetId, superUserId, operateUser)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationInfoByOperateUserAndDeviceIdAndTime = operationService
					.findAllOperationInfoByOperateUserAndDeviceIdAndTime(superUserId, targetId, operateUser, startTime,
							endTime);
			if (findAllOperationInfoByOperateUserAndDeviceIdAndTime.size()==0) {
				printJson(resp,req, 400, "Find operation's info by operateUser and superuserId and targetId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationInfoByOperateUserAndDeviceIdAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个设备某个操作者在某段时间类的操作结果
	 * 
	 * @param superUserId
	 * @param targetId
	 * @param targetType
	 * @param operateUser
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType")
	@ResponseBody
	public void findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetType = req.getParameter("targetType");
		String targetId = req.getParameter("targetId");
		String operateUser = req.getParameter("operateUser");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetId, superUserId, operateUser,targetType)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType = operationService
					.findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType(superUserId, targetId, operateUser,targetType, startTime,
							endTime);
			if (findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType.size()==0) {
				printJson(resp,req, 400, "Find operation's info by operateUser and superuserId and targetId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	
	
	/**
	 * 查询某个操作者某段时间类的所有操作信息
	 * 
	 * @param superUserId
	 * @param operateUser
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationInfoByOperateUserAndTime")
	@ResponseBody
	public void findAllOperationInfoByOperateUserAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String operateUser = req.getParameter("operateUser");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, operateUser, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationInfoByOperateUserAndTime = operationService
					.findAllOperationInfoByOperateUserAndTime(superUserId, operateUser, startTime, endTime);
			if (findAllOperationInfoByOperateUserAndTime.size()==0) {
				printJson(resp,req, 400, "Find operation's info by operateUser and superuserId and does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationInfoByOperateUserAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查找某段时间某个设备某个操作结果的操作信息
	 *
	 * @param targetId
	 * @param superUserId
	 * @param operateResult
	 * @param operateType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findOneDeviceAllOperationInfoByOperateResultAndTime")
	@ResponseBody
	public void findOneDeviceAllOperationInfoByOperateResultAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetId = req.getParameter("targetId");
		String operateResult = req.getParameter("operateResult");
		String operateType = req.getParameter("operateType");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetId, superUserId, operateResult,operateType)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp,req, 400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findOneDeviceAllOperationInfoByOperateResultAndTime = operationService
					.findOneDeviceAllOperationInfoByOperateResultAndTime(superUserId, targetId, operateResult,operateType,
							startTime, endTime);
			if (findOneDeviceAllOperationInfoByOperateResultAndTime.size()==0) {
				printJson(resp,req, 400, "Find operation's info by operateResult and superuserId and targetId does not exist","String");
			} else {
				printJson(resp,req, 200, findOneDeviceAllOperationInfoByOperateResultAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个超级用户所有的设备在某段时间类的操作信息
	 *
	 * @param superUserId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllDeviceOperationBySuperUserAndTime")
	@ResponseBody
	public void findAllDeviceOperationBySuperUserAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否存在
		if (!validateParams(resp,req, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllDeviceOperationBySuperUserAndTime = operationService
					.findAllDeviceOperationBySuperUserAndTime(superUserId, startTime, endTime);
			if (findAllDeviceOperationBySuperUserAndTime.size()==0) {
				printJson(resp,req, 400, "Find operation's info by superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllDeviceOperationBySuperUserAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个设备某种操作类型在某段时间类的操作记录
	 *
	 * @param superUserId
	 * @param targetId
	 * @param operateType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findOneDeviceAllOperationInfoByOperateTypeAndTime")
	@ResponseBody
	public void findOneDeviceAllOperationInfoByOperateTypeAndTime(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetId = req.getParameter("targetId");
		String operateType = req.getParameter("operateType");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetId, superUserId, operateType)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findOneDeviceAllOperationInfoByOperateTypeAndTime = operationService
					.findOneDeviceAllOperationInfoByOperateTypeAndTime(superUserId, targetId, operateType, startTime,
							endTime);
			if (findOneDeviceAllOperationInfoByOperateTypeAndTime.size()==0) {
				printJson(resp, req,400, "Find operation's info by operateType and superuserId and targetId does not exist","String");
			} else {
				printJson(resp, req,200, findOneDeviceAllOperationInfoByOperateTypeAndTime,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个超级用户的某类设备在某段时间类的操作记录
	 *
	 * @param superUserId
	 * @param targetType
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationFromTimeBySuperUserAndDeviceType")
	@ResponseBody
	public void findAllOperationFromTimeBySuperUserAndDeviceType(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetType = req.getParameter("targetType");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetType, superUserId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationFromTimeBySuperUserAndDeviceType = operationService
					.findAllOperationFromTimeBySuperUserAndDeviceType(superUserId, targetType, startTime, endTime);
			if (findAllOperationFromTimeBySuperUserAndDeviceType.size()==0) {
				printJson(resp,req, 400, "Find operation's info by targetType and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationFromTimeBySuperUserAndDeviceType,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
	
	/**
	 * 查询某个超级用户的某类设备在某段时间类的操作记录
	 *
	 * @param superUserId
	 * @param targetType
	 * @param targetId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@RequestMapping("/findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId")
	@ResponseBody
	public void findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		String targetType = req.getParameter("targetType");
		String targetId = req.getParameter("targetId");
		String startTime = req.getParameter("startTime");
		String endTime = req.getParameter("endTime");
		//判断参数是否为空
		if (!validateParams(resp,req, targetType, superUserId,targetId)) {
			return;
		}
		//判断superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req,400, "The superuser does not exist","String");
			return;
		}
		try {
			//查找数据
			List<Map<String, Object>> findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId = operationService
					.findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId(superUserId, targetType,targetId, startTime, endTime);
			if (findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId.size()==0) {
				printJson(resp,req, 400, "Find operation's info by targetType and superuserId does not exist","String");
			} else {
				printJson(resp,req, 200, findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId,"List");
			}
			return;
		} catch (Exception e) {
			//处理异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
	}
}