package com.zionwork.zion.service;


import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.zionwork.zion.entity.Area;
import com.zionwork.zion.entity.Device;
import com.zionwork.zion.entity.Message;
import com.zionwork.zion.entity.Superuser;
import com.zionwork.zion.repository.AreaRepository;
import com.zionwork.zion.repository.DeviceRepository;
import com.zionwork.zion.repository.SuperuserRepository;


/**
 * @author Zion Admin
 * 设备信息的service层
 */
@Transactional
@Service
public class DeviceService {
    @Autowired
    private DeviceRepository deviceRepository;
    @Autowired
    private AreaRepository areaRepository;
    @Autowired
    private MessageService messageService;
    @Autowired
    private SuperuserRepository superuserRepository;

    
    public DeviceRepository getDeviceRepository() {
        return deviceRepository;
    }

	/**
	 * 新设备录入
	 * @param deviceId
	 * @param deviceType
	 * @param deviceMake
	 * @param deviceStatus
	 * @param deviceVersion
	 * @param deviceMakeTime
	 * @param areaId
	 * @param deviceAddress
	 * @param superUserId
	 * @return
	 */
	public String registerDevice(String deviceId, String deviceType, String deviceMake, String deviceStatus,
			String deviceVersion,String deviceMakeTime, String areaId, String deviceAddress, String superUserId) {
		Device device=new Device();
		device.setDeviceId(deviceId);
		device.setDeviceType(deviceType);
		device.setDeviceMake(deviceMake);
		device.setDeviceStatus(deviceStatus);
		device.setDeviceVersion(deviceVersion);
		device.setDeviceMakeTime(deviceMakeTime);
		device.setAreaId(areaId);
		device.setDeviceAddress(deviceAddress);
		device.setSuperUserId(superUserId);
		device.setUpdateTime(String.valueOf(Instant.now().getEpochSecond()));
		try {
			deviceRepository.save(device);
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}	
	}

	/**
	 * 通过设备id查找设备信息
	 * @param deviceId
	 * @return
	 */
	public Device findDeviceByDeviceId(String deviceId) {
		return deviceRepository.findOne(deviceId);		
	}

	/**
	 * 设备绑定超级用户
	 * @param superUserId
	 * @param deviceId
	 * @return
	 */
	
	public String updateDeviceInfoBySuperUser(String superUserId, String deviceId) {	
		try {
			Superuser findOne = superuserRepository.findOne(superUserId);
			if (findOne==null) {
				return "The superUserid does not exist";
			}
			deviceRepository.updateDeviceInfoBySuperUser(superUserId, deviceId,String.valueOf(Instant.now().getEpochSecond()));
			Message findOneDeviceInfo = messageService.findOneDeviceInfo(deviceId);
			if (findOneDeviceInfo!=null) {
				messageService.updateMessageBysuperUserId(superUserId,deviceId);
			}
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 设备绑定区域信息
	 * @param areaId
	 * @param deviceId
	 * @param length
	 * @param width
	 * @param height
	 * @return
	 */
	public String updateDeviceByArea(String areaId, String deviceId,String length, String width, String height) {
		//判断长，宽，高是否可以转化成浮点数
		if (!validate(length)||!validate(width)||!validate(height)) {
			return "The length or width or height does not match the format";
		}
		//判断需要改的区域数据是否存在
		Area findOneArea = areaRepository.findOne(areaId);
		if (findOneArea==null) {
			return "The areaId doesn't exist";
		}
		//判断设备的位置信息有没有超出区域尺寸
		String areaSize=findOneArea.getAreaSize();
		String[] strArr = areaSize.split("x");
		if (Float.parseFloat(length)>Float.parseFloat(strArr[0])) {
			return "Coordinate length dimension exceeds area length dimension";
		}
		if (Float.parseFloat(width)>Float.parseFloat(strArr[1])) {
			return "Coordinate width dimension exceeds area width dimension";
		}
		//设备更改区域信息
		String deviceAddress=length+"x"+width+"x"+height;
		try {
			deviceRepository.updateDeviceByArea(areaId, deviceId,deviceAddress,String.valueOf(Instant.now().getEpochSecond()));
			Message findOneDeviceInfo = messageService.findOneDeviceInfo(deviceId);
			if (findOneDeviceInfo!=null) {
				messageService.updateAreaInfoByDeviceId(deviceId,areaId,deviceAddress,findOneArea.getUserId());
			}
			return "success";
		} catch (Exception e) {
			//出现异常，返回异常信息
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}		
	}

	/**
	 * 更新设备状态
	 * @param deviceStatus
	 * @param deviceId
	 * @return
	 */
	public String updateDeviceInfoByStatus(String deviceStatus, String deviceId) {
		try {
			deviceRepository.updateDeviceInfoByStatus(deviceStatus, deviceId,String.valueOf(Instant.now().getEpochSecond()));
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 某个超级用户通过设备id查找设备信息
	 * @param deviceId
	 * @param superUserId
	 * @return
	 */
	public Device findDeviceInfoByDeviceIdAndSuperUserId(String deviceId, String superUserId) {
		Device device=new Device();
		device.setDeviceId(deviceId);
		device.setSuperUserId(superUserId);
		Example<Device> example = Example.of(device);
		return deviceRepository.findOne(example);
	}

	/**
	 * 通过超级用户查找他名下所有设备信息
	 * @param superUserId
	 * @return
	 */
	public List<Device> findDeviceBySuperUserId(String superUserId) {
		Device device=new Device();
		device.setSuperUserId(superUserId);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);

	}

	/**
	 * @param deviceType
	 * @param superUserId
	 * @return
	 */
	public List<Device> findDeviceInfoByDeviceTypeAndSuperUserId(String deviceType, String superUserId) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setSuperUserId(superUserId);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}

	/**
	 * 通过区域id以及设备类型查找某个超级用户的设备信息
	 * @param deviceType
	 * @param superUserId
	 * @param areaId
	 * @return
	 */
	public List<Device> findDeviceInfoByDeviceTypeAndAreaAndSuperUser(String deviceType, String superUserId,
			String areaId) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setSuperUserId(superUserId);
		device.setAreaId(areaId);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}

	/**
	 * 通过设备类型和设备状态查询某个超级用户的设备信息
	 * @param deviceType
	 * @param superUserId
	 * @param deviceStatus
	 * @return
	 */
	public List<Device> findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus(String deviceType, String superUserId,
			String deviceStatus) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setSuperUserId(superUserId);
		device.setDeviceStatus(deviceStatus);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}

	/**
	 * 通过设备类型和设备状态查询设备信息
	 * @param deviceType
	 * @param deviceStatus
	 * @return
	 */
	public List<Device> findDeviceInfoByDevcieTypeAndDeviceStatus(String deviceType, String deviceStatus) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setDeviceStatus(deviceStatus);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}

	/**
	 * 通过设备id和设备状态查询某个超级用户的设备信息
	 * @param deviceStatus
	 * @param deviceId
	 * @param superUserId
	 * @return
	 */
	public String updateDeviceInfoByStatusAndSuperUserId(String deviceStatus, String deviceId, String superUserId) {
		try {
			deviceRepository.updateDeviceInfoByStatusAndSuperUserId(deviceStatus, deviceId,superUserId,String.valueOf(Instant.now().getEpochSecond()));
			return "success";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return e.toString();
		}
	}

	/**
	 * 通过区域id查询某个超级用户下的设备信息
	 * @param areaId
	 * @param superUserId
	 * @return
	 */
	public List<Device> findDeviceInfoByareaIdAndSuperUserId(String areaId, String superUserId) {
		Device device=new Device();
		device.setAreaId(areaId);
		device.setSuperUserId(superUserId);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}

	/**
	 * 通过设备类型，设备状态，区域id和具体位置查找设备信息
	 * @param deviceType
	 * @param deviceStatus
	 * @param areaId
	 * @param deviceAddress
	 * @return
	 */
	public List<Device> findDeviceInfoByDevcieTypeAndDeviceStatusAndAreaInfo(String deviceType, String deviceStatus,
			String areaId, String deviceAddress) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setDeviceStatus(deviceStatus);
		device.setAreaId(areaId);
		device.setDeviceAddress(deviceAddress);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}	
	
	/**
	 * 通过设备类型，设备生产时间查找设备信息
	 * @param deviceType
	 * @param deviceMakeTime
	 * @return
	 */
	public List<Device> findDeviceInfoByDevcieTypeAndDeviceMakeTime(String deviceType, String deviceMakeTime) {
		Device device=new Device();
		device.setDeviceType(deviceType);
		device.setDeviceMakeTime(deviceMakeTime);
		Example<Device> example = Example.of(device);
		return deviceRepository.findAll(example);
	}	
	
	/**
	 * 判断String是否可以转浮点数
	 * @param date
	 * @return
	 */
	public boolean validate(String date) {	        
	    boolean flag =true;
	    try {
	       Float.parseFloat(date);

	    } catch (Exception e) {
	       flag=false;
	    }
	    return flag;
	}
}