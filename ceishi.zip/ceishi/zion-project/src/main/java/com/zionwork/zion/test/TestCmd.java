package com.zionwork.zion.test;

import java.io.File;
import java.io.IOException;


public class TestCmd {
    public static void main(String[] args) {
        String cmdStr = "cmd /c start mongoexport -h localhost:27017 -u root -p 123456 -d test -c Historytable -q {createTime:{'$gt':'1544896899993'}} -o d:Historytabless.dat";
        Runtime run = Runtime.getRuntime();
        try {
            run.exec(cmdStr,null,new File("C:\\Program Files\\Mongodb\\Server\\4.0\\bin"));
            run.exit(1);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

