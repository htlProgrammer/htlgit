package com.zionwork.zion.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Area;
import com.zionwork.zion.service.AreaService;
import com.zionwork.zion.service.SuperuserService;
import com.zionwork.zion.service.UserService;

/**
 * @author Zion Admin 区域表接口
 */
@Controller
@RequestMapping("/zion/Area")
public class AreaController extends BaseController {
	@Autowired
	private AreaService areaService;
	@Autowired
	private SuperuserService superuserService;
	@Autowired
	private UserService userService;

	/**
	 * 添加区域
	 *
	 * @param areaName
	 *            areaSize:
	 * @param: length
	 * @param: width
	 * @param: height
	 *             [optional]
	 *
	 * @param userId
	 * @param superUserId
	 * @return 添加区域信息
	 */
	@RequestMapping("/addArea")
	@ResponseBody
	public void addArea(HttpServletRequest req, HttpServletResponse resp) {
		// Validate parameters
		// SUPERUSERID exists???
		// Get Epoch time
		// area.setCreate_time(createTime); THIS IS WRONG
		// TODO @ymc
		// 400 - Every Reason
		// 200
		String areaName = req.getParameter("areaName");
		String length = req.getParameter("length");
		String width = req.getParameter("width");
		String height = req.getParameter("height");
		String userId = req.getParameter("userId");
		String superUserId = req.getParameter("superUserId");
		String areaPictureUrl = req.getParameter("areaPictureUrl");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaName, length, width, areaPictureUrl)) {
			return;
		}
		try {
			// 插入区域信息
			superUserId = changeNullParam(superUserId);
			userId = changeNullParam(userId);
			String addArea = areaService.addArea(areaName, length, width, height, userId, superUserId, areaPictureUrl);
			if (addArea.equals("This area map already exists")) {
				printJson(resp, req, 400, addArea, "String");
			} else {
				printJson(resp, req, 200, addArea, "String");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 修改区域信息
	 *
	 * @param areaId
	 * @param areaName
	 *            areaSize
	 * @param: length
	 * @param: width
	 * @param: height
	 *             [optional]
	 * @param userId
	 * @param superUserId
	 */
	@RequestMapping("/updateArea")
	@ResponseBody
	public void updateArea(HttpServletRequest req, HttpServletResponse resp) {
		// TODO: THIS IS WRONG @ymc
		// areaService.updateArea(areaId, areaName, areaSize, createTime, userId,
		// superUserId);
		String areaId = req.getParameter("areaId");
		String areaName = req.getParameter("areaName");
		String length = req.getParameter("length");
		String width = req.getParameter("width");
		String height = req.getParameter("height");
		String userId = req.getParameter("userId");
		String superUserId = req.getParameter("superUserId");
		String areaPictureUrl = req.getParameter("areaPictureUrl");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaId, areaName, length, width, areaPictureUrl, superUserId, userId)) {
			return;
		}
		// 查看区域是否存在，做初步判断数据
		if (areaService.findAreaInfoByAreaId(areaId) == null) {
			printJson(resp, req, 400, "The area doesn't exist", "String");
			return;
		}
		try {
			// 修改数据
			String updateArea = areaService.updateArea(areaId, areaName, length, width, height, userId, superUserId,
					areaPictureUrl);
			if (updateArea.equals("success")) {
				printJson(resp, req, 200, updateArea, "String");
			} else if (updateArea.equals("fail")) {
				printJson(resp, req, 400, "The database was not modified", "String");
			} else {
				printJson(resp, req, 400, updateArea, "String");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	// TODO: updateAreaSize

	/**
	 * 修改区域大小信息
	 *
	 * @param areaId
	 *            areaSize
	 * @param: length
	 * @param: width
	 * @param: height
	 *             [optional]
	 */
	@RequestMapping("/updateAreaSize")
	@ResponseBody
	public void updateAreaSize(HttpServletRequest req, HttpServletResponse resp) {
		String areaId = req.getParameter("areaId");
		String length = req.getParameter("length");
		String width = req.getParameter("width");
		String height = req.getParameter("height");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaId, length, width)) {
			return;
		}
		// 判断修改区域是否存在
		if (areaService.findAreaInfoByAreaId(areaId) == null) {
			printJson(resp, req, 400, "The area doesn't exist", "String");
			return;
		}
		try {
			// 修改数据
			String updateAreaSize = areaService.updateAreaSize(areaId, length, width, height);
			if (updateAreaSize.equals("success")) {
				printJson(resp, req, 200, updateAreaSize, "String");
			} else {
				printJson(resp, req, 400, "The database was not modified", "String");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	// TODO: updateAreaUserId
	/**
	 * 修改区域负责人信息
	 *
	 * @param areaId
	 * @param userId
	 */
	@RequestMapping("/updateAreaUserId")
	@ResponseBody
	public void updateAreaUserId(HttpServletRequest req, HttpServletResponse resp) {
		String areaId = req.getParameter("areaId");
		String userId = req.getParameter("userId");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaId, userId)) {
			return;
		}
		// 判断区域是否存在
		if (areaService.findAreaInfoByAreaId(areaId) == null) {
			printJson(resp, req, 400, "The area doesn't exist", "String");
			return;
		}
		try {
			// 修改数据
			String updateAreaUserId = areaService.updateAreaUserId(areaId, userId);
			if (updateAreaUserId.equals("success")) {
				printJson(resp, req, 200, updateAreaUserId, "String");
			} else {
				printJson(resp, req, 400, "The database was not modified", "String");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	// TODO: updateAreasuperUserId
	/**
	 * 修改区域超级用户信息
	 *
	 * @param areaId
	 * @param superuserId
	 */
	@RequestMapping("/updateAreasuperUserId")
	@ResponseBody
	public void updateAreasuperUserId(HttpServletRequest req, HttpServletResponse resp) {
		String areaId = req.getParameter("areaId");
		String superUserId = req.getParameter("superUserId");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaId, superUserId)) {
			return;
		}
		// 判断区域是否存在，并且判断区域是否属于这个
		if (areaService.findAreaInfoByAreaId(areaId) == null) {
			printJson(resp, req, 400, "The area doesn't exist", "String");
			return;
		}
		try {
			// 修改数据
			String updateAreasuperUserId = areaService.updateAreasuperUserId(areaId, superUserId);
			if (updateAreasuperUserId.equals("success")) {
				printJson(resp, req, 200, updateAreasuperUserId, "String");
			} else {
				printJson(resp, req, 400, "The database was not modified", "String");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查询某个超级用户下的全部区域信息
	 *
	 * @param superUserId
	 * @return
	 */
	@RequestMapping("/findAreaInfoBySuperUserId")
	@ResponseBody
	public void findAreaInfoBySuperUserId(HttpServletRequest req, HttpServletResponse resp) {
		String superUserId = req.getParameter("superUserId");
		// 判断参数是否为空
		if (!validateParams(resp, req, superUserId)) {
			return;
		}
		// 检验superuser是否存在
		if (superuserService.findSuperUserBySuperUserId(superUserId) == null) {
			printJson(resp, req, 400, "The superuser does not exist", "String");
			return;
		}
		try {
			// 查找数据
			List<Area> findAreaInfoBySuperUserId = areaService.findAreaInfoBySuperUserId(superUserId);
			if (findAreaInfoBySuperUserId.size() == 0) {
				printJson(resp, req, 400, "Find area's info by superuser does not exist", "String");
			} else {
				printJson(resp, req, 200, findAreaInfoBySuperUserId, "List");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	// TODO add area picture @ymc

	/**
	 * 通过区域id查询区域信息
	 *
	 * @param areaId
	 * @return
	 */
	@RequestMapping("/findAreaInfoByAreaId")
	@ResponseBody
	public void findAreaInfoByAreaId(HttpServletRequest req, HttpServletResponse resp) {
		String areaId = req.getParameter("areaId");
		// 判断参数是否为空
		if (!validateParams(resp, req, areaId)) {
			return;
		}
		try {
			// 查找数据
			Area findAreaInfoByAreaId = areaService.findAreaInfoByAreaId(areaId);
			if (findAreaInfoByAreaId == null) {
				printJson(resp, req, 400, "Find area's info by areaId does not exist", "String");
			} else {
				printJson(resp, req, 200, findAreaInfoByAreaId, "Object");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}

	/**
	 * 查找某个超级用户下的某个用户负责的所有区域
	 *
	 * @param superUserId
	 * @param userId
	 * @return
	 */
	@RequestMapping("/findAreaInfoBySuperUserIdAndUserId")
	@ResponseBody
	public void findAreaInfoBySuperUserIdAndUserId(HttpServletRequest req, HttpServletResponse resp) {
		String userId = req.getParameter("userId");
		String superUserId = req.getParameter("superUserId");
		// 判断参数是否为空
		if (!validateParams(resp, req, userId, superUserId)) {
			return;
		}
		// 判断用户是否存在，并且判断用户和超级用户是否是所属关系
		if (userService.findUserByUserId(userId) == null) {
			printJson(resp, req, 400, "The user does not exist", "String");
			return;
		} else if (userService.findUserByUserId(userId).getSuperUserId() == null
				|| !superUserId.equals(userService.findUserByUserId(userId).getSuperUserId())) {
			printJson(resp, req, 400, "This user does not belong to the superuser", "String");
			return;
		}
		try {
			// 查找数据
			List<Area> findAreaInfoBySuperUserIdAndUserId = areaService.findAreaInfoBySuperUserIdAndUserId(superUserId,
					userId);
			if (findAreaInfoBySuperUserIdAndUserId.size() == 0) {
				printJson(resp, req, 400, "Find Area's info by superuser and user does not exist", "String");
			} else {
				printJson(resp, req, 200, findAreaInfoBySuperUserIdAndUserId, "List");
			}
			return;
		} catch (Exception e) {
			// 处理异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}
}
