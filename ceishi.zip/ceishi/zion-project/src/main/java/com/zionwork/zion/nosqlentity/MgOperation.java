package com.zionwork.zion.nosqlentity;


import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection="Operationtable") 
public class MgOperation {
	    String operateId;
	    String targetId;
	    String operateUser;
	    String operateType;
	    String operateReason;
	    String operateResult;
	    String targetType;
	    
	    @Indexed
	    String createTime;
	    @Indexed
	    String superUserId;

		public String getOperateId() {
			return operateId;
		}
		public void setOperateId(String operateId) {
			this.operateId = operateId;
		}
		public String getTargetId() {
			return targetId;
		}
		public void setTargetId(String targetId) {
			this.targetId = targetId;
		}
		public String getOperateUser() {
			return operateUser;
		}
		public void setOperateUser(String operateUser) {
			this.operateUser = operateUser;
		}
		public String getOperateType() {
			return operateType;
		}
		public void setOperateType(String operateType) {
			this.operateType = operateType;
		}
		public String getOperateReason() {
			return operateReason;
		}
		public void setOperateReason(String operateReason) {
			this.operateReason = operateReason;
		}
		public String getOperateResult() {
			return operateResult;
		}
		public void setOperateResult(String operateResult) {
			this.operateResult = operateResult;
		}
		public String getCreateTime() {
			return createTime;
		}
		public void setCreateTime(String createTime) {
			this.createTime = createTime;
		}
		public String getTargetType() {
			return targetType;
		}
		public void setTargetType(String targetType) {
			this.targetType = targetType;
		}
		public String getSuperUserId() {
			return superUserId;
		}
		public void setSuperUserId(String superUserId) {
			this.superUserId = superUserId;
		}
	    
	
}
