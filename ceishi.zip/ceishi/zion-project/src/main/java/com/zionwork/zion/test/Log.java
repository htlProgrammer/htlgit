package com.zionwork.zion.test;


public class Log {

	public static float log(float value, float base) {

        return (float) (Math.log(value) / Math.log(base));

    }

}

