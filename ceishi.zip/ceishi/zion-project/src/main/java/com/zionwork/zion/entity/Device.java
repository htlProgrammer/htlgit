package com.zionwork.zion.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

/**
 * device 实体类
 * Fri Apr 12 10:34:04 CST 2019
 * @Zion
 */ 
@Entity
@Table(name="device")
public class Device implements Serializable {
	private static final long serialVersionUID = 1L;
	private String deviceId;
	private String deviceType;
	private String areaId;
	private String deviceAddress;
	private String deviceMake;
	private String deviceMakeTime;
	private String superUserId;
	private String updateTime;
	private String deviceStatus;
	private String deviceVersion;

	@Id
	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId=deviceId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType=deviceType;
	}

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId=areaId;
	}

	public String getDeviceAddress() {
		return deviceAddress;
	}

	public void setDeviceAddress(String deviceAddress) {
		this.deviceAddress=deviceAddress;
	}

	public String getDeviceMake() {
		return deviceMake;
	}

	public void setDeviceMake(String deviceMake) {
		this.deviceMake=deviceMake;
	}

	public String getDeviceMakeTime() {
		return deviceMakeTime;
	}

	public void setDeviceMakeTime(String deviceMakeTime) {
		this.deviceMakeTime=deviceMakeTime;
	}

	public String getSuperUserId() {
		return superUserId;
	}

	public void setSuperUserId(String superUserId) {
		this.superUserId=superUserId;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime=updateTime;
	}

	public String getDeviceStatus() {
		return deviceStatus;
	}

	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus=deviceStatus;
	}

	public String getDeviceVersion() {
		return deviceVersion;
	}

	public void setDeviceVersion(String deviceVersion) {
		this.deviceVersion=deviceVersion;
	}

}

