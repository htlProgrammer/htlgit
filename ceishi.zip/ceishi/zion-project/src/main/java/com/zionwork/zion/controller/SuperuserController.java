package com.zionwork.zion.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zioncore.utils.BaseController;
import com.zionwork.zion.entity.Superuser;
import com.zionwork.zion.service.SuperuserService;


/**
 * @author Zion Admin
 * 超级用户接口
 */
@Controller
@RequestMapping("/zion/Superuser")
public class SuperuserController extends BaseController {
    @Autowired
    private SuperuserService superuserService;
   
	//private Logger logger = LoggerFactory.getLogger(this.getClass());
    
	/**
     * 通过状态查找某个用户信息
     *
     * @param status
     * @return 
     */
    @RequestMapping("/findSuperUserByStatus")
    @ResponseBody
    public void findSuperUserByStatus(HttpServletRequest req,HttpServletResponse resp){
    	String status=req.getParameter("status");
    	//判断参数是否为空
    	if (!validateParams(resp,req,status)) {
			return;
		}
    	try {
    		//查找数据
    		List<Superuser> list=superuserService.findSuperUserByStatus(status);
    		if (list.size()==0) {
    			printJson(resp,req, 400, "Find superuser's info by superuser's status does not exist","String");
			}else {
				printJson(resp,req, 200, list,"List");
			}
    		return;
		} catch (Exception e) {
			//出现异常，抛出异常
			printJson(resp,req, 500, e.toString(),"String");
			logger.error("Server exception", e);
		}
    }
	
   /**
    * 添加超级用户
    * @param status
    * @param superUserId
    * @param telephone
    * @param telephoneName
    * @return
    */
   @RequestMapping("/addSuperUser")
   @ResponseBody
	public void addSuperUser(HttpServletRequest req, HttpServletResponse resp) {
		// 获取参数
		String superUserId = req.getParameter("superUserId");
		String telephone = req.getParameter("telephone");
		String telephoneName = req.getParameter("telephoneName");
		String status=req.getParameter("status");
		String mailBox=req.getParameter("mailBox");
		// 参数不能为空
		if (!validateParams(resp, req, superUserId, telephone, telephoneName,status,mailBox)) {
			return;
		}
		try {
			String addSuperUser = superuserService.addSuperUser(superUserId,telephone,telephoneName,status,mailBox);
			if (addSuperUser.equals("success")) {
				printJson(resp, req, 200, addSuperUser, "String");	
			}else {
				printJson(resp, req, 400, addSuperUser, "String");	
			}	
		} catch (Exception e) {
			// 出现异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}
   
   /**
    * 通过Id查找某个用户信息
    *
    * @param superuserId
    * @return
    * @throws IOException 
    */
	@RequestMapping("/findOneSuperUser")
	@ResponseBody
	public void findOneSuperUser(HttpServletRequest req, HttpServletResponse resp) {
		// 获取参数
		String superUserId = req.getParameter("superUserId");
		// 参数不能为空
		if (!validateParams(resp, req, superUserId)) {
			return;
		}
		try {
			Superuser findSuperUserBySuperUserId = superuserService.findSuperUserBySuperUserId(superUserId);
			if (findSuperUserBySuperUserId!=null) {
				printJson(resp, req, 200, findSuperUserBySuperUserId, "Object");	
			}else {
				printJson(resp, req, 400, findSuperUserBySuperUserId, "This super user does not exist");	
			}
		} catch (Exception e) {
			// 出现异常，抛出异常
			printJson(resp, req, 500, e.toString(), "String");
			logger.error("Server exception", e);
		}
	}
	


/*	*

    *//**
     * 修改超级用户信息
     *
     * @param super_user_id
     * @param telephone
     * @param telephone_name
     * @param status
     * @param create_time
     * @return
     *//*
    //@RequestMapping("/updateSuperUser")
    @ResponseBody
    public Object updateSuperUser(HttpServletRequest req, HttpServletResponse resp) {
    	String superUserId=req.getParameter("superUserId");
    	System.out.println(superUserId);
    	logger.info("hello world");
    	return "success";
    }


    *//**
     * 通过Id查找某个用户信息
     *
     * @param superuserId
     * @return
     * @throws IOException 
     *//*
    //@RequestMapping("/findOneSuperUser")
    @ResponseBody
    public void findOneSuperUser(HttpServletRequest req,HttpServletResponse resp){
    	    printJson(resp,req, 200, "success", "String");
    }
    */
}