package com.zioncore.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;

public class S3Util {
	static AmazonS3 s3Client; 
	static{
		BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAOPZTIQPFMP5KZB2Q", "bIUya8PJslwoGaSnl+Vjqi5hLvJjvoJ/VPd5RRk/");
		s3Client = AmazonS3ClientBuilder.standard()
		                        .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
		                        .build();
	}
	
	/**
	 * 创建S3存储桶
	 * @param bucketName
	 * @return
	 */
	public static String s3createBucket(String bucketName) {
		try {
			s3Client.createBucket(bucketName);
		} catch (AmazonS3Exception e) {
			return e.getErrorMessage();
		}
		return "success";
	}
	
	/**
	 * 上传文件到S3
	 * @param bucketName
	 * @param key
	 * @param file
	 * @return
	 */
	public static String uploadDate(String bucketName,String key,String file) {
		try {
			s3Client.putObject(bucketName, key, new File(file));
		} catch (AmazonServiceException e) {
		    System.exit(1);
		    return e.getErrorMessage();
		}
		return "success";
	}
	
	/**
	 * 从S3上面下载文件
	 * @param bucketName
	 * @param key
	 * @param file
	 */
	public static void downloadDate(String bucketName,String key,String file) {
		try {
		    S3Object o = s3Client.getObject(bucketName, key);
		    S3ObjectInputStream s3is = o.getObjectContent();
		    FileOutputStream fos = new FileOutputStream(new File(file));
		    byte[] read_buf = new byte[1024];
		    int read_len = 0;
		    while ((read_len = s3is.read(read_buf)) > 0) {
		        fos.write(read_buf, 0, read_len);
		    }
		    s3is.close();
		    fos.close();
		} catch (AmazonServiceException e) {
		    System.err.println(e.getErrorMessage());
		    System.exit(1);
		} catch (FileNotFoundException e) {
		    System.err.println(e.getMessage());
		    System.exit(1);
		} catch (IOException e) {
		    System.err.println(e.getMessage());
		    System.exit(1);
		}
	}
}
