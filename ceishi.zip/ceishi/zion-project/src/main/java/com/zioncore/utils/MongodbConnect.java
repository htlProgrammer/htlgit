package com.zioncore.utils;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;

public class MongodbConnect {
	/**
	 * 连接Mongodb数据库
	 * @return
	 */
	public static MongoDatabase getMongodb() {
		//读取配置文件获取连接参数
		String host = PropertiesUtil.getProperty("spring.data.mongodb.host");
		String port = PropertiesUtil.getProperty("spring.data.mongodb.port");
		String dbName = PropertiesUtil.getProperty("spring.data.mongodb.database");
		String username = PropertiesUtil.getProperty("spring.data.mongodb.username");
		String password = PropertiesUtil.getProperty("spring.data.mongodb.password");
		// 连接mongodb
		List<ServerAddress> adds = new ArrayList<>();
		ServerAddress serverAddress = new ServerAddress(host, Integer.parseInt(port));
		adds.add(serverAddress);
		List<MongoCredential> credentials = new ArrayList<>();
		MongoCredential mongoCredential = MongoCredential.createScramSha1Credential(username, dbName,
				password.toCharArray());
		credentials.add(mongoCredential);
		@SuppressWarnings("resource")
		MongoClient mongoClient = new MongoClient(adds, credentials);
		MongoDatabase mongoDataBase = mongoClient.getDatabase(dbName);
		//返回连接
		return mongoDataBase;
	}
}
