package com.zioncore.utils;

import java.util.Arrays;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;

/**
 * @author Zion Admin
 * 在Dynamodb中创建表
 * 向表中添加数据可以读取json文件来填充，SDK中自带了jackson
 */
public class CreateDynamoDBTable {
    public static void main(String[] args) throws Exception {
        // 通过客户端生成器创建客户端
        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
        DynamoDB dynamoDB = new DynamoDB(client);
        String tableName = "Historytable";
        try {
            // 打印操作
            System.out.println("Attempting to create table; please wait...");

            Table table = dynamoDB.createTable(tableName,
                    // 声明分区键和排序键
                    Arrays.asList(new KeySchemaElement("superUserId", KeyType.HASH),
                    		new KeySchemaElement("createTime", KeyType.RANGE)),

                    // 声明数值的类型，S-->字符串 N-->数字
                    Arrays.asList(new AttributeDefinition("superUserId", ScalarAttributeType.S),
                    		new AttributeDefinition("createTime", ScalarAttributeType.S)),
                    new ProvisionedThroughput(10L, 10L));
            //创建
            table.waitForActive();
            //不抛异常则打印操作成功
            System.out.println("Success.  Table status: " + table.getDescription().getTableStatus());
        } catch (Exception e) {
            System.err.println("Unable to create table: ");
            System.err.println(e.getMessage());
        }
    }
}

