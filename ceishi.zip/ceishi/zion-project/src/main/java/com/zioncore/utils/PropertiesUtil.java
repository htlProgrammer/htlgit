package com.zioncore.utils;

import org.springframework.core.env.Environment;


/**
 * @author Zion Admin
 * properties的配置文本读取工具类
 */
public class PropertiesUtil {

	private static Environment env = null;

	public static void setEnvironment(Environment env) {
		PropertiesUtil.env = env;
	}

	public static String getProperty(String key) {
		return PropertiesUtil.env.getProperty(key);
	}

}
