package com.zioncore.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;


/**
 * @author Zion Admin
 * 关系型数据库工厂
 */
public class RelationFactory {
    public static RelationDB getInstance() {
        try {
            //反向生成某个数据库连接类
            Class<?> c = Class.forName("com.zioncore.utils.SqlClient");
            //构造函数参数类型
            @SuppressWarnings("rawtypes")
			Class[] parameterTypes = {String.class, String.class, String.class, String.class};
            //添加构造函数
            Constructor<?> constructor = c.getConstructor(parameterTypes);
            //构造函数参数
            Object[] parameters = {"com.mysql.jdbc.Driver",
                    "jdbc:mysql://127.0.0.1:3306/test?useUnicode=true&characterEncoding=utf8&useSSL=true", "root",
                    "123456"};
            //实现多态
            RelationDB relationDB = (RelationDB) constructor.newInstance(parameters);
            return relationDB;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        return null;
    }
}
