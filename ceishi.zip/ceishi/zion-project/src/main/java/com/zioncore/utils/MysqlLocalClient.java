package com.zioncore.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;


import com.mysql.jdbc.ResultSetMetaData;

/**
 * @author Zion Admin
 * mysql连接工具类
 */
/**
 * @author Zion Admin
 *
 */
/**
 * @author Zion Admin
 *
 */
public class MysqlLocalClient extends RelationDB {
    protected String driverclassname;
    protected String url;
    protected String username;
    protected String password;
    protected Connection conn;
    private static LinkedList<Connection> connPool = new LinkedList<Connection>();

    public MysqlLocalClient(String driverclassname, String url, String username, String password) {
        super();
        this.driverclassname = driverclassname;
        this.url = url;
        this.username = username;
        this.password = password;
        //1.加载驱动程序
        try {
            Class.forName(driverclassname);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        //2.获得数据库链接
        try {
            for (int i = 0; i < 20; i++) {
                conn = DriverManager.getConnection(url, username, password);
                //将创建的连接添加的list中
                System.out.println("初始化数据库连接池，创建第 " + (i + 1) + " 个连接，添加到池中");
                connPool.add(conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    /* 
     * 查找数据
     */
    @Override
    public ArrayList<Map<String, Object>> find(String sql) {
        try {
            final Connection conn = connPool.removeFirst();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            ArrayList<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
            //获取键名
            ResultSetMetaData md = (ResultSetMetaData) rs.getMetaData();
            //获取行的数量
            int columnCount = md.getColumnCount();
            while (rs.next()) {
            	//声明Map
                Map<String, Object> rowData = new HashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                	//获取键名及值
                    rowData.put(md.getColumnName(i), rs.getObject(i));
                }
                list.add(rowData);
            }
            rs.close();
            pst.close();
            connPool.add(conn);
            return list;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return null;
    }

    /* 
     * 插入数据
     */
    @Override
    public int save(String sql) {
        int i = 0;
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            i = pst.executeUpdate();
            return i;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
    }

    /* 
     * 删除数据
     */
    @Override
    public int delete(String sql) {
        int i = 0;
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            i = pst.executeUpdate();
            return i;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
    }

    /* 
     * 修改数据
     */
    @Override
    public int change(String sql) {
        int i = 0;
        try {
            PreparedStatement pst = conn.prepareStatement(sql);
            i = pst.executeUpdate();
            return i;
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return 0;
    }

}
