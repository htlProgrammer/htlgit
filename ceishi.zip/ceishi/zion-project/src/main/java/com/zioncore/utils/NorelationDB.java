package com.zioncore.utils;

import java.util.List;
import java.util.Map;


/**
 * @author Zion Admin
 * nosql数据库的父类接口
 */
public interface NorelationDB {

    public abstract String batchSave(Map<String, String> map);

    public abstract String save(Map<String, String> map);

    public abstract List<Map<String, Object>> findByKeyAndRangeKey(String tablename, String keyname, Object key, String rangekeyname, Object start, Object end);

    public abstract List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tablename, String keyname, Object key, String rangekeyname, Object start, Object end, Map<String, Object> map);

    public abstract List<Map<String, Object>> findByKeyAndRangeKey(String tablename, String keyname, Object key, String rangekeyname, Object rangekey);

    public abstract List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tablename, String keyname, Object key, String rangekeyname, Object rangekey, Map<String, Object> map);

    public abstract List<Map<String, Object>> findByKey(String tablename, String keyname, Object key);

    public abstract List<Map<String, Object>> findByKeyAndParams(String tablename, String keyname, Object key, Map<String, Object> map);
}
