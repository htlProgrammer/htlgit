package com.zioncore.utils;

import java.util.ArrayList;
import java.util.Map;


/**
 * @author Zion Admin
 * 关系型数据库抽象类
 */
public abstract class RelationDB {
    public abstract ArrayList<Map<String, Object>> find(String sql);

    public abstract int save(String sql);

    public abstract int delete(String sql);

    public abstract int change(String sql);
}
