package com.zioncore.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
/**
 * @author Zion Admin
 *接口列
 *用于为持久属性或字段指定映射列。如果没有指定列注释，则应用默认值。
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Column {
    public String name(); 
    public String text() default "这是一个属性映射";
}