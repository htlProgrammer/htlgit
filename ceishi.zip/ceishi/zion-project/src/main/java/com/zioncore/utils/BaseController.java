package com.zioncore.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zionwork.zion.controller.AopController;

public class BaseController {
	protected org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AopController.class);
    // 输出指定string
    public void print(HttpServletResponse resp, int status, String content) {
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Content-type", "text/html;charset=UTF-8");
        PrintWriter out = null;
        try {
            out = resp.getWriter();
            out.print(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 输出json化的实体/实体集合/map/map集合
    public void printJson(HttpServletResponse resp,HttpServletRequest req, int status, Object content, String dataType) {
    	
        resp.setStatus(status);
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Content-type", "application/json;charset=UTF-8");
        Map<String, Object> map = new HashMap<>();
        if (status == 200) {
            map.put("status_code", status);
            map.put("err_msg", "none");
            map.put("payload", content);
            map.put("date_type", dataType);
        } else {
            map.put("status_code", status);// 400
            map.put("err_msg", content);   // key parameter is null
            map.put("payload", "none");    //none
            map.put("date_type", dataType);  //String 
            logger.error("URL : " + req.getRequestURL().toString()+" , "+"HTTP_METHOD : " + req.getMethod()+" , "+"IP : " + req.getRemoteAddr()+" , "+"Request error:"+"{"+"status_code"+" : "+status+" , "+"err_msg"+" : "+content+" , "+"payload"+" : "+"none"+" , "+"date_type"+" : "+dataType+"}");
        }
        PrintWriter out = null;
       
        try {
            out = resp.getWriter();
            out.print(JSON.toJSONString(map)); //直接返回一个json化的map
           
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 判断参数是否为空   ；传值的方式是通过可变参数来进行String类型的传递。
    public boolean validateParams(HttpServletResponse resp,HttpServletRequest req, String... strings) {
        for (String string : strings) {
            if (string == null || string == "") {
                printJson(resp,req, 400, "Key parameter is null", "String");
                return false;  //如果为空，返回false.
            }
        }
        return true; //不为空返回true
    }
    
    //空值赋值
    public String changeNullParam(String param) {
		if (param==null||param=="") {
			param="-";
		}
		return param;
	}
    //读HttpServletRequest流   
    public JSONObject ReadHttpServletRequestIO(HttpServletRequest req, HttpServletResponse resp) {
    	JSONObject jsonObject=new JSONObject();
    	try {
            BufferedReader streamReader = new BufferedReader(new InputStreamReader(req.getInputStream(), "UTF-8"));
            StringBuilder responseStrBuilder = new StringBuilder();
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr);
            jsonObject = JSONObject.parseObject(responseStrBuilder.toString());
        } catch (Exception e) {
            printJson(resp,req, 400, e.toString(), "String");
        }
        return jsonObject;
    }

}
