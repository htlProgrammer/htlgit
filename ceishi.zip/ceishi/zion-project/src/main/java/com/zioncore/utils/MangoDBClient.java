package com.zioncore.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bson.Document;
import com.alibaba.fastjson.JSON;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.zionwork.zion.nosqlentity.MgHistory;
import com.zionwork.zion.nosqlentity.MgOperation;

/**
 * @author Zion Admin mongodb数据库的方法工具
 */
public class MangoDBClient implements NorelationDB {
	protected MongoClient mongoClient;
	protected MongoDatabase mongoDataBase;
	Map<String, Object> nullMap = new HashMap<String, Object>();

	@SuppressWarnings("static-access")
	public MangoDBClient() {
		/*
		 * if (serverAddress!=null&&port!=null&&dbName!=null) { mongoClient = new
		 * MongoClient(serverAddress, Integer.parseInt(port)); mongoDataBase =
		 * mongoClient.getDatabase(dbName); }else { mongoClient=null;
		 * mongoDataBase=null; }
		 */
		try {
			// 读取properties配置的信息，连接mongodb
			PropertiesUtil propertiesUtil = new PropertiesUtil();
			String host = propertiesUtil.getProperty("spring.data.mongodb.host");
			String port = propertiesUtil.getProperty("spring.data.mongodb.port");
			String dbName = propertiesUtil.getProperty("spring.data.mongodb.database");
			String username = propertiesUtil.getProperty("spring.data.mongodb.username");
			String password = propertiesUtil.getProperty("spring.data.mongodb.password");
			// 连接mongodb
			List<ServerAddress> adds = new ArrayList<>();
			ServerAddress serverAddress = new ServerAddress(host, Integer.parseInt(port));
			adds.add(serverAddress);
			List<MongoCredential> credentials = new ArrayList<>();
			MongoCredential mongoCredential = MongoCredential.createScramSha1Credential(username, dbName,
					password.toCharArray());
			credentials.add(mongoCredential);
			mongoClient = new MongoClient(adds, credentials);
			mongoDataBase = mongoClient.getDatabase(dbName);
		} catch (Exception e) {
			// 连接异常输出异常错误
			e.printStackTrace();
		}
	}

	/*
	 * 批量插入数据
	 */
	@Override
	public String batchSave(Map<String, String> map) {
		MongoCollection<Document> collection = null;
		try {
			// 区分数据存储到哪张表
			if (map.containsKey("History")) {
				collection = mongoDataBase.getCollection("Historytable");
				List<MgHistory> list = JSON.parseArray(map.get("History"), MgHistory.class);
				// 排序键加上UUID确保唯一性
				for (int i = 0; i < list.size(); i++) {
					String uuid = UUID.randomUUID().toString().replaceAll("-", "");
					MgHistory history = list.get(i);
					history.setCreateTime(history.getCreateTime() + "-" + uuid);
				}
				collection.insertMany(BsonUtil.toBsons(list));
			} else if (map.containsKey("Operation")) {
				collection = mongoDataBase.getCollection("Operationtable");
				List<MgOperation> list = JSON.parseArray(map.get("Operation"), MgOperation.class);
				collection.insertMany(BsonUtil.toBsons(list));
			}
		} catch (Exception e) {
			//存储失败，抛出异常
			return e.toString();
		}
		//存储成功打印success
		return "success";
	}

	/* 
	 * 插入单条数据
	 */
	@Override
	public String save(Map<String, String> map) {
		MongoCollection<Document> collection = null;
		try {
			//区分数据存储到哪张表
			if (map.containsKey("History")) {
				collection = mongoDataBase.getCollection("Historytable");
				MgHistory mgHistory = (MgHistory) JSON.parseObject(map.get("History"), MgHistory.class);
				collection.insertOne(BsonUtil.toBson(mgHistory));
			} else if (map.containsKey("Operation")) {
				collection = mongoDataBase.getCollection("Operationtable");
				MgOperation mgOperation = (MgOperation) JSON.parseObject(map.get("Operation"), MgOperation.class);
				collection.insertOne(BsonUtil.toBson(mgOperation));
			}
		} catch (Exception e) {
			//存储失败，抛出异常
			return e.toString();
		}
		//存储成功打印success
		return "success";
	}

	/* 
	 * 根据分区键排序键以及条件查询数据
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tableName, String keyName, Object key,
			String rangeKeyName, Object start, Object end, Map<String, Object> map) {
		//选择查询的数据表
		MongoCollection<Document> collection = mongoDataBase.getCollection(tableName);
		BasicDBList condList = new BasicDBList();
		BasicDBObject query = new BasicDBObject();
		BasicDBObject query2 = new BasicDBObject();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		try {
			query.append(keyName, key);
			//根据排序键进行查询条件的拼接
			if (start != "" && end != "") {
				//如果start，end都存在需要考虑两者相等的情况
				if (!start.equals(end)) {
					query.append(rangeKeyName, new BasicDBObject("$gt", start));
					query2.append(rangeKeyName, new BasicDBObject("$lte", end));
				} else {
					query.append(rangeKeyName, start);
				}
			} else if (start != "" && end == "") {
				query.append(rangeKeyName, new BasicDBObject("$gt", start));
			} else if (start == "" && end != "") {
				query.append(rangeKeyName, new BasicDBObject("$lte", end));
			}
			//处理除了分区键和排序键之外的其他查询条件
			if (map.size() != 0) {
				for (String mapKey : map.keySet()) {
					query.append(mapKey, map.get(mapKey));
				}
			}
			condList.add(query);
			condList.add(query2);
			//拼接所有查询条件
			BasicDBObject cond = new BasicDBObject();
			cond.put("$and", condList);
			FindIterable<Document> find = collection.find(cond);
			//查询结果转成Map，放入list，返回出去
			for (Document document : find) {
				list.add(document);
			}
			return list;
		} catch (Exception e) {
			//查询异常
			throw e;
		}
	}

	/*
	 * 根据分区键和排序键查范围内找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKey(String tableName, String keyName, Object key,
			String rangeKeyName, Object start, Object end) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangeKeyName, start, end, nullMap);
	}
	
	/* 
	 * 根据分区键和排序键定位查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKey(String tableName, String keyName, Object key,
			String rangeKeyName, Object rangeKey) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangeKeyName, rangeKey, rangeKey, nullMap);
	}

	/* 
	 * 根据分区键和排序键以及其他条件定位查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tableName, String keyName, Object key,
			String rangeKeyName, Object rangeKey, Map<String, Object> map) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangeKeyName, rangeKey, rangeKey, map);
	}

	/* 
	 * 根据分区键查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKey(String tableName, String keyName, Object key) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, "", "", "", nullMap);
	}

	/* 
	 * 根据分区键和其他条件查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndParams(String tableName, String keyName, Object key,
			Map<String, Object> map) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, "", "", "", map);
	}

}
