package com.zioncore.utils;


/**
 * @author Zion Admin
 * nosql数据库的工厂类
 */
public class NorelationFactory {

	
	public static NorelationDB getInstance() {
		PropertiesUtil propertiesUtil=new PropertiesUtil();
		@SuppressWarnings("static-access")
		//从properties中读取数据库选择
		String attrValue = propertiesUtil.getProperty("norelationDBpath");
	        try {
	        	//反射选择具体的子类
	        	NorelationDB norelationDB = (NorelationDB)Class.forName(attrValue).newInstance();
	            return norelationDB;
	        } catch (Exception e) {
	        	//异常抛出
	            e.printStackTrace();
	        } 
	        return null;
	    }	
}
