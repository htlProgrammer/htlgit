package com.zioncore.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeConversion {
	public String beforeDay(Date dNow,Integer index) throws ParseException {
		Date dBefore = new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd"); //设置时间格式
		Calendar calendar = Calendar.getInstance(); //得到日历
		calendar.setTime(dNow);//把当前时间赋给日历
		calendar.add(Calendar.DAY_OF_MONTH, -index); //设置为前一天
		dBefore = calendar.getTime(); //得到前一天的时间		
		String defaultStartDate = sdf.format(dBefore); //格式化前一天
		defaultStartDate = defaultStartDate+" 00:00:00";
		String temp=DateFormat.getDateTimeInstance().parse(defaultStartDate).getTime()+"";//String转时间格式
		return temp.substring(0,temp.length()-3);//将毫秒变成秒数输出
	}
	
	public String currentDay(Date dNow) throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd"); //设置时间格式
		String defaultStartDate=sdf.format(dNow)+" 00:00:00";
		String temp=DateFormat.getDateTimeInstance().parse(defaultStartDate).getTime()+"";
		return temp.substring(0,temp.length()-3);//将毫秒变成秒数输出
	}
}
