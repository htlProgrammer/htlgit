package com.zioncore.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.alibaba.fastjson.JSON;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.zionwork.zion.nosqlentity.DyHistory;
import com.zionwork.zion.nosqlentity.DyOperation;

/**
 * @author Zion Admin 
 * dynamodb数据库的方法工具
 */
public class DynamoDBClient implements NorelationDB {        	

	protected DynamoDB dynamoDB;
	protected AmazonDynamoDB client;
	protected DynamoDBMapper mapper;
	public DynamoDBClient() {
		// 通过客户端生成器创建客户端
		client = AmazonDynamoDBClientBuilder.standard().build();
		dynamoDB = new DynamoDB(client);
		mapper = new DynamoDBMapper(client);
	}

	Map<String, Object> nullMap = new HashMap<String, Object>();

	/*
	 * 批量插入数据
	 */
	@Override
	public String batchSave(Map<String, String> map) {
		try {
			//区分数据存储到哪张表
			if (map.containsKey("History")) {
				List<DyHistory> list = (List<DyHistory>) JSON.parseArray(map.get("History"), DyHistory.class);
				//排序键加上UUID确保唯一性
				for (int i = 0; i < list.size(); i++) {
        			String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        			DyHistory history = list.get(i);
        			history.setCreateTime(history.getCreateTime() + "-" + uuid);
                }
				DyHistory[] array = list.toArray(new DyHistory[list.size()]);
				mapper.batchSave(Arrays.asList(array));
			} else if (map.containsKey("Operation")) {
				List<DyOperation> list = (List<DyOperation>) JSON.parseArray(map.get("Operation"), DyOperation.class);
				DyOperation[] array = list.toArray(new DyOperation[list.size()]);
				mapper.batchSave(Arrays.asList(array));
			}
			//不成功则抛出异常
		} catch (Exception e) {
			return e.toString();
		}
		//成功打印success
		return "success";
	}
		
	/* 
	 * 插入单条数据
	 */
	@Override
	public String save(Map<String, String> map) {
		try {
			//区分数据存储到哪张表
			if (map.containsKey("History")) {
				DyHistory dyHistory = (DyHistory) JSON.parseObject(map.get("History"), DyHistory.class);
				mapper.save(dyHistory);
			} else if (map.containsKey("Operation")) {
				DyOperation dyOperation = (DyOperation) JSON.parseObject(map.get("Operation"), DyOperation.class);
				mapper.save(dyOperation);
			}
			//不成功则抛出异常
		} catch (Exception e) {
			return e.toString();
		}
		//成功打印success
		return "success";
	}
	
	/* 
	 * 根据分区键排序键以及条件查询数据
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tableName, String keyName, Object key,
			String rangekeyName, Object start, Object end, Map<String, Object> map) {
		//选择查询的表
		Table table = dynamoDB.getTable(tableName);
		ValueMap valueMap = new ValueMap();
		String conditions = "";
		String keyConditions = "";
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> rowData = new HashMap<String, Object>();
		QuerySpec spec = new QuerySpec();
		try {
			//根据排序键进行查询条件的拼接
			if (start == ""&& end == "") {
				valueMap.with(":id", key);
				keyConditions = keyName + "= :id ";
			} else if (start == "") {
				valueMap.with(":id", key).with(":rangeId", end);
				keyConditions = keyName + "= :id and " + rangekeyName + "<= :rangeId";
			} else if (end == "") {
				valueMap.with(":id", key).with(":rangeId", start);
				keyConditions = keyName + "= :id " + " and " + rangekeyName + ">= :rangeId";
			} else {
				//如果start，end都存在需要考虑两者相等的情况
				if (start == end) {
					valueMap.with(":id", key).with(":rangeId", end);
					keyConditions = keyName + "= :id and " + rangekeyName + "= :rangeId";
				} else {
					valueMap.with(":id", key).with(":rangeId", end).with(":rangeId2", start);
					keyConditions = keyName + "= :id and " + rangekeyName + " between :rangeId2 and :rangeId";
				}
			}
			//处理除了分区键和排序键之外的其他查询条件
			if (map.size() != 0) {
				for (String mapKey : map.keySet()) {
					conditions = conditions + mapKey + "=:" + mapKey + " and ";
					valueMap.with(":" + mapKey, map.get(mapKey));
				}
				spec = new QuerySpec().withKeyConditionExpression(keyConditions)
						.withFilterExpression(conditions.substring(0, conditions.length() - 4)).withValueMap(valueMap);
			} else {
				spec = new QuerySpec().withKeyConditionExpression(keyConditions).withValueMap(valueMap);
			}
			ItemCollection<QueryOutcome> query = table.query(spec);
			//查找结果转成Map，放入到list，返回出去
			for (Item item : query) {
				rowData = item.asMap();
				list.add(rowData);	
			}
			return list;
			//异常输出
		} catch (Exception e) {
			System.err.println("Unable to read item: " + key);
			System.err.println(e.getMessage());
			throw e;
		}	
	}

	/*
	 * 根据分区键和排序键查范围内找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKey(String tableName, String keyName, Object key,
			String rangeKeyName, Object start, Object end) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangeKeyName, start, end, nullMap);
	}

	/* 
	 * 根据分区键和排序键定位查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKey(String tableName, String keyName, Object key,
			String rangekeyName, Object rangeKey) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangekeyName, rangeKey, rangeKey, nullMap);
	}

	/* 
	 * 根据分区键和排序键以及其他条件定位查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndRangeKeyAndParams(String tableName, String keyName, Object key,
			String rangekeyName, Object rangeKey, Map<String, Object> map) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, rangekeyName, rangeKey, rangeKey, map);
	}

	/* 
	 * 根据分区键查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKey(String tableName, String keyName, Object key) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, "", "", "", nullMap);
	}

	/* 
	 * 根据分区键和其他条件查找信息
	 */
	@Override
	public List<Map<String, Object>> findByKeyAndParams(String tableName, String keyName, Object key,
			Map<String, Object> map) {
		return findByKeyAndRangeKeyAndParams(tableName, keyName, key, "", "", "", map);
	}

	
}
