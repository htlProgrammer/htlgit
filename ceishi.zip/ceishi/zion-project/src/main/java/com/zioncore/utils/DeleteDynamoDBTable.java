package com.zioncore.utils;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;

/**
 * @author Zion Admin
 * 删除Dynamodb中的表
 */
public class DeleteDynamoDBTable {

    public static void main(String[] args) throws Exception {
    	// 通过客户端生成器创建客户端
    	AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
        DynamoDB dynamoDB = new DynamoDB(client);
        Table table = dynamoDB.getTable("Music");
        try {
        	// 打印操作
            System.out.println("Attempting to delete table; please wait...");
            table.delete();
            table.waitForDelete();
            //不抛异常则打印操作成功
            System.out.print("Success.");
        }
        catch (Exception e) {
            System.err.println("Unable to delete table: ");
            System.err.println(e.getMessage());
        }
    }
}