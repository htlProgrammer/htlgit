package zionwork.zion;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;


import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.zionwork.zion.Start;
import com.zionwork.zion.entity.Permissions;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class PermissionsControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testAddPermission() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId = "hhhhh";
		    String targetId = "1";
		    String relationType = "1";
		    String relationValue = "1";
		    String superUserId = "1";
		    String targetType ="";
		    params.add("userId",userId);
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("relationType",relationType);
			params.add("relationValue",relationValue);
			params.add("targetType",targetType);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/addPermission").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testPushPermissionInfo() {
		try {
			List<Permissions> list=new ArrayList<>();
			Permissions p=new Permissions();
			p.setUserId("a");
			p.setTargetId("a");
			p.setRelationType("a");
			Permissions p1=new Permissions();
			p1.setUserId("a1");
			p1.setTargetId("a1");
			p1.setRelationType("a1");
			list.add(p);
			list.add(p1);
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/pushPermissionInfo").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdatePermission() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId = "1";
		    String targetId = "1";
		    String relationType = "1";
		    String relationValue = "2";
		    params.add("userId",userId);
			params.add("targetId",targetId);
			params.add("relationType",relationType);
			params.add("relationValue",relationValue);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/updatePermission").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindPermissionByUserIdAndDeviceIdAndValue() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId = "hhhhh";
		    String targetId = "SmokeDetector";
		    String relationType = "HISTORY";
		    String relationValue = "SELF";
		    String superUserId = "01000122";
		    params.add("userId",userId);
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("relationType",relationType);
			params.add("relationValue",relationValue);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/findPermissionByUserIdAndDeviceIdAndValue").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindPermissionByUserIdAndRelation() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId = "zionsxt";
		    String relationType = "HISTORY";
		    String relationValue = "SELF";
		    String superUserId = "01000122";
		    params.add("userId",userId);
			params.add("superUserId",superUserId);
			params.add("relationType",relationType);
			params.add("relationValue",relationValue);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/findPermissionByUserIdAndRelation").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindPermissionByUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId = "e";
		    params.add("userId",userId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/findPermissionByUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindPermissionBysuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String targetId = "SmokeDetector";
		    String superUserId = "01000122";
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/findPermissionBysuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testDeleteAllPermissionsByAllUserId() {
		try {
			List<String> list=new ArrayList<>();
			list.add("a");
			list.add("a1");
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Permissions/deleteAllPermissionsByAllUserId").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
