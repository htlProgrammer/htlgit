package zionwork.zion;

import static org.junit.Assert.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.zionwork.zion.Start;
import com.zionwork.zion.entity.History;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class HistoryControllerTest {	
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testPushDateToHistory() {
		try {
			List<History> list=new ArrayList<>();
			for (int i = 0; i <1000; i++) {
				History history=new History();
				history.setSuperUserId("11111");
				history.setCreateTime(String.valueOf(Instant.now().getEpochSecond()));
				history.setDeviceId("3"+i);
				if (i==1111||i==22222) {
					history.setCurrentStatusValue("Alarm");
				}else {
					history.setCurrentStatusValue("ddsdf");
				}
				history.setDeviceSignType("ssssss");
				history.setDeviceWorkStatus("asfasda");
				history.setDeviceType("sdfasdfsd");
				list.add(history);
			}
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			System.out.println(jsonparam.getBytes().length);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/History/pushDateToHistory").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
	        System.out.println("ceshi"+jsonparam.getBytes().length);
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllInfoByDeviceAndTimeFromHistory() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String deviceId = "SUNRAY_SmokeDetector_0869-4870-3001-6306";
		    String startTime = "1555398226";
		    String endTime = "1559398228";
		    String superUserId = "01000122";
			params.add("superUserId",superUserId);
			params.add("deviceId",deviceId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/History/findAllInfoByDeviceAndTimeFromHistory").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceInfoBySuperUserAndTimeFromHistory() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String startTime = "1555398226";
		    String endTime = "1555398228";
		    String superUserId = "01000122";
			params.add("superUserId",superUserId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/History/findAllDeviceInfoBySuperUserAndTimeFromHistory").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllInfoBySuperUserDeviceTypeAndTimeFromHistory() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String deviceType = "SmokeDetector";
		    String startTime = "1555398226";
		    String endTime = "1555398228";
		    String superUserId = "01000122";
			params.add("superUserId",superUserId);
			params.add("deviceType",deviceType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/History/findAllInfoBySuperUserDeviceTypeAndTimeFromHistory").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
