package zionwork.zion;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.zionwork.zion.Start;

import org.springframework.boot.test.context.SpringBootTest;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class AreaControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	@Before
	public void setUp() throws Exception {
		 mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testAddArea() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaName="001";
			String length="100.68489";
			String width="10.564";
			String height="";
			String userId="";
			String superUserId="";
			String areaPictureUrl="ceshi2";
			params.add("areaName",areaName);
			params.add("length", length);
			params.add("width", width);
			params.add("height", height);
			params.add("userId", userId);
			params.add("superUserId", superUserId);
			params.add("areaPictureUrl", areaPictureUrl);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/addArea").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		} 
	}

	@Test
	public void testUpdateArea() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId="652cf7fabc114744a53f731e618e3bb3";
			String areaName="ceshi";
			String length="100";
			String width="100";
			String height="";
			String userId="wangwu";
			String superUserId="01000122";
			String areaPictureUrl="ceshi";
			params.add("areaId",areaId);
			params.add("areaName",areaName);
			params.add("length", length);
			params.add("width", width);
			params.add("height", height);
			params.add("userId", userId);
			params.add("superUserId", superUserId);
			params.add("areaPictureUrl", areaPictureUrl);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/updateArea").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		} 
	}

	@Test
	public void testUpdateAreaSize() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId="652cf7fabc114744a53f731e618e3bb3";
			String length="100";
			String width="100";
			String height="";
			params.add("length",length);
			params.add("width",width);
			params.add("height",height);
			params.add("areaId",areaId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/updateAreaSize").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateAreaUserId() {
		
		
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId="1";
			String userId="01000122";
			params.add("userId",userId);
			params.add("areaId",areaId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/updateAreaUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}
	
	@Test
	public void testUpdateAreasuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId="cecabe736d4a4b5fa01b32d5c7f3fe0c";
			String superUserId="01000122";
			params.add("superUserId",superUserId);
			params.add("areaId",areaId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/updateAreasuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAreaInfoBySuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId="01000122";
			params.add("superUserId", superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/findAreaInfoBySuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAreaInfoByAreaId() {

		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId="652cf7fabc114744a53f731e618e3bb3";
			params.add("areaId",areaId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/findAreaInfoByAreaId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAreaInfoBySuperUserIdAndUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String userId="zionsxt";
			String superUserId="01000122";
			params.add("superUserId",superUserId);
			params.add("userId",userId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Area/findAreaInfoBySuperUserIdAndUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
		
	}

}
