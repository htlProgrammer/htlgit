package zionwork.zion;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;
import com.zionwork.zion.Start;
import com.zionwork.zion.entity.Operation;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class OperationControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testPushOperationsInfo() {
		try {
			List<Operation> list=new ArrayList<>();
			Operation operation=new Operation();
			operation.setOperateUser("ceshi");
			Operation operation2=new Operation();
			operation2.setOperateUser("ceshi2");
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/pushOperationsInfo").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testAddOperationInfo() {
		try {
			List<Operation> list=new ArrayList<>();
			Operation operation=new Operation();
			operation.setSuperUserId("0100012");
			operation.setOperateUser("hhhhh");
			list.add(operation);
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/addOperationInfo").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindOneOperationInfo() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operationId = "795d24d2-5cea-11e9-a514-6c96cfdfefdf";
		    String superUserId = "01000122";
		    params.add("operationId",operationId);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findOneOperationInfo").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationInfoByTimeAndDevice() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String targetId = "SmokeDetector";
		    String superUserId = "01000122";
		    String startTime = "";
		    String endTime = "";
		    params.add("targetId",targetId);
			params.add("superUserId",superUserId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationInfoByTimeAndDevice").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindOneDeviceAllOprationInfoByOperateResultAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operateUserId = "xdrfgh";
		    String superUserId = "01000122";
		    String operationResult = "PENDING";
		    String startTime = "";
		    String endTime = "";
		    params.add("operateUserId",operateUserId);
			params.add("superUserId",superUserId);
			params.add("operationResult",operationResult);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findOneDeviceAllOprationInfoByOperateResultAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationInfoByOperateUserAndDeviceIdAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operateUser = "xdrfgh";
		    String superUserId = "01000122";
		    String targetId = "SmokeDetector";
		    String startTime = "";
		    String endTime = "";
		    params.add("operateUser",operateUser);
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationInfoByOperateUserAndDeviceIdAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationInfoByOperateUserAndDeviceIdAndDeviceType() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operateUser = "xdrfgh";
		    String superUserId = "01000122";
		    String targetId = "SmokeDetector";
		    String targetType="SYSTEM";
		    String startTime = "";
		    String endTime = "";
		    params.add("operateUser",operateUser);
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("targetType",targetType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationInfoByOperateUserAndDeviceIdAndDeviceType").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationInfoByOperateUserAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operateUser = "xdrfgh";
		    String superUserId = "01000122";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
		    params.add("operateUser",operateUser);
			params.add("superUserId",superUserId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationInfoByOperateUserAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindOneDeviceAllOperationInfoByOperateResultAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String operateResult = "PENDING";
		    String superUserId = "01000122";
		    String targetId = "SmokeDetector";
		    String operateType="USER_REGISTER";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
		    params.add("operateResult",operateResult);
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("operateType",operateType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findOneDeviceAllOperationInfoByOperateResultAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceOperationBySuperUserAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String superUserId = "01000122";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
			params.add("superUserId",superUserId);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllDeviceOperationBySuperUserAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindOneDeviceAllOperationInfoByOperateTypeAndTime() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String superUserId = "01000122";
		    String targetId = "SmokeDetector";
		    String operateType="USER_REGISTER";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("operateType",operateType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findOneDeviceAllOperationInfoByOperateTypeAndTime").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationFromTimeBySuperUserAndDeviceType() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String superUserId = "01000122";
		    String targetType="SYSTEM";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
			params.add("superUserId",superUserId);
			params.add("targetType",targetType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationFromTimeBySuperUserAndDeviceType").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String superUserId = "01000122";
		    String targetId = "SmokeDetector";
		    String targetType="SYSTEM";
		    String startTime = "1555045646";
		    String endTime = "1555045647";
			params.add("superUserId",superUserId);
			params.add("targetId",targetId);
			params.add("targetType",targetType);
			params.add("startTime",startTime);
			params.add("endTime",endTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Operation/findAllOperationFromTimeBySuperUserAndDeviceTypeAndTargetId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
