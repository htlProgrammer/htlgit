package zionwork.zion;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.zionwork.zion.Start;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class DeviceControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testRegisterDevice() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceType = "CESHI";
			String deviceMake = "";
			String deviceMakeTime = "2019-01-01";
			String deviceStatus = "CESHI1";
			String deviceVersion ="";
			String deviceId = "CESHI_SmokeDetector_0869-4870-3002-3688";
			params.add("deviceId",deviceId);
			params.add("deviceVersion",deviceVersion);
			params.add("deviceType",deviceType);
			params.add("deviceMake",deviceMake);
			params.add("deviceStatus",deviceStatus);
			params.add("deviceMakeTime",deviceMakeTime);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/registerDevice").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateDeviceInfoBySuperUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000124";
			String deviceId = "CESHI_SmokeDetector_0869-4870-3002-3688";
			params.add("deviceId",deviceId);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/updateDeviceInfoBySuperUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateDeviceByArea() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId = "001";
			String length = "10.5";
	        String width ="10.51";
	        String height ="0";
			String deviceId = "1";
			params.add("deviceId",deviceId);
			params.add("areaId",areaId);
			params.add("length",length);
			params.add("width",width);
			params.add("height",height);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/updateDeviceByArea").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateDeviceInfoByStatus() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceStatus = "Working";
			String deviceId = "CESHI_SmokeDetector_0869-4870-3002-3688";
			params.add("deviceId",deviceId);
			params.add("deviceStatus",deviceStatus);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/updateDeviceInfoByStatus").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateDeviceInfoByStatusAndSuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "1";
			String deviceStatus="1";
			String deviceId = "1";
			params.add("deviceId",deviceId);
			params.add("superUserId",superUserId);
			params.add("deviceStatus", deviceStatus);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/updateDeviceInfoByStatusAndSuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	
	@Test
	public void testFindDeviceInfoByDeviceIdAndSuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000124";
			String deviceId = "SUNRAY_SmokeDetector_0869-4870-3002-3684";
			params.add("deviceId",deviceId);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoByDeviceIdAndSuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindDeviceInfoBySuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000124";
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoBySuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindDeviceInfoByDeviceTypeAndSuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceType = "SmokeDetector";
			String superUserId = "01000124";
			params.add("deviceType",deviceType);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoByDeviceTypeAndSuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindDeviceInfoByDeviceTypeAndAreaAndSuperUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceType = "SmokeDetector";
			String superUserId = "01000124";
			String areaId = "010";
			params.add("deviceType",deviceType);
			params.add("areaId",areaId);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoByDeviceTypeAndAreaAndSuperUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceType = "SmokeDetector";
			String superUserId = "01000124";
			String deviceStatus = "Working";
			params.add("deviceType",deviceType);
			params.add("deviceStatus",deviceStatus);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoBySuperUserIdAndDevcieTypeAndDeviceStatus").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}
	
	@Test
	public void testFindDeviceInfoByDevcieTypeAndDeviceStatus() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceType = "SmokeDetector";
			String deviceStatus = "Working";
			params.add("deviceType",deviceType);
			params.add("deviceStatus",deviceStatus);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Device/findDeviceInfoByDevcieTypeAndDeviceStatus").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
