package zionwork.zion;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;


import com.zionwork.zion.Start;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class SuperuserControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testFindSuperUserByStatus() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String status = "normal";
		    params.add("status",status);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Superuser/findSuperUserByStatus").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	
    

}
