package zionwork.zion;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.alibaba.fastjson.JSON;


import com.zionwork.zion.Start;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class UserControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build(); 
	}

	@Test
	public void testAddUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
		    String userId = "cy";
		    String password = "321345646";
		    String phoneNumber = "13809881088";
		    String realName = "ceshi";
		    String birthday = "1922-01-01";
			params.add("userId",userId);
			params.add("superUserId",superUserId);
			params.add("password",password);
			params.add("phoneNumber",phoneNumber);
			params.add("realName",realName);
			params.add("birthday",birthday);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/addUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testUpdateUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String userId = "cy";
		    String password = "";
		    String phoneNumber = "999";
		    String realName = "";
		    String birthday = "";
			params.add("userId",userId);
			params.add("password",password);
			params.add("phoneNumber",phoneNumber);
			params.add("realName",realName);
			params.add("birthday",birthday);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/updateUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testValidateUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String userId = "cy";
		    String superUserId = "01000122";
		    params.add("userId",userId);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/validateUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindUserByUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
		    String userId = "cy";
		    params.add("userId",userId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/findUserByUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllUserBySuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/findAllUserBySuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindUserIdByphoneNumber() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String phoneNumber = "888";
			params.add("phoneNumber",phoneNumber);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/findUserIdByphoneNumber").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testDeleteAllByAllUserId() {
		try {
			List<String> list=new ArrayList<>();
			list.add("1");
			list.add("2");
			list.add("3");
			String jsonparam="{payload:"+JSON.toJSONString(list)+"}";
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/User/deleteAllByAllUserId").content(jsonparam));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
