package zionwork.zion;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.zionwork.zion.Start;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(classes = Start.class)
@Ignore
public class MessageControllerTest {
	@Autowired 
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;
	@Before
	public void setUp() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext ).build();
	}

	@Test
	public void testUpdateMessageUserIdByAreaId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String areaId = "-";
			String userId = "1111";
			params.add("areaId",areaId);
			params.add("userId",userId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/updateMessageUserIdByAreaId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}
	
	@Test
	public void testFindAllDeviceInfoBySuperUserAndDeviceType() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
			String deviceType = "SmokeDetector";
			params.add("deviceType",deviceType);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findAllDeviceInfoBySuperUserAndDeviceType").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceInfoBySuperUserId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000124";
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findAllDeviceInfoBySuperUserId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
			String deviceType = "SmokeDetector";
			String areaId = "001";
			params.add("deviceType",deviceType);
			params.add("superUserId",superUserId);
			params.add("areaId",areaId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findAllDeviceInfoBySuperUserIdAndDeviceTypeAndAreaId").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValue() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
			String deviceType = "SmokeDetector";
			String statusValue = "2893";
			params.add("deviceType",deviceType);
			params.add("superUserId",superUserId);
			params.add("statusValue",statusValue);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findAllDeviceInfoBySuperUserIdAndDeviceTypeAndStatusValues").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindSuperUserIdAllDeviceByUserIdAndType() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "11111";
			String deviceType = "sdfasdfsd";
			String userId = "-";
			params.add("deviceType",deviceType);
			params.add("superUserId",superUserId);
			params.add("userId",userId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findSuperUserIdAllDeviceByUserIdAndType").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindAllDeviceCurrentStatusValueBySuperUser() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String superUserId = "01000122";
			String statusValue = "2893";
			params.add("statusValue",statusValue);
			params.add("superUserId",superUserId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findAllDeviceCurrentStatusValueBySuperUser").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

	@Test
	public void testFindOneDeviceInfo() {
		try {
			MultiValueMap<String, String> params=new LinkedMultiValueMap<>();
			String deviceId = "SUNRAY_SmokeDetector_0869-4870-3002-3684";
			params.add("deviceId",deviceId);
			ResultActions resultActions = mockMvc.perform(MockMvcRequestBuilders.post("/zion/Message/findOneDeviceInfo").params(params));
	        MvcResult mvcResult = resultActions.andDo(MockMvcResultHandlers.print()).andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
	        String result = mvcResult.getResponse().getContentAsString();
	        System.out.println("==========结果为：==========\n" + result + "\n");
		} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("Not yet implemented");
		}
	}

}
